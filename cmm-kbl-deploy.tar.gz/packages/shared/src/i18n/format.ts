import type { Language } from '../constants';

/**
 * Indian formatting utilities (docs/plans/10-internationalization.md §4).
 * Always used for prize ladder, scores, and reports.
 */

const inrFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

const countFormatter = new Intl.NumberFormat('en-IN');

/** 10000000 → "₹1,00,00,000" (lakh/crore grouping) */
export function formatINR(amount: number): string {
  return inrFormatter.format(amount);
}

/** 1250 → "1,250" */
export function formatCount(n: number): string {
  return countFormatter.format(n);
}

/** Compact display for large amounts on the ladder: 10000000 → "1 करोड़" / "1 Cr" */
export function formatPrizeShort(amount: number, lang: Language): string {
  if (amount >= 10_000_000 && amount % 10_000_000 === 0) {
    const cr = amount / 10_000_000;
    return lang === 'hi' ? `${formatCount(cr)} करोड़` : `${formatCount(cr)} Cr`;
  }
  if (amount >= 100_000 && amount % 100_000 === 0) {
    const lakh = amount / 100_000;
    return lang === 'hi' ? `${formatCount(lakh)} लाख` : `${formatCount(lakh)} L`;
  }
  return formatINR(amount);
}

export function formatDate(d: Date | string, lang: Language): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  return new Intl.DateTimeFormat(lang === 'hi' ? 'hi-IN' : 'en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function formatTime(d: Date | string, lang: Language): string {
  const date = typeof d === 'string' ? new Date(d) : d;
  return new Intl.DateTimeFormat(lang === 'hi' ? 'hi-IN' : 'en-IN', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

/** 4200 → "4.2 सेकंड" / "4.2 s" */
export function formatDuration(ms: number, lang: Language): string {
  const seconds = ms / 1000;
  return lang === 'hi' ? `${seconds.toFixed(1)} सेकंड` : `${seconds.toFixed(1)} s`;
}

/** 95000 → "00:01:35" style countdown string */
export function formatClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
