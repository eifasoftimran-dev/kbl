import type { GamePhase, LifelineType, OptionKey, GameView, StandingsEntry } from '../types';

/**
 * Socket event contracts (docs/plans/06-realtime-engine.md §3).
 * Names + payload types defined ONCE here and imported by both apps.
 */

export const CLIENT_EVENTS = {
  SESSION_JOIN: 'session:join',
  SESSION_LEAVE: 'session:leave',
  CONTROL_START: 'control:start',
  CONTROL_PAUSE: 'control:pause',
  CONTROL_RESUME: 'control:resume',
  CONTROL_NEXT: 'control:next',
  CONTROL_SELECT: 'control:select',
  CONTROL_LOCK: 'control:lock',
  CONTROL_REVEAL: 'control:reveal',
  CONTROL_OVERRIDE: 'control:override',
  CONTROL_END: 'control:end',
  CONTROL_RESET: 'control:reset',
  LIFELINE_USE: 'lifeline:use',
  CONTESTANT_TURN: 'contestant:turn',
  DISPLAY_COMMAND: 'display:command',
} as const;

export const SERVER_EVENTS = {
  STATE_CHANGED: 'state:changed',
  TIMER_TICK: 'timer:tick',
  LIFELINE_RESULT: 'lifeline:result',
  REVEAL_EFFECT: 'reveal:effect',
  SESSION_ENDED: 'session:ended',
  CONNECTION_OK: 'connection:ok',
} as const;

// --- client → server payloads -------------------------------------------------

export interface SessionJoinPayload {
  /** admin clients join by sessionId; display clients by public 6-char code */
  sessionId?: string;
  code?: string;
}

export interface SessionRefPayload {
  sessionId: string;
}

export interface ControlSelectPayload extends SessionRefPayload {
  optionKey: OptionKey;
}

export interface LifelineUsePayload extends SessionRefPayload {
  type: LifelineType;
  contestantId?: string;
}

export interface ContestantTurnPayload extends SessionRefPayload {
  contestantId: string;
}

export type DisplayCommand = 'show_question' | 'idle' | 'branding' | 'force_sync';

export interface DisplayCommandPayload extends SessionRefPayload {
  command: DisplayCommand;
}

export interface ControlOverridePayload extends SessionRefPayload {
  patch: {
    activeContestantId?: string;
    selectedOption?: OptionKey;
    dramaSeconds?: number;
    timerRemainingMs?: number;
  };
}

export interface ControlResetPayload extends SessionRefPayload {
  confirm: boolean;
  wipeAttempts?: boolean;
}

// --- server → client payloads -------------------------------------------------

export interface TimerTickPayload {
  sessionId: string;
  phase: GamePhase;
  endsAt?: number;
  remainingMs?: number;
  serverTime: number;
  paused: boolean;
}

export type RevealEffect = 'suspense_start' | 'suspense_end' | 'correct' | 'wrong';

export interface RevealEffectPayload {
  sessionId: string;
  effect: RevealEffect;
  correctOption?: OptionKey;
}

export interface SessionEndedPayload {
  sessionId: string;
  standings: StandingsEntry[];
}

/** Ack shape for every client→server event (M06 §3.1) */
export type AckResult<T = undefined> =
  | { ok: true; data?: T }
  | { ok: false; error: { code: string; message: string } };

export type StateChangedPayload = GameView;
