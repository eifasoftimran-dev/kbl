// @cmm/shared — single barrel for both apps (docs/plans/01-project-setup.md M01.2)

export * from './constants';
export * from './types';
export * from './events';
export * from './schemas';
export * from './i18n/format';

import hi from './i18n/hi.json';
import en from './i18n/en.json';

/** i18n resource bundles consumed by react-i18next (web) and report exports (server). */
export const I18N_RESOURCES = { hi, en } as const;
