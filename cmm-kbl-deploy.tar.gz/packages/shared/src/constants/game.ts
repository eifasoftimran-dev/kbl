/** Game enums & defaults per docs/plans/07-game-state-machine.md */

export const GAME_PHASES = [
  'idle',
  'lobby',
  'question_intro',
  'question_active',
  'answer_selected',
  'answer_locked',
  'reveal_suspense',
  'answer_revealed',
  'game_over',
] as const;
export type GamePhase = (typeof GAME_PHASES)[number];

export const DIFFICULTIES = ['easy', 'medium', 'hard'] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

export const OPTION_KEYS = ['A', 'B', 'C', 'D'] as const;
export type OptionKey = (typeof OPTION_KEYS)[number];

export const LIFELINE_TYPES = ['fifty_fifty', 'audience_poll', 'expert_call'] as const;
export type LifelineType = (typeof LIFELINE_TYPES)[number];

export const LANGUAGES = ['hi', 'en'] as const;
export type Language = (typeof LANGUAGES)[number];

export const SESSION_STATUSES = ['draft', 'live', 'paused', 'completed', 'aborted'] as const;
export type SessionStatus = (typeof SESSION_STATUSES)[number];

export const QUESTION_STATUSES = ['active', 'inactive'] as const;
export type QuestionStatus = (typeof QUESTION_STATUSES)[number];

export const LED_LAYOUTS = ['classic', 'compact', 'wide'] as const;
export type LedLayout = (typeof LED_LAYOUTS)[number];

export const ROTATION_MODES = ['round_robin', 'streak'] as const;
export type RotationMode = (typeof ROTATION_MODES)[number];

// Timer defaults (docs/plans/08-admin-panel.md §3.9)
export const DEFAULT_TIMER_SECONDS = 30;
export const TIMER_MIN_SECONDS = 10;
export const TIMER_MAX_SECONDS = 120;
export const TIMER_DEFAULTS_BY_DIFFICULTY: Record<Difficulty, number> = {
  easy: 30,
  medium: 30,
  hard: 45,
};

// Reveal suspense duration (seconds) — the "drama" beat before result (M07 T7)
export const DEFAULT_DRAMA_SECONDS = 2.5;
export const QUESTION_INTRO_MS = 1500;

// Prize ladder: 15 levels ₹500 → ₹1,00,00,000, safe havens at 5 & 10 (M03 §2.8)
export const LADDER_SIZE = 15;
export const LADDER_SAFE_HAVEN_LEVELS = [5, 10];
export const DEFAULT_LADDER_AMOUNTS = [
  500, 1000, 2000, 3000, 5000, 10000, 20000, 40000, 80000, 160000, 320000, 640000, 1250000, 2500000,
  10000000,
] as const;

export const DEFAULT_LADDER: ReadonlyArray<{ level: number; amount: number; isSafeHaven: boolean }> =
  DEFAULT_LADDER_AMOUNTS.map((amount, i) => ({
    level: i + 1,
    amount,
    isSafeHaven: LADDER_SAFE_HAVEN_LEVELS.includes(i + 1),
  }));
