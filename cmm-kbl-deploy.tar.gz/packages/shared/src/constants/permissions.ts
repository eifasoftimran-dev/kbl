import type { Role } from './roles';

/**
 * Permission matrix — SINGLE SOURCE OF TRUTH (docs/plans/05-auth-rbac.md §3).
 * Consumed by: server REST middleware, socket event guards, web nav/route guards.
 */
export const PERMISSIONS = {
  'dashboard.view': ['super_admin', 'operator', 'host', 'question_editor'],
  'questions.read': ['super_admin', 'operator', 'host', 'question_editor'],
  'questions.write': ['super_admin', 'question_editor'],
  'questions.delete': ['super_admin'],
  'categories.write': ['super_admin', 'question_editor'],
  'contestants.read': ['super_admin', 'operator', 'host', 'question_editor'],
  'contestants.write': ['super_admin', 'operator', 'host'],
  'sessions.read': ['super_admin', 'operator', 'host', 'question_editor'],
  'sessions.create': ['super_admin', 'operator'],
  'sessions.configure': ['super_admin', 'operator'],
  'game.control': ['super_admin', 'operator', 'host'],
  'lifelines.use': ['super_admin', 'operator', 'host'],
  'led.control': ['super_admin', 'operator', 'host'],
  'settings.read': ['super_admin', 'operator', 'host', 'question_editor'],
  'settings.write': ['super_admin'],
  'reports.read': ['super_admin', 'operator', 'host'],
  'reports.export': ['super_admin', 'operator'],
  'users.manage': ['super_admin'],
  'media.read': ['super_admin', 'operator', 'host', 'question_editor'],
  'media.upload': ['super_admin', 'operator', 'question_editor'],
  'media.delete': ['super_admin'],
  'audit.view': ['super_admin'],
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export const PERMISSION_LIST = Object.keys(PERMISSIONS) as Permission[];

/** Does `role` hold `permission`? (M05 — used identically on server & web) */
export function roleHasPermission(role: Role, permission: Permission): boolean {
  return (PERMISSIONS[permission] as readonly Role[]).includes(role);
}
