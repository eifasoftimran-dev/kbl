/** Roles per docs/plans/05-auth-rbac.md §1 */
export const ROLES = ['super_admin', 'operator', 'host', 'question_editor'] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABEL_KEYS: Record<Role, string> = {
  super_admin: 'common.roles.super_admin',
  operator: 'common.roles.operator',
  host: 'common.roles.host',
  question_editor: 'common.roles.question_editor',
};
