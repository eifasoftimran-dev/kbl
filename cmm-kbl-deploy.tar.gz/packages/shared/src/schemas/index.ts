import { z } from 'zod';
import {
  DIFFICULTIES,
  LED_LAYOUTS,
  LADDER_SIZE,
  LANGUAGES,
  OPTION_KEYS,
  ROLES,
  ROTATION_MODES,
  TIMER_MAX_SECONDS,
  TIMER_MIN_SECONDS,
} from '../constants';

/** Zod schemas shared by REST controllers and admin forms (docs/plans M04 §1). */

export const localTextSchema = z.object({
  hi: z.string().trim().min(1).max(2000),
  en: z.string().trim().min(1).max(2000),
});

// --- auth ----------------------------------------------------------------

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(200),
});
export type LoginInput = z.infer<typeof loginSchema>;

// --- users ----------------------------------------------------------------

export const userCreateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().toLowerCase().email(),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(200)
    .regex(/[A-Za-z]/, 'Password must contain a letter')
    .regex(/\d/, 'Password must contain a digit'),
  role: z.enum(ROLES),
});
export const userUpdateSchema = userCreateSchema
  .omit({ password: true })
  .partial()
  .strict();
export const passwordResetSchema = z.object({ password: userCreateSchema.shape.password });

// --- categories ----------------------------------------------------------------

export const categoryCreateSchema = z.object({
  name: localTextSchema,
  color: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/, 'Color must be a #RRGGBB hex value'),
  sortOrder: z.number().int().min(0).max(999).default(0),
});
export const categoryUpdateSchema = categoryCreateSchema.partial().strict();

// --- questions ----------------------------------------------------------------

export const questionOptionSchema = z.object({
  key: z.enum(OPTION_KEYS),
  text: localTextSchema,
});

const questionCreateBase = z.object({
  text: localTextSchema,
  options: z.array(questionOptionSchema).length(4, 'Exactly 4 options (A–D) are required'),
  correctOption: z.enum(OPTION_KEYS),
  category: z.string().min(1), // category id
  difficulty: z.enum(DIFFICULTIES),
  timerSeconds: z
    .number()
    .int()
    .min(TIMER_MIN_SECONDS)
    .max(TIMER_MAX_SECONDS)
    .default(30),
  points: z.number().int().min(0).max(1_000_000).default(1000),
  explanation: localTextSchema.nullish(),
  media: z
    .object({ kind: z.enum(['image', 'video']), assetId: z.string().min(1) })
    .nullish(),
  status: z.enum(['active', 'inactive']).default('active'),
  tags: z.array(z.string().trim().min(1).max(40)).max(10).optional(),
});

export const questionCreateSchema = questionCreateBase.superRefine((q, ctx) => {
  const keys = q.options.map((o) => o.key);
  const unique = new Set(keys);
  if (unique.size !== 4) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['options'],
      message: 'Option keys must be A, B, C, D exactly once each',
    });
  }
  if (!keys.includes(q.correctOption)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['correctOption'],
      message: 'Correct answer must be one of the 4 options',
    });
  }
});

// Partial + strict PATCH schema: only validate cross-field rules when both
// halves are present in the same request.
export const questionUpdateSchema = questionCreateBase
  .partial()
  .strict()
  .superRefine((q, ctx) => {
    if (q.options) {
      const keys = q.options.map((o) => o.key);
      if (new Set(keys).size !== 4) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['options'],
          message: 'Option keys must be A, B, C, D exactly once each',
        });
      }
      if (q.correctOption && !keys.includes(q.correctOption)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['correctOption'],
          message: 'Correct answer must be one of the 4 options',
        });
      }
    }
  });
export type QuestionCreateInput = z.infer<typeof questionCreateSchema>;
export type QuestionUpdateInput = z.infer<typeof questionUpdateSchema>;

// --- contestants ----------------------------------------------------------------

export const contestantCreateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  mobile: z
    .string()
    .regex(/^[6-9]\d{9}$/, 'Mobile must be a 10-digit Indian number'),
  city: z.string().trim().min(2).max(60),
  avatarAssetId: z.string().min(1).nullish(),
});
export const contestantUpdateSchema = contestantCreateSchema.partial().strict();

// --- sessions ----------------------------------------------------------------

export const sessionLifelineSettingsSchema = z.object({
  fiftyFifty: z.object({
    enabled: z.boolean().default(true),
    perContestant: z.number().int().min(0).max(10).default(1),
  }),
  audiencePoll: z.object({
    enabled: z.boolean().default(true),
    perContestant: z.number().int().min(0).max(10).default(1),
  }),
  expertCall: z.object({
    enabled: z.boolean().default(true),
    perContestant: z.number().int().min(0).max(10).default(1),
    durationSeconds: z.number().int().min(10).max(120).default(30),
  }),
});

export const sessionCreateSchema = z.object({
  name: z.string().trim().min(3).max(120),
  questionIds: z.array(z.string().min(1)).min(1, 'A session needs at least 1 question'),
  contestantIds: z.array(z.string().min(1)).min(1, 'A session needs at least 1 contestant'),
  rotationMode: z.enum(ROTATION_MODES).default('round_robin'),
  onTimeout: z.enum(['reveal_wrong', 'pause_for_host']).default('reveal_wrong'),
  dramaSeconds: z.number().int().min(0).max(10).default(2),
  lifelines: sessionLifelineSettingsSchema.partial().optional(),
  buzzerMode: z.boolean().default(false),
  ladderConfigId: z.string().min(1).optional(),
});
export const sessionUpdateSchema = sessionCreateSchema.partial().strict();
export type SessionCreateInput = z.infer<typeof sessionCreateSchema>;

// --- settings ----------------------------------------------------------------

export const ladderLevelsSchema = z
  .array(
    z.object({
      level: z.number().int().min(1).max(15),
      amount: z.number().int().min(0).max(100_000_000),
      isSafeHaven: z.boolean(),
    }),
  )
  .length(LADDER_SIZE, `Ladder must have exactly ${LADDER_SIZE} levels`)
  .superRefine((levels, ctx) => {
    for (let i = 1; i < levels.length; i += 1) {
      if (levels[i].amount <= levels[i - 1].amount) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Level ${i + 1} amount must be greater than level ${i}`,
        });
        break;
      }
    }
    if (levels.some((l) => l.level !== levels.indexOf(l) + 1)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Levels must be 1..15 in order' });
    }
  });

export const prizeLadderSettingsSchema = z.object({ levels: ladderLevelsSchema });

export const timerSettingsSchema = z.object({
  easy: z.number().int().min(TIMER_MIN_SECONDS).max(TIMER_MAX_SECONDS),
  medium: z.number().int().min(TIMER_MIN_SECONDS).max(TIMER_MAX_SECONDS),
  hard: z.number().int().min(TIMER_MIN_SECONDS).max(TIMER_MAX_SECONDS),
  max: z.number().int().min(TIMER_MIN_SECONDS).max(TIMER_MAX_SECONDS),
});

export const lifelinesSettingsSchema = sessionLifelineSettingsSchema;

export const themeSettingsSchema = z.object({
  logoAssetId: z.string().min(1).nullish(),
  brandPrimary: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  brandAccent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  ledLayout: z.enum(LED_LAYOUTS),
  buzzerMode: z.boolean(),
  defaultLanguage: z.enum(LANGUAGES),
  showHostIllustration: z.boolean(),
  showReflection: z.boolean(),
  slogans: z.object({
    topLeft: localTextSchema,
    center: localTextSchema,
    topRight: localTextSchema,
  }),
});
export type ThemeSettingsInput = z.infer<typeof themeSettingsSchema>;

// --- session control (HTTP mirror, M04 §2.6) ------------------------------------

export const CONTROL_ACTIONS = [
  'start',
  'pause',
  'resume',
  'next',
  'reveal',
  'select',
  'lock',
  'end',
  'reset',
] as const;

export const controlActionSchema = z.object({
  action: z.enum(CONTROL_ACTIONS),
  payload: z.record(z.unknown()).optional(),
});
