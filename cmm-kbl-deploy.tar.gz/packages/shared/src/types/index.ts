import type {
  Difficulty,
  GamePhase,
  Language,
  LedLayout,
  LifelineType,
  OptionKey,
  Role,
  RotationMode,
  SessionStatus,
} from '../constants';

/** Bilingual text stored in the DB and resolved via ?lang= on reads (M03 §1) */
export interface LocalText {
  hi: string;
  en: string;
}

// ---------------------------------------------------------------------------
// REST DTOs
// ---------------------------------------------------------------------------

export interface UserPublic {
  id: string;
  name: string;
  email: string;
  role: Role;
  isActive: boolean;
  lastLoginAt?: string | null;
}

export interface CategoryDTO {
  id: string;
  name: LocalText;
  slug: string;
  color: string;
  sortOrder: number;
  questionCount?: number;
}

export interface QuestionOption {
  key: OptionKey;
  text: LocalText;
}

export interface QuestionMedia {
  kind: 'image' | 'video';
  assetId: string;
  url: string;
}

/** Admin-facing question (includes correctOption — NEVER sent to display) */
export interface QuestionDTO {
  id: string;
  code: string;
  text: LocalText;
  options: QuestionOption[];
  correctOption: OptionKey;
  category: CategoryDTO;
  difficulty: Difficulty;
  timerSeconds: number;
  points: number;
  explanation?: LocalText | null;
  media?: QuestionMedia | null;
  status: 'active' | 'inactive';
  createdAt?: string;
  updatedAt?: string;
}

export interface CategoryRefDTO {
  id: string;
  name: string;
  color: string;
}

/** List-row question after server-side lang resolution (M04 §1); editor detail uses QuestionDTO. */
export interface QuestionListItemDTO {
  id: string;
  code: string;
  text: string;
  options: { key: OptionKey; text: string }[];
  correctOption: OptionKey;
  category: CategoryRefDTO;
  difficulty: Difficulty;
  timerSeconds: number;
  points: number;
  status: 'active' | 'inactive';
  createdAt?: string;
  updatedAt?: string;
}

export interface ContestantDTO {
  id: string;
  name: string;
  mobile: string;
  city: string;
  avatarUrl?: string | null;
  score: number;
  isActive: boolean;
}

export interface LadderLevel {
  level: number;
  amount: number;
  isSafeHaven: boolean;
}

export interface SessionLifelineSettings {
  fiftyFifty: { enabled: boolean; perContestant: number };
  audiencePoll: { enabled: boolean; perContestant: number };
  expertCall: { enabled: boolean; perContestant: number; durationSeconds: number };
}

export interface SessionSummaryDTO {
  id: string;
  name: string;
  code: string;
  status: SessionStatus;
  totalQuestions: number;
  currentQuestionIndex: number;
  contestantIds: string[];
  startedAt?: string | null;
  endedAt?: string | null;
}

export interface DashboardStatsDTO {
  activeGame: {
    sessionId: string;
    name: string;
    code: string;
    phase: GamePhase;
    questionIndex: number;
    total: number;
  } | null;
  totalQuestions: number;
  categoryCount: number;
  contestants: { total: number; active: number };
  todaySessions: { live: number; completed: number };
}

export interface ThemeSettingsDTO {
  logoUrl?: string | null;
  brandPrimary: string;
  brandAccent: string;
  ledLayout: LedLayout;
  buzzerMode: boolean;
  defaultLanguage: Language;
  showHostIllustration: boolean;
  showReflection: boolean;
  slogans: { topLeft: LocalText; center: LocalText; topRight: LocalText };
}

// ---------------------------------------------------------------------------
// Realtime — GameView snapshot contract (docs/plans/06-realtime-engine.md §4)
// ---------------------------------------------------------------------------

export type LifelineResult =
  | { type: 'fifty_fifty'; removedKeys: OptionKey[] }
  | { type: 'audience_poll'; distribution: Record<OptionKey, number> }
  | {
      type: 'expert_call';
      durationSeconds: number;
      adviceText?: string;
      suggestedKey?: OptionKey;
    };

export interface GameViewQuestion {
  index: number;
  total: number;
  numberLabel: string;
  text: string;
  options: { key: OptionKey; text: string; visible: boolean }[];
  media?: { kind: 'image' | 'video'; url: string } | null;
  difficulty: Difficulty;
}

export interface GameViewTimer {
  durationMs: number;
  /** epoch ms — set while running; undefined while paused */
  endsAt?: number;
  remainingMs?: number;
}

export interface GameView {
  sessionId: string;
  code: string;
  name: string;
  phase: GamePhase;
  paused: boolean;
  language: Language;

  question: GameViewQuestion | null;
  timer: GameViewTimer | null;

  selectedOption?: OptionKey;
  lockedOption?: OptionKey;
  lockedBy?: { contestantId: string; name: string };

  /** Present ONLY in answer_revealed phase (sanitized away for display otherwise) */
  reveal?: {
    isCorrect: boolean;
    correctOption: OptionKey;
    explanation?: string;
    pointsAwarded: number;
  };

  activeContestant: { id: string; name: string } | null;
  contestants: { id: string; name: string; score: number; isActive: boolean }[];
  ladder: {
    levels: LadderLevel[];
    currentLevel: number;
    safeAmount: number;
  };

  lifelines: Record<LifelineType, number>;
  lifelineResult?: LifelineResult | null;

  theme: {
    logoUrl?: string | null;
    brandPrimary: string;
    brandAccent: string;
    ledLayout: LedLayout;
    slogans: { topLeft: string; center: string; topRight: string };
    showHostIllustration: boolean;
  };

  serverTime: number;
  version: number;
}

// ---------------------------------------------------------------------------
// Envelope & misc
// ---------------------------------------------------------------------------

export interface ApiSuccess<T> {
  ok: true;
  data: T;
}

export interface ApiFailure {
  ok: false;
  error: { code: string; message: string; details?: unknown };
}

export type ApiResponse<T> = ApiSuccess<T> | ApiFailure;

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
}

export interface StandingsEntry {
  contestantId: string;
  name: string;
  score: number;
  correctCount: number;
  avgResponseMs?: number | null;
}

export type {
  Difficulty,
  GamePhase,
  Language,
  LedLayout,
  LifelineType,
  OptionKey,
  Role,
  RotationMode,
  SessionStatus,
};
