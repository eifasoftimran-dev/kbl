import path from 'node:path';
import express, { type Application } from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import pinoHttp from 'pino-http';
import mongoose from 'mongoose';
import type { Request, Response } from 'express';
import { env } from './config/env';
import { logger } from './utils/logger';
import { requestId } from './middlewares/request-id';
import { errorHandler, notFoundHandler } from './middlewares/error';
import { authRouter } from './modules/auth/auth.routes';
import { dashboardRouter } from './modules/dashboard/dashboard.routes';
import { questionsRouter } from './modules/questions/question.routes';
import { contestantsRouter } from './modules/contestants/contestant.routes';
import { sessionsRouter } from './modules/sessions/session.routes';
import { usersRouter } from './modules/users/user.routes';
import { settingsRouter } from './modules/settings/settings.routes';
import { controlRouter } from './modules/control/control.routes';

/**
 * Express app factory (M04 §1): one place for middleware order,
 * so the HTTP server, tests, and future workers all boot identically.
 */
export function createApp(): Application {
  const app = express();

  app.disable('x-powered-by');
  app.use(helmet());
  app.use(
    cors({
      origin: env.WEB_ORIGIN.split(',').map((o) => o.trim()),
      credentials: true,
    }),
  );
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false, limit: '2mb' }));
  app.use(requestId);
  app.use(
    pinoHttp({
      logger,
      genReqId: (req) => (req as Request).id,
      redact: ['req.headers.authorization', 'req.headers.cookie'],
    }),
  );

  const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    limit: 300,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { ok: false, error: { code: 'RATE_LIMITED', message: 'Too many requests — slow down' } },
  });
  app.use('/api', apiLimiter);

  // Liveness/readiness probe — P0 exit criterion (M00 §4)
  app.get('/healthz', (_req: Request, res: Response) => {
    const dbUp = mongoose.connection.readyState === 1;
    res.status(dbUp ? 200 : 503).json({
      ok: dbUp,
      db: dbUp ? 'up' : 'down',
      uptimeSeconds: Math.floor(process.uptime()),
    });
  });

  // Public uploads (M11) — served before API routes so files bypass auth.
  app.use('/uploads', express.static(path.resolve(process.cwd(), env.UPLOAD_DIR), { index: false }));

  // API modules (P1 — REST catalog)
  app.use('/api/auth', authRouter);
  app.use('/api/dashboard', dashboardRouter);
  app.use('/api/questions', questionsRouter);
  app.use('/api/contestants', contestantsRouter);
  app.use('/api/sessions', sessionsRouter);
  app.use('/api/users', usersRouter);
  app.use('/api/settings', settingsRouter);
  app.use('/api/control', controlRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
