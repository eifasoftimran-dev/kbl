/**
 * Lifeline logic (M07 §6): 50:50, audience poll, expert call.
 * Pure functions — DB persistence is done by the runtime.
 */
import type { Difficulty, LifelineResult, OptionKey } from '@cmm/shared';

/**
 * 50:50 — pick 2 random WRONG keys to hide (never the correct one).
 * Returns the removed keys.
 */
export function computeFiftyFifty(correctOption: OptionKey, seed?: number): OptionKey[] {
  const allKeys: OptionKey[] = ['A', 'B', 'C', 'D'];
  const wrongKeys = allKeys.filter((k) => k !== correctOption);

  // Shuffle with seed for audit reproducibility
  const rng = seededRandom(seed ?? Date.now());
  const shuffled = shuffleArray(wrongKeys, rng);

  // Pick first 2 wrong keys to remove
  return shuffled.slice(0, 2);
}

/**
 * Audience poll — simulated distribution (M07 §6.2).
 * Correct-option weight by difficulty; remaining split among visible wrong options.
 */
export function computeAudiencePoll(
  correctOption: OptionKey,
  difficulty: Difficulty,
  eliminatedOptions: OptionKey[] = [],
): LifelineResult {
  // Base weight for correct option by difficulty
  const baseWeights: Record<Difficulty, number> = {
    easy: 0.7,
    medium: 0.55,
    hard: 0.4,
  };
  const noise: Record<Difficulty, number> = {
    easy: 0.1,
    medium: 0.1,
    hard: 0.12,
  };

  const correctWeight = Math.max(0.1, baseWeights[difficulty] + (Math.random() * 2 - 1) * noise[difficulty]);

  const allKeys: OptionKey[] = ['A', 'B', 'C', 'D'];
  const visibleKeys = allKeys.filter((k) => !eliminatedOptions.includes(k));
  const wrongVisible = visibleKeys.filter((k) => k !== correctOption);

  const remaining = 1 - correctWeight;
  const wrongWeight = wrongVisible.length > 0 ? remaining / wrongVisible.length : 0;

  const distribution: Record<OptionKey, number> = { A: 0, B: 0, C: 0, D: 0 };
  for (const key of visibleKeys) {
    if (key === correctOption) {
      distribution[key] = Math.round(correctWeight * 100);
    } else {
      // Add some noise to each wrong option
      const noisyWeight = Math.max(0.02, wrongWeight + (Math.random() * 2 - 1) * 0.05);
      distribution[key] = Math.round(noisyWeight * 100);
    }
  }

  // Normalize to 100%
  const total = Object.values(distribution).reduce((a, b) => a + b, 0);
  if (total !== 100) {
    const diff = 100 - total;
    distribution[correctOption] += diff;
  }

  return { type: 'audience_poll', distribution };
}

/**
 * Expert call — mostly presentational (M07 §6.3).
 */
export function computeExpertCall(durationSeconds: number): LifelineResult {
  return {
    type: 'expert_call',
    durationSeconds,
    // suggestedKey is intentionally omitted — the host conveys it verbally
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function shuffleArray<T>(arr: T[], rng: () => number): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
