/**
 * Global 250ms ticker for all live sessions (M06 §5, M07 §5).
 * Single interval — not per-session. Calls runtime.onTick() for each active session.
 */
import { logger } from '../../utils/logger';
import { runtimeRegistry } from './game-session-runtime';

const TICK_INTERVAL_MS = 250;

let tickerInterval: ReturnType<typeof setInterval> | null = null;

export function startTicker(): void {
  if (tickerInterval) return;

  tickerInterval = setInterval(() => {
    const now = Date.now();
    const runtimes = runtimeRegistry.activeRuntimes();

    for (const rt of runtimes) {
      rt.onTick(now).catch((err) => {
        logger.error({ err, sessionId: rt.sessionId }, 'Ticker onTick failed');
      });
    }
  }, TICK_INTERVAL_MS);

  logger.info(`Game ticker started (${TICK_INTERVAL_MS}ms interval)`);
}

export function stopTicker(): void {
  if (tickerInterval) {
    clearInterval(tickerInterval);
    tickerInterval = null;
    logger.info('Game ticker stopped');
  }
}
