/**
 * GameSessionRuntime — one instance per live session (M07 §1).
 * Owns the RuntimeState, processes dispatch() results, persists to DB,
 * and triggers broadcasts via the supplied callback.
 */
import type { Server as SocketIOServer } from 'socket.io';
import type {
  GameView,
  Language,
  LifelineResult,
  LifelineType,
  OptionKey,
} from '@cmm/shared';
import { Question } from '../../modules/questions/question.model';
import { Contestant } from '../../modules/contestants/contestant.model';
import { GameSession, type SessionDoc } from '../../modules/sessions/session.model';
import { QuestionAttempt } from '../../modules/sessions/attempt.model';
import { LifelineUsage } from '../../modules/sessions/lifeline-usage.model';
import { PrizeLadderConfig, DEFAULT_LADDER_LEVELS } from '../../modules/sessions/ladder-config.model';
import { ThemeSetting } from '../../modules/settings/theme-setting.model';
import { logAudit } from '../../modules/audit/audit.service';
import { logger } from '../../utils/logger';
import {
  dispatch,
  buildGameView,
  sanitizeForDisplay,
  type RuntimeState,
  type GameAction,
  type Effect,
  type EmbeddedQuestion,
  type TransitionResult,
  type StandingsRow,
} from './state-machine';
import { computeFiftyFifty, computeAudiencePoll, computeExpertCall } from './lifelines';

export class GameSessionRuntime {
  private state: RuntimeState;
  private sessionDoc: SessionDoc | null = null;
  private scheduledTimers: Map<string, ReturnType<typeof setTimeout>> = new Map();
  private contestantNames: Record<string, string> = {};
  private themeData: GameView['theme'] = {
    brandPrimary: '#1E5BFF',
    brandAccent: '#FFC93C',
    ledLayout: 'classic',
    slogans: { topLeft: '', center: '', topRight: '' },
    showHostIllustration: false,
  };
  private totalQuestions = 0;

  constructor(
    readonly sessionId: string,
    private io: SocketIOServer,
  ) {
    this.state = this.createBlankState(sessionId);
  }

  // -----------------------------------------------------------------------
  // Lifecycle
  // -----------------------------------------------------------------------

  /** Load session data from DB and initialize the runtime state. */
  async hydrate(): Promise<void> {
    const session = await GameSession.findById(this.sessionId).lean().exec();
    if (!session) throw new Error(`Session ${this.sessionId} not found`);
    this.sessionDoc = session as SessionDoc;

    // Load contestants
    const contestants = await Contestant.find({
      _id: { $in: session.contestantOrder },
    })
      .select('name')
      .lean()
      .exec();
    for (const c of contestants) {
      this.contestantNames[String(c._id)] = c.name;
    }

    // Load ladder
    let ladderLevels = DEFAULT_LADDER_LEVELS.map((l) => ({ ...l }));
    if (session.ladderConfigId) {
      const ladderConfig = await PrizeLadderConfig.findById(session.ladderConfigId).lean().exec();
      if (ladderConfig?.levels) {
        ladderLevels = ladderConfig.levels.map((l) => ({
          level: l.level,
          amount: l.amount,
          isSafeHaven: l.isSafeHaven,
        }));
      }
    }

    // Load theme
    const theme = await ThemeSetting.findOne({ key: 'global' }).lean().exec();
    if (theme) {
      this.themeData = {
        logoUrl: null,
        brandPrimary: theme.brandPrimary,
        brandAccent: theme.brandAccent,
        ledLayout: theme.ledLayout,
        slogans: {
          topLeft: theme.slogans.topLeft.hi,
          center: theme.slogans.center.hi,
          topRight: theme.slogans.topRight.hi,
        },
        showHostIllustration: theme.showHostIllustration,
      };
    }

    this.totalQuestions = session.questionIds.length;

    // Initialize scores
    const scores: Record<string, number> = {};
    const correctCounts: Record<string, number> = {};
    const ladderLevel: Record<string, number> = {};
    for (const cid of session.contestantOrder.map(String)) {
      scores[cid] = 0;
      correctCounts[cid] = 0;
      ladderLevel[cid] = 0;
    }

    // Rehydrate from snapshot if available
    const snapshot = session.stateSnapshot as Partial<RuntimeState> | null;
    if (snapshot && snapshot.phase && snapshot.phase !== 'idle') {
      this.state = { ...this.state, ...snapshot } as RuntimeState;
      // Restore contestant names in case they changed
      this.state.contestantOrder = session.contestantOrder.map(String);
      this.state.scores = scores;
      this.state.correctCounts = correctCounts;
      this.state.ladderLevel = ladderLevel;
    } else {
      this.state = this.createBlankState(this.sessionId);
      this.state.contestantOrder = session.contestantOrder.map(String);
      this.state.scores = scores;
      this.state.correctCounts = correctCounts;
      this.state.ladderLevel = ladderLevel;
      this.state.rotationMode = session.rotationMode;
      this.state.dramaSeconds = session.settings.dramaSeconds;
      this.state.onTimeout = session.settings.onTimeout;
      this.state.ladderLevels = ladderLevels;
    }

    // Load embedded question for current index
    if (this.state.questionIndex >= 0 && this.state.questionIndex < session.questionIds.length) {
      await this.loadQuestion(this.state.questionIndex);
    }
  }

  /** Main entry point — dispatch an action and process effects. */
  async dispatchAction(action: GameAction): Promise<TransitionResult> {
    const result = dispatch(this.state, action);
    if (!result.ok) return result;

    await this.processEffects(result.effects);
    return result;
  }

  /** Called by the global ticker every 250ms. */
  async onTick(now: number): Promise<void> {
    // Check timer expiry for question_active
    if (
      this.state.phase === 'question_active' &&
      !this.state.paused &&
      this.state.timer?.endsAt &&
      this.state.timer.endsAt <= now
    ) {
      await this.dispatchAction({ type: 'timeout' });
      return;
    }

    // Check suspense expiry
    if (
      this.state.phase === 'reveal_suspense' &&
      this.state.suspenseEndsAt &&
      this.state.suspenseEndsAt <= now
    ) {
      await this.dispatchAction({ type: 'suspense_expired' });
    }
  }

  /** Get the current GameView (admin version). */
  async getGameView(): Promise<GameView> {
    const view = buildGameView(this.state, this.contestantNames, this.themeData);
    view.code = this.sessionDoc?.code ?? '';
    view.name = this.sessionDoc?.name ?? '';
    if (view.question) {
      view.question.total = this.totalQuestions;
    }

    // Fill lifeline counts
    await this.fillLifelineCounts(view);

    return view;
  }

  /** Get sanitized GameView for display clients. */
  async getDisplayView(): Promise<GameView> {
    const view = await this.getGameView();
    return sanitizeForDisplay(view);
  }

  getState(): Readonly<RuntimeState> {
    return this.state;
  }

  /** Whether a question exists at the given index (for the "next" guard). */
  hasQuestion(index: number): boolean {
    return index >= 0 && index < this.totalQuestions;
  }

  /** Force an immediate state broadcast (e.g. after external mutation like lifelines). */
  async broadcastNow(): Promise<void> {
    await this.broadcastState();
  }

  isActive(): boolean {
    return this.state.phase !== 'idle' && this.state.phase !== 'game_over';
  }

  /** Clean up timers on session end. */
  dispose(): void {
    for (const timer of this.scheduledTimers.values()) {
      clearTimeout(timer);
    }
    this.scheduledTimers.clear();
  }

  // -----------------------------------------------------------------------
  // Effect processing
  // -----------------------------------------------------------------------

  private async processEffects(effects: Effect[]): Promise<void> {
    for (const effect of effects) {
      switch (effect.type) {
        case 'broadcast':
          await this.broadcastState();
          break;

        case 'schedule_intro_expiry':
          this.scheduleTimer('intro', effect.delayMs, async () => {
            await this.dispatchAction({ type: 'intro_expired' });
          });
          break;

        case 'schedule_suspense_expiry':
          this.scheduleTimer('suspense', effect.endsAt - Date.now(), async () => {
            await this.dispatchAction({ type: 'suspense_expired' });
          });
          break;

        case 'arm_timer':
          // Timer is tracked in state; the global ticker handles expiry
          break;

        case 'clear_timer':
          this.clearScheduledTimer('intro');
          this.clearScheduledTimer('suspense');
          break;

        case 'pause_timer':
        case 'resume_timer':
          // Handled by state mutation; global ticker checks paused flag
          break;

        case 'persist_attempt': {
          const session = this.sessionDoc;
          if (session && session.questionIds[effect.attempt.questionIndex]) {
            await QuestionAttempt.create({
              sessionId: this.sessionId,
              questionId: session.questionIds[effect.attempt.questionIndex],
              questionIndex: effect.attempt.questionIndex,
              contestantId: effect.attempt.contestantId,
              selectedOption: effect.attempt.selectedOption,
              isCorrect: effect.attempt.isCorrect,
              pointsAwarded: effect.attempt.pointsAwarded,
              responseMs: effect.attempt.responseMs,
              lifelinesUsed: effect.attempt.lifelinesUsed,
              lockedAt: effect.attempt.responseMs != null ? new Date() : null,
            });
          }
          break;
        }

        case 'persist_session':
          await GameSession.findByIdAndUpdate(this.sessionId, effect.patch).exec();
          break;

        case 'update_contestant_score':
          await Contestant.findByIdAndUpdate(effect.contestantId, { score: effect.score }).exec();
          break;

        case 'emit_reveal_effect':
          this.io.to(`session:${this.sessionId}:admin`).emit('reveal:effect', {
            sessionId: this.sessionId,
            effect: effect.effect,
            correctOption: effect.correctOption,
          });
          this.io.to(`session:${this.sessionId}:display`).emit('reveal:effect', {
            sessionId: this.sessionId,
            effect: effect.effect,
            correctOption: effect.effect !== 'suspense_start' ? effect.correctOption : undefined,
          });
          break;

        case 'emit_lifeline_result':
          this.io.to(`session:${this.sessionId}:admin`).emit('lifeline:result', {
            sessionId: this.sessionId,
            ...effect.result,
          });
          this.io.to(`session:${this.sessionId}:display`).emit('lifeline:result', {
            sessionId: this.sessionId,
            ...effect.result,
          });
          break;

        case 'emit_session_ended':
          // Fill names
          const standings = effect.standings.map((s) => ({
            ...s,
            name: this.contestantNames[s.contestantId] ?? s.contestantId,
          }));
          this.io.to(`session:${this.sessionId}:admin`).emit('session:ended', {
            sessionId: this.sessionId,
            standings,
          });
          this.io.to(`session:${this.sessionId}:display`).emit('session:ended', {
            sessionId: this.sessionId,
            standings,
          });
          break;

        case 'audit':
          logAudit({
            action: effect.action,
            targetType: 'GameSession',
            targetId: this.sessionId,
            payload: effect.payload,
          });
          break;
      }
    }
  }

  // -----------------------------------------------------------------------
  // Question loading
  // -----------------------------------------------------------------------

  async loadQuestion(index: number): Promise<void> {
    if (!this.sessionDoc) return;
    const questionId = this.sessionDoc.questionIds[index];
    if (!questionId) return;

    const q = await Question.findById(questionId).lean().exec();
    if (!q) {
      logger.error({ questionId, index }, 'Question not found for session');
      return;
    }

    // Determine language
    const lang: Language = this.state.language || 'hi';

    const embedded: EmbeddedQuestion = {
      text: q.text[lang],
      options: q.options.map((o) => ({
        key: o.key,
        text: o.text[lang],
      })),
      correctOption: q.correctOption,
      timerSeconds: q.timerSeconds,
      points: q.points,
      difficulty: q.difficulty,
      explanation: q.explanation?.[lang],
      media:
        q.media.kind !== 'none' && q.media.assetId
          ? { kind: q.media.kind as 'image' | 'video', url: `/uploads/${String(q.media.assetId)}` }
          : null,
    };

    this.state.embeddedQuestion = embedded;
    this.state.eliminatedOptions = [];
    this.state.selectedOption = null;
    this.state.lockedOption = null;
    this.state.lockedAt = null;
    this.state.reveal = undefined;
    this.state.lastLifelineResult = null;
  }

  // -----------------------------------------------------------------------
  // Lifeline processing
  // -----------------------------------------------------------------------

  async processLifeline(lifelineType: LifelineType): Promise<LifelineResult | null> {
    const eq = this.state.embeddedQuestion;
    if (!eq) return null;

    const contestantId = this.state.activeContestantId;
    if (!contestantId) return null;

    let result: LifelineResult;

    switch (lifelineType) {
      case 'fifty_fifty': {
        const removedKeys = computeFiftyFifty(eq.correctOption);
        this.state.eliminatedOptions = removedKeys;
        result = { type: 'fifty_fifty', removedKeys };
        break;
      }
      case 'audience_poll': {
        result = computeAudiencePoll(eq.correctOption, eq.difficulty, this.state.eliminatedOptions);
        break;
      }
      case 'expert_call': {
        const duration = this.sessionDoc?.settings.lifelines.expertCall.durationSeconds ?? 30;
        result = computeExpertCall(duration);
        break;
      }
      default:
        return null;
    }

    this.state.lastLifelineResult = result;
    this.state.version++; // clients use a version guard — bump so the re-broadcast is accepted

    // Persist lifeline usage
    await LifelineUsage.create({
      sessionId: this.sessionId,
      contestantId,
      questionIndex: this.state.questionIndex,
      type: lifelineType,
      resultData: result as unknown as Record<string, unknown>,
    });

    return result;
  }

  // -----------------------------------------------------------------------
  // Helpers
  // -----------------------------------------------------------------------

  private createBlankState(sessionId: string): RuntimeState {
    return {
      sessionId,
      phase: 'idle',
      paused: false,
      questionIndex: -1,
      embeddedQuestion: null,
      timer: null,
      activeContestantId: null,
      contestantOrder: [],
      scores: {},
      correctCounts: {},
      ladderLevel: {},
      lifelineUses: {},
      eliminatedOptions: [],
      rotationMode: 'round_robin',
      dramaSeconds: 2.5,
      onTimeout: 'reveal_wrong',
      language: 'hi',
      ladderLevels: DEFAULT_LADDER_LEVELS.map((l) => ({ ...l })),
      version: 0,
    };
  }

  private async broadcastState(): Promise<void> {
    try {
      const adminView = await this.getGameView();
      const displayView = sanitizeForDisplay(adminView);

      this.io.to(`session:${this.sessionId}:admin`).emit('state:changed', adminView);
      this.io.to(`session:${this.sessionId}:display`).emit('state:changed', displayView);

      // Persist snapshot for rehydration
      await GameSession.findByIdAndUpdate(this.sessionId, {
        stateSnapshot: this.state,
      }).exec();
    } catch (err) {
      logger.error({ err, sessionId: this.sessionId }, 'broadcastState failed');
    }
  }

  private async fillLifelineCounts(view: GameView): Promise<void> {
    if (!this.sessionDoc || !this.state.activeContestantId) return;
    const settings = this.sessionDoc.settings.lifelines;
    const cid = this.state.activeContestantId;

    const uses = await LifelineUsage.find({
      sessionId: this.sessionId,
      contestantId: cid,
    })
      .select('type')
      .lean()
      .exec();

    const usedCounts: Record<LifelineType, number> = { fifty_fifty: 0, audience_poll: 0, expert_call: 0 };
    for (const u of uses) {
      usedCounts[u.type]++;
    }

    view.lifelines = {
      fifty_fifty: Math.max(0, settings.fiftyFifty.perContestant - usedCounts.fifty_fifty),
      audience_poll: Math.max(0, settings.audiencePoll.perContestant - usedCounts.audience_poll),
      expert_call: Math.max(0, settings.expertCall.perContestant - usedCounts.expert_call),
    };
  }

  private scheduleTimer(key: string, delayMs: number, fn: () => Promise<void>): void {
    this.clearScheduledTimer(key);
    const timer = setTimeout(() => {
      this.scheduledTimers.delete(key);
      fn().catch((err) => logger.error({ err }, `Scheduled timer '${key}' failed`));
    }, Math.max(0, delayMs));
    this.scheduledTimers.set(key, timer);
  }

  private clearScheduledTimer(key: string): void {
    const existing = this.scheduledTimers.get(key);
    if (existing) {
      clearTimeout(existing);
      this.scheduledTimers.delete(key);
    }
  }
}

// ---------------------------------------------------------------------------
// RuntimeRegistry — singleton map of all live runtimes
// ---------------------------------------------------------------------------

class RuntimeRegistry {
  private runtimes = new Map<string, GameSessionRuntime>();

  get(sessionId: string): GameSessionRuntime | undefined {
    return this.runtimes.get(sessionId);
  }

  async getOrCreate(sessionId: string, io: SocketIOServer): Promise<GameSessionRuntime> {
    let rt = this.runtimes.get(sessionId);
    if (!rt) {
      rt = new GameSessionRuntime(sessionId, io);
      await rt.hydrate();
      this.runtimes.set(sessionId, rt);
    }
    return rt;
  }

  remove(sessionId: string): void {
    const rt = this.runtimes.get(sessionId);
    if (rt) {
      rt.dispose();
      this.runtimes.delete(sessionId);
    }
  }

  /** All active runtimes (for the global ticker). */
  activeRuntimes(): GameSessionRuntime[] {
    return [...this.runtimes.values()].filter((rt) => rt.isActive());
  }

  /** Rehydrate all live/paused sessions on server boot. */
  async rehydrateAll(io: SocketIOServer): Promise<void> {
    const sessions = await GameSession.find({
      status: { $in: ['live', 'paused'] },
    })
      .select('_id')
      .lean()
      .exec();

    for (const s of sessions) {
      try {
        await this.getOrCreate(String(s._id), io);
        logger.info({ sessionId: String(s._id) }, 'Rehydrated live session');
      } catch (err) {
        logger.error({ err, sessionId: String(s._id) }, 'Failed to rehydrate session');
      }
    }
  }
}

export const runtimeRegistry = new RuntimeRegistry();
