/**
 * Pure game-phase transition logic (M07 §2–§3).
 * No DB imports — all persistence is injected so this stays unit-testable.
 */
import type {
  Difficulty,
  GamePhase,
  GameView,
  Language,
  LadderLevel,
  LifelineResult,
  LifelineType,
  OptionKey,
  RotationMode,
} from '@cmm/shared';
import { QUESTION_INTRO_MS } from '@cmm/shared';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface EmbeddedQuestion {
  text: string;
  options: { key: OptionKey; text: string }[];
  correctOption: OptionKey;
  timerSeconds: number;
  points: number;
  difficulty: Difficulty;
  explanation?: string;
  media?: { kind: 'image' | 'video'; url: string } | null;
}

export interface RuntimeState {
  sessionId: string;
  phase: GamePhase;
  paused: boolean;
  pausedFrom?: GamePhase;
  questionIndex: number; // -1 in lobby/idle
  embeddedQuestion: EmbeddedQuestion | null;
  selectedOption?: OptionKey | null;
  lockedOption?: OptionKey | null;
  lockedAt?: number | null;
  questionStartedAt?: number | null;
  timer: { durationMs: number; endsAt?: number; remainingMs?: number } | null;
  activeContestantId: string | null;
  contestantOrder: string[];
  scores: Record<string, number>;
  correctCounts: Record<string, number>;
  ladderLevel: Record<string, number>;
  lifelineUses: Record<string, number>; // key: `${contestantId}:${type}`
  eliminatedOptions: OptionKey[];
  lastLifelineResult?: LifelineResult | null;
  reveal?: {
    isCorrect: boolean;
    correctOption: OptionKey;
    explanation?: string;
    pointsAwarded: number;
  } | null;
  suspenseEndsAt?: number | null;
  rotationMode: RotationMode;
  dramaSeconds: number;
  onTimeout: 'reveal_wrong' | 'pause_for_host';
  language: Language;
  ladderLevels: LadderLevel[];
  version: number;
}

export type GameAction =
  | { type: 'start'; actorId: string }
  | { type: 'select'; optionKey: OptionKey; actorId: string }
  | { type: 'lock'; actorId: string }
  | { type: 'reveal'; actorId: string }
  | { type: 'next'; actorId: string }
  | { type: 'pause'; actorId: string }
  | { type: 'resume'; actorId: string }
  | { type: 'end'; actorId: string }
  | { type: 'reset'; confirm: boolean; wipeAttempts?: boolean; actorId: string }
  | { type: 'contestant_turn'; contestantId: string; actorId: string }
  | { type: 'lifeline_use'; lifelineType: LifelineType; actorId: string }
  | { type: 'timeout' }
  | { type: 'intro_expired' }
  | { type: 'suspense_expired' }
  | {
      type: 'override';
      patch: {
        activeContestantId?: string;
        selectedOption?: OptionKey;
        dramaSeconds?: number;
        timerRemainingMs?: number;
      };
      actorId: string;
    };

export interface TransitionResult {
  ok: boolean;
  error?: { code: string; message: string };
  /** side-effects the runtime should execute AFTER the mutation */
  effects: Effect[];
}

export type Effect =
  | { type: 'broadcast' }
  | { type: 'schedule_intro_expiry'; delayMs: number }
  | { type: 'schedule_suspense_expiry'; endsAt: number }
  | { type: 'arm_timer'; endsAt: number }
  | { type: 'clear_timer' }
  | { type: 'pause_timer'; remainingMs: number }
  | { type: 'resume_timer'; endsAt: number }
  | { type: 'persist_attempt'; attempt: AttemptPersist }
  | { type: 'persist_session'; patch: Record<string, unknown> }
  | { type: 'update_contestant_score'; contestantId: string; score: number }
  | { type: 'emit_reveal_effect'; effect: 'suspense_start' | 'suspense_end' | 'correct' | 'wrong'; correctOption?: OptionKey }
  | { type: 'emit_lifeline_result'; result: LifelineResult }
  | { type: 'emit_session_ended'; standings: StandingsRow[] }
  | { type: 'audit'; action: string; payload?: Record<string, unknown> };

export interface AttemptPersist {
  sessionId: string;
  questionId?: string;
  questionIndex: number;
  contestantId: string;
  selectedOption: OptionKey | null;
  isCorrect: boolean;
  pointsAwarded: number;
  responseMs: number | null;
  lifelinesUsed: LifelineType[];
}

export interface StandingsRow {
  contestantId: string;
  name: string;
  score: number;
  correctCount: number;
  avgResponseMs: number | null;
}

// ---------------------------------------------------------------------------
// Transition function — pure, deterministic
// ---------------------------------------------------------------------------

export function dispatch(state: RuntimeState, action: GameAction): TransitionResult {
  switch (action.type) {
    case 'start':
      return handleStart(state, action);
    case 'select':
      return handleSelect(state, action);
    case 'lock':
      return handleLock(state, action);
    case 'reveal':
      return handleReveal(state, action);
    case 'next':
      return handleNext(state, action);
    case 'pause':
      return handlePause(state, action);
    case 'resume':
      return handleResume(state, action);
    case 'end':
      return handleEnd(state, action);
    case 'reset':
      return handleReset(state, action);
    case 'contestant_turn':
      return handleContestantTurn(state, action);
    case 'lifeline_use':
      return handleLifelineUse(state, action);
    case 'timeout':
      return handleTimeout(state);
    case 'intro_expired':
      return handleIntroExpired(state);
    case 'suspense_expired':
      return handleSuspenseExpired(state);
    case 'override':
      return handleOverride(state, action);
    default:
      return { ok: false, error: { code: 'UNKNOWN_ACTION', message: `Unknown action: ${(action as { type: string }).type}` }, effects: [] };
  }
}

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

function invalidState(msg: string): TransitionResult {
  return { ok: false, error: { code: 'INVALID_STATE', message: msg }, effects: [] };
}

/** T1: idle → question_intro (first question) */
function handleStart(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (state.phase !== 'idle') return invalidState('Can only start from idle phase');

  const effects: Effect[] = [];
  state.phase = 'question_intro';
  state.questionIndex = 0;
  state.version++;

  // Set first active contestant
  if (state.contestantOrder.length > 0) {
    state.activeContestantId = state.contestantOrder[0];
  }

  // Load first question (will be injected by runtime before broadcast)
  effects.push({ type: 'audit', action: 'session.start', payload: { actorId: action.actorId } });
  effects.push({ type: 'schedule_intro_expiry', delayMs: QUESTION_INTRO_MS });
  effects.push({ type: 'broadcast' });
  effects.push({
    type: 'persist_session',
    patch: { status: 'live', startedAt: new Date(), currentQuestionIndex: 0, activeContestantId: state.activeContestantId },
  });

  return { ok: true, effects };
}

/** T2: question_intro → question_active (auto after 1.5s) */
function handleIntroExpired(state: RuntimeState): TransitionResult {
  if (state.phase !== 'question_intro') return invalidState('Not in question_intro');
  if (state.paused) return invalidState('Cannot transition while paused');

  const now = Date.now();
  const durationMs = (state.embeddedQuestion?.timerSeconds ?? 30) * 1000;
  const endsAt = now + durationMs;

  state.phase = 'question_active';
  state.timer = { durationMs, endsAt };
  state.questionStartedAt = now;
  state.version++;

  return { ok: true, effects: [{ type: 'arm_timer', endsAt }, { type: 'broadcast' }] };
}

/** T3: question_active → answer_selected */
function handleSelect(state: RuntimeState, action: { optionKey: OptionKey; actorId: string }): TransitionResult {
  if (state.phase !== 'question_active') return invalidState('Can only select in question_active');
  if (state.eliminatedOptions.includes(action.optionKey)) {
    return invalidState(`Option ${action.optionKey} was eliminated by 50:50`);
  }

  state.selectedOption = action.optionKey;
  state.phase = 'answer_selected';
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'broadcast' },
      { type: 'audit', action: 'game.select', payload: { optionKey: action.optionKey, actorId: action.actorId } },
    ],
  };
}

/** T4: question_active | answer_selected → answer_locked */
function handleLock(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (state.phase !== 'question_active' && state.phase !== 'answer_selected') {
    return invalidState('Can only lock from question_active or answer_selected');
  }

  const now = Date.now();
  state.lockedOption = state.selectedOption ?? null;
  state.lockedAt = now;
  state.phase = 'answer_locked';
  state.version++;

  // Stop timer
  const responseMs = state.questionStartedAt ? now - state.questionStartedAt : null;
  if (state.timer) {
    state.timer.endsAt = undefined;
    state.timer.remainingMs = undefined;
  }

  return {
    ok: true,
    effects: [
      { type: 'clear_timer' },
      { type: 'broadcast' },
      { type: 'audit', action: 'game.lock', payload: { lockedOption: state.lockedOption, responseMs, actorId: action.actorId } },
    ],
  };
}

/** T6: answer_locked → reveal_suspense */
function handleReveal(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (state.phase !== 'answer_locked' && state.phase !== 'answer_selected' && state.phase !== 'question_active') {
    return invalidState('Can only reveal from answer_locked, answer_selected, or question_active');
  }

  // If locking is needed first (from question_active or answer_selected)
  if (state.phase === 'question_active' || state.phase === 'answer_selected') {
    state.lockedOption = state.selectedOption ?? null;
    state.lockedAt = Date.now();
    if (state.timer) {
      state.timer.endsAt = undefined;
      state.timer.remainingMs = undefined;
    }
  }

  state.phase = 'reveal_suspense';
  const suspenseEndsAt = Date.now() + state.dramaSeconds * 1000;
  state.suspenseEndsAt = suspenseEndsAt;
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'clear_timer' },
      { type: 'schedule_suspense_expiry', endsAt: suspenseEndsAt },
      { type: 'emit_reveal_effect', effect: 'suspense_start' },
      { type: 'broadcast' },
      { type: 'audit', action: 'game.reveal', payload: { actorId: action.actorId } },
    ],
  };
}

/** T7: reveal_suspense → answer_revealed (auto after dramaSeconds) */
function handleSuspenseExpired(state: RuntimeState): TransitionResult {
  if (state.phase !== 'reveal_suspense') return invalidState('Not in reveal_suspense');

  const eq = state.embeddedQuestion!;
  const isCorrect = state.lockedOption === eq.correctOption;
  const pointsAwarded = isCorrect ? eq.points : 0;
  const contestantId = state.activeContestantId!;

  // Update scores
  if (isCorrect) {
    state.scores[contestantId] = (state.scores[contestantId] ?? 0) + pointsAwarded;
    state.correctCounts[contestantId] = (state.correctCounts[contestantId] ?? 0) + 1;
    state.ladderLevel[contestantId] = (state.ladderLevel[contestantId] ?? 0) + 1;
  }

  state.reveal = {
    isCorrect,
    correctOption: eq.correctOption,
    explanation: eq.explanation,
    pointsAwarded,
  };
  state.phase = 'answer_revealed';
  state.version++;

  const responseMs = state.lockedAt && state.questionStartedAt ? state.lockedAt - state.questionStartedAt : null;

  // Collect lifelines used this question by this contestant
  const lifelinesUsed: LifelineType[] = [];
  for (const lt of ['fifty_fifty', 'audience_poll', 'expert_call'] as LifelineType[]) {
    const key = `${contestantId}:${lt}`;
    if (state.lifelineUses[key] && state.lifelineUses[key] > 0) {
      lifelinesUsed.push(lt);
    }
  }

  const effects: Effect[] = [
    { type: 'clear_timer' },
    {
      type: 'persist_attempt',
      attempt: {
        sessionId: state.sessionId,
        questionIndex: state.questionIndex,
        contestantId,
        selectedOption: state.lockedOption ?? null,
        isCorrect,
        pointsAwarded,
        responseMs,
        lifelinesUsed,
      },
    },
    { type: 'emit_reveal_effect', effect: isCorrect ? 'correct' : 'wrong', correctOption: eq.correctOption },
    { type: 'update_contestant_score', contestantId, score: state.scores[contestantId] ?? 0 },
    { type: 'broadcast' },
  ];

  return { ok: true, effects };
}

/** T5: timeout — question_active without selection */
function handleTimeout(state: RuntimeState): TransitionResult {
  if (state.phase !== 'question_active') return invalidState('Timeout only in question_active');

  // Auto-lock with no selection
  state.lockedOption = null;
  state.lockedAt = Date.now();

  if (state.onTimeout === 'pause_for_host') {
    state.paused = true;
    state.pausedFrom = 'question_active';
    state.version++;
    return {
      ok: true,
      effects: [
        { type: 'clear_timer' },
        { type: 'broadcast' },
        { type: 'audit', action: 'game.timeout_pause' },
      ],
    };
  }

  // reveal_wrong path: go to suspense → reveal
  state.phase = 'reveal_suspense';
  const suspenseEndsAt = Date.now() + state.dramaSeconds * 1000;
  state.suspenseEndsAt = suspenseEndsAt;
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'clear_timer' },
      { type: 'schedule_suspense_expiry', endsAt: suspenseEndsAt },
      { type: 'emit_reveal_effect', effect: 'suspense_start' },
      { type: 'broadcast' },
      { type: 'audit', action: 'game.timeout' },
    ],
  };
}

/** T8: answer_revealed → question_intro (next) or game_over */
function handleNext(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (state.phase !== 'answer_revealed') return invalidState('Can only advance from answer_revealed');

  const nextIndex = state.questionIndex + 1;
  const wasCorrect = state.reveal?.isCorrect ?? false;

  // Check if we have more questions
  // The runtime will set embeddedQuestion; here we just check the index
  state.selectedOption = null;
  state.lockedOption = null;
  state.lockedAt = null;
  state.questionStartedAt = null;
  state.timer = null;
  state.eliminatedOptions = [];
  state.lastLifelineResult = null;
  state.reveal = undefined;
  state.suspenseEndsAt = null;

  // Rotate contestant
  if (state.contestantOrder.length > 0) {
    const currentIdx = state.contestantOrder.indexOf(state.activeContestantId!);
    if (state.rotationMode === 'round_robin') {
      state.activeContestantId = state.contestantOrder[(currentIdx + 1) % state.contestantOrder.length];
    }
    // 'streak' mode: keep same contestant unless they got it wrong
    if (state.rotationMode === 'streak' && !wasCorrect) {
      state.activeContestantId = state.contestantOrder[(currentIdx + 1) % state.contestantOrder.length];
    }
  }

  state.questionIndex = nextIndex;
  state.phase = 'question_intro';
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'schedule_intro_expiry', delayMs: QUESTION_INTRO_MS },
      { type: 'broadcast' },
      {
        type: 'persist_session',
        patch: { currentQuestionIndex: nextIndex, activeContestantId: state.activeContestantId },
      },
      { type: 'audit', action: 'game.next', payload: { questionIndex: nextIndex, actorId: action.actorId } },
    ],
  };
}

/** T9: any → game_over */
function handleEnd(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (state.phase === 'idle' || state.phase === 'game_over') {
    return invalidState('Cannot end a session that is not live');
  }

  const standings = computeStandings(state);
  state.phase = 'game_over';
  state.timer = null;
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'clear_timer' },
      { type: 'emit_session_ended', standings },
      { type: 'broadcast' },
      {
        type: 'persist_session',
        patch: { status: 'completed', endedAt: new Date() },
      },
      { type: 'audit', action: 'session.end', payload: { actorId: action.actorId, standings } },
    ],
  };
}

/** T12: reset → idle */
function handleReset(
  state: RuntimeState,
  action: { confirm: boolean; wipeAttempts?: boolean; actorId: string },
): TransitionResult {
  if (!action.confirm) return invalidState('Reset requires confirm: true');
  if (state.phase === 'idle') return invalidState('Already idle');

  state.phase = 'idle';
  state.paused = false;
  state.pausedFrom = undefined;
  state.questionIndex = -1;
  state.embeddedQuestion = null;
  state.selectedOption = null;
  state.lockedOption = null;
  state.lockedAt = null;
  state.questionStartedAt = null;
  state.timer = null;
  state.eliminatedOptions = [];
  state.lastLifelineResult = null;
  state.reveal = null;
  state.suspenseEndsAt = null;
  // Reset scores
  for (const cid of state.contestantOrder) {
    state.scores[cid] = 0;
    state.correctCounts[cid] = 0;
    state.ladderLevel[cid] = 0;
  }
  state.lifelineUses = {};
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'clear_timer' },
      { type: 'broadcast' },
      {
        type: 'persist_session',
        patch: {
          status: 'draft',
          currentQuestionIndex: -1,
          startedAt: null,
          endedAt: null,
          activeContestantId: null,
        },
      },
      { type: 'audit', action: 'session.reset', payload: { wipeAttempts: action.wipeAttempts, actorId: action.actorId } },
    ],
  };
}

/** T10: pause */
function handlePause(state: RuntimeState, action: { actorId: string }): TransitionResult {
  const pausablePhases: GamePhase[] = ['question_intro', 'question_active', 'answer_selected'];
  if (!pausablePhases.includes(state.phase)) return invalidState(`Cannot pause from ${state.phase}`);
  if (state.paused) return invalidState('Already paused');

  state.paused = true;
  state.pausedFrom = state.phase;
  state.version++;

  const effects: Effect[] = [{ type: 'broadcast' }, { type: 'audit', action: 'game.pause', payload: { actorId: action.actorId } }];

  if (state.phase === 'question_active' && state.timer?.endsAt) {
    const remainingMs = Math.max(0, state.timer.endsAt - Date.now());
    state.timer.endsAt = undefined;
    state.timer.remainingMs = remainingMs;
    effects.push({ type: 'pause_timer', remainingMs });
  }

  return { ok: true, effects };
}

/** T11: resume */
function handleResume(state: RuntimeState, action: { actorId: string }): TransitionResult {
  if (!state.paused) return invalidState('Not paused');

  state.paused = false;
  state.version++;

  const effects: Effect[] = [{ type: 'broadcast' }, { type: 'audit', action: 'game.resume', payload: { actorId: action.actorId } }];

  if (state.pausedFrom === 'question_active' && state.timer?.remainingMs != null) {
    const endsAt = Date.now() + state.timer.remainingMs;
    state.timer.endsAt = endsAt;
    state.timer.remainingMs = undefined;
    effects.push({ type: 'resume_timer', endsAt });
  }

  state.pausedFrom = undefined;
  return { ok: true, effects };
}

/** T13: manual contestant switch */
function handleContestantTurn(state: RuntimeState, action: { contestantId: string; actorId: string }): TransitionResult {
  if (!state.contestantOrder.includes(action.contestantId)) {
    return invalidState('Contestant not in this session');
  }
  if (state.paused) return invalidState('Cannot switch turns while paused');

  state.activeContestantId = action.contestantId;
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'broadcast' },
      { type: 'audit', action: 'game.contestant_turn', payload: { contestantId: action.contestantId, actorId: action.actorId } },
    ],
  };
}

/** T14: lifeline use */
function handleLifelineUse(state: RuntimeState, action: { lifelineType: LifelineType; actorId: string }): TransitionResult {
  const lifelinePhases: GamePhase[] = ['question_active', 'answer_selected'];
  if (!lifelinePhases.includes(state.phase)) return invalidState(`Cannot use lifeline in ${state.phase}`);

  const contestantId = state.activeContestantId!;
  const useKey = `${contestantId}:${action.lifelineType}`;

  // Check if already used
  if (state.lifelineUses[useKey] && state.lifelineUses[useKey] > 0) {
    return invalidState('Lifeline already used by this contestant');
  }

  state.lifelineUses[useKey] = (state.lifelineUses[useKey] ?? 0) + 1;
  state.version++;

  const effects: Effect[] = [
    { type: 'broadcast' },
    { type: 'audit', action: 'game.lifeline', payload: { type: action.lifelineType, contestantId, actorId: action.actorId } },
  ];

  // The actual lifeline result computation is done by the runtime (it has DB access)
  return { ok: true, effects };
}

/** T15: override */
function handleOverride(
  state: RuntimeState,
  action: { patch: { activeContestantId?: string; selectedOption?: OptionKey; dramaSeconds?: number; timerRemainingMs?: number }; actorId: string },
): TransitionResult {
  if (action.patch.activeContestantId) {
    if (!state.contestantOrder.includes(action.patch.activeContestantId)) {
      return invalidState('Contestant not in this session');
    }
    state.activeContestantId = action.patch.activeContestantId;
  }
  if (action.patch.selectedOption) {
    state.selectedOption = action.patch.selectedOption;
  }
  if (action.patch.dramaSeconds != null) {
    state.dramaSeconds = action.patch.dramaSeconds;
  }
  if (action.patch.timerRemainingMs != null && state.timer) {
    state.timer.remainingMs = action.patch.timerRemainingMs;
    if (!state.paused) {
      state.timer.endsAt = Date.now() + action.patch.timerRemainingMs;
    }
  }
  state.version++;

  return {
    ok: true,
    effects: [
      { type: 'broadcast' },
      { type: 'audit', action: 'game.override', payload: { patch: action.patch, actorId: action.actorId } },
    ],
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function computeStandings(state: RuntimeState): StandingsRow[] {
  return state.contestantOrder
    .map((cid) => ({
      contestantId: cid,
      name: '', // filled by runtime
      score: state.scores[cid] ?? 0,
      correctCount: state.correctCounts[cid] ?? 0,
      avgResponseMs: null, // computed by runtime from attempts
    }))
    .sort((a, b) => b.score - a.score || b.correctCount - a.correctCount);
}

/** Build a GameView from the runtime state (admin version — includes everything) */
export function buildGameView(
  state: RuntimeState,
  contestantNames: Record<string, string>,
  themeData: GameView['theme'],
): GameView {
  const eq = state.embeddedQuestion;

  const question = eq
    ? {
        index: state.questionIndex,
        total: 0, // filled by runtime
        numberLabel: `Q${String(state.questionIndex + 1).padStart(2, '0')}`,
        text: eq.text,
        options: eq.options.map((o) => ({
          key: o.key,
          text: o.text,
          visible: !state.eliminatedOptions.includes(o.key),
        })),
        media: eq.media ?? null,
        difficulty: eq.difficulty,
      }
    : null;

  const timer = state.timer
    ? {
        durationMs: state.timer.durationMs,
        endsAt: state.timer.endsAt,
        remainingMs: state.timer.remainingMs,
      }
    : null;

  // Lifelines remaining for active contestant
  const lifelines: Record<LifelineType, number> = {
    fifty_fifty: 0,
    audience_poll: 0,
    expert_call: 0,
  };
  if (state.activeContestantId) {
    // These will be filled by the runtime with actual session settings
    for (const lt of ['fifty_fifty', 'audience_poll', 'expert_call'] as LifelineType[]) {
      const key = `${state.activeContestantId}:${lt}`;
      lifelines[lt] = -1; // placeholder; runtime fills with max - used
    }
  }

  // Ladder
  const activeLadderLevel = state.activeContestantId ? state.ladderLevel[state.activeContestantId] ?? 0 : 0;
  const safeAmount = computeSafeAmount(state, state.activeContestantId);

  const view: GameView = {
    sessionId: state.sessionId,
    code: '', // filled by runtime
    name: '', // filled by runtime
    phase: state.phase,
    paused: state.paused,
    language: state.language,
    question,
    timer,
    selectedOption: state.selectedOption ?? undefined,
    lockedOption: state.lockedOption ?? undefined,
    lockedBy: state.lockedOption
      ? { contestantId: state.activeContestantId ?? '', name: state.activeContestantId ? contestantNames[state.activeContestantId] ?? '' : '' }
      : undefined,
    reveal: state.reveal ?? undefined,
    activeContestant: state.activeContestantId
      ? { id: state.activeContestantId, name: contestantNames[state.activeContestantId] ?? '' }
      : null,
    contestants: state.contestantOrder.map((cid) => ({
      id: cid,
      name: contestantNames[cid] ?? '',
      score: state.scores[cid] ?? 0,
      isActive: cid === state.activeContestantId,
    })),
    ladder: {
      levels: state.ladderLevels,
      currentLevel: activeLadderLevel + 1,
      safeAmount,
    },
    lifelines,
    lifelineResult: state.lastLifelineResult,
    theme: themeData,
    serverTime: Date.now(),
    version: state.version,
  };

  return view;
}

/** Strip sensitive data for the display room (M06 §4 sanitization) */
export function sanitizeForDisplay(view: GameView): GameView {
  const sanitized = { ...view };

  // Never expose correctOption before answer_revealed
  if (sanitized.question) {
    sanitized.question = { ...sanitized.question };
  }

  // reveal field only in answer_revealed
  if (sanitized.phase !== 'answer_revealed') {
    sanitized.reveal = undefined;
  }

  return sanitized;
}

function computeSafeAmount(state: RuntimeState, contestantId: string | null): number {
  if (!contestantId) return 0;
  const level = state.ladderLevel[contestantId] ?? 0;
  let safeAmount = 0;
  for (const l of state.ladderLevels) {
    if (l.isSafeHaven && l.level <= level) {
      safeAmount = Math.max(safeAmount, l.amount);
    }
  }
  return safeAmount;
}
