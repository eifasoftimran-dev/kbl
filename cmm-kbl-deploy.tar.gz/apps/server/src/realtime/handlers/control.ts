/**
 * Game control event handlers (M06 §3.1).
 * Maps socket events → runtime.dispatch() with permission guards.
 */
import type { Server, Socket } from 'socket.io';
import { CLIENT_EVENTS } from '@cmm/shared';
import type { OptionKey, LifelineType } from '@cmm/shared';
import { runtimeRegistry } from '../game/game-session-runtime';
import { ackError, ackOk, socketHasPermission, type SocketIdentity } from '../io';
import { logger } from '../../utils/logger';

type AckFn = (result: { ok: boolean; error?: { code: string; message: string }; data?: unknown }) => void;

function getIdentity(socket: Socket): SocketIdentity | undefined {
  return (socket.data as { identity?: SocketIdentity }).identity;
}

function requireAuth(socket: Socket, ack: AckFn | undefined): SocketIdentity | null {
  const identity = getIdentity(socket);
  if (!identity) {
    ack?.(ackError('UNAUTHORIZED', 'Authentication required'));
    return null;
  }
  return identity;
}

function requirePerm(socket: Socket, ack: AckFn | undefined, permission: string): SocketIdentity | null {
  const identity = requireAuth(socket, ack);
  if (!identity) return null;
  if (!socketHasPermission(socket, permission)) {
    ack?.(ackError('FORBIDDEN', `Role '${identity.role}' lacks '${permission}'`));
    return null;
  }
  return identity;
}

async function getRuntime(io: Server, ack: AckFn | undefined, sessionId: string) {
  try {
    return await runtimeRegistry.getOrCreate(sessionId, io);
  } catch {
    ack?.(ackError('NOT_FOUND', 'Session runtime not available'));
    return null;
  }
}

export function registerControlHandlers(io: Server): void {
  io.on('connection', (socket: Socket) => {
    // -----------------------------------------------------------------------
    // control:start
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_START, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = await getRuntime(io, ack, payload.sessionId);
      if (!rt) return;

      // Load the first question BEFORE start so the intro broadcast includes it
      await rt.loadQuestion(0);

      const result = await rt.dispatchAction({ type: 'start', actorId: identity.userId });
      if (!result.ok) {
        ack?.(ackError(result.error!.code, result.error!.message));
        return;
      }

      // The intro→active transition fires from the scheduled intro timer (QUESTION_INTRO_MS)

      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:pause
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_PAUSE, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({ type: 'pause', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:resume
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_RESUME, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({ type: 'resume', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:next
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_NEXT, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      // Guard: no more questions — the operator should end the session instead
      const nextIndex = rt.getState().questionIndex + 1;
      if (!rt.hasQuestion(nextIndex)) {
        ack?.(ackError('NO_MORE_QUESTIONS', 'No more questions in this session — end the game instead'));
        return;
      }

      // Load the next question BEFORE dispatch so the intro broadcast includes it
      await rt.loadQuestion(nextIndex);

      const result = await rt.dispatchAction({ type: 'next', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }

      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:select
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_SELECT, async (payload: { sessionId: string; optionKey: OptionKey }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({
        type: 'select',
        optionKey: payload.optionKey,
        actorId: identity.userId,
      });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:lock
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_LOCK, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({ type: 'lock', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:reveal
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_REVEAL, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({ type: 'reveal', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:end
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_END, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({ type: 'end', actorId: identity.userId });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:reset
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_RESET, async (payload: { sessionId: string; confirm: boolean; wipeAttempts?: boolean }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({
        type: 'reset',
        confirm: payload.confirm,
        wipeAttempts: payload.wipeAttempts,
        actorId: identity.userId,
      });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // control:override
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTROL_OVERRIDE, async (payload: { sessionId: string; patch: { activeContestantId?: string; selectedOption?: OptionKey; dramaSeconds?: number; timerRemainingMs?: number } }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({
        type: 'override',
        patch: payload.patch,
        actorId: identity.userId,
      });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // lifeline:use
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.LIFELINE_USE, async (payload: { sessionId: string; type: LifelineType; contestantId?: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'lifelines.use');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      // Dispatch the lifeline action
      const result = await rt.dispatchAction({
        type: 'lifeline_use',
        lifelineType: payload.type,
        actorId: identity.userId,
      });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }

      // Process the lifeline computation (50:50, audience poll, expert call)
      const lifelineResult = await rt.processLifeline(payload.type);

      // Emit lifeline result to all clients
      if (lifelineResult) {
        io.to(`session:${payload.sessionId}:admin`).emit('lifeline:result', {
          sessionId: payload.sessionId,
          ...lifelineResult,
        });
        io.to(`session:${payload.sessionId}:display`).emit('lifeline:result', {
          sessionId: payload.sessionId,
          ...lifelineResult,
        });
      }

      // Re-broadcast so eliminated options / lifeline counts reach clients via state:changed
      await rt.broadcastNow();

      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // contestant:turn
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.CONTESTANT_TURN, async (payload: { sessionId: string; contestantId: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'game.control');
      if (!identity) return;

      const rt = runtimeRegistry.get(payload.sessionId);
      if (!rt) { ack?.(ackError('NOT_FOUND', 'Session not active')); return; }

      const result = await rt.dispatchAction({
        type: 'contestant_turn',
        contestantId: payload.contestantId,
        actorId: identity.userId,
      });
      if (!result.ok) { ack?.(ackError(result.error!.code, result.error!.message)); return; }
      ack?.(ackOk());
    });

    // -----------------------------------------------------------------------
    // display:command
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.DISPLAY_COMMAND, async (payload: { sessionId: string; command: string }, ack?: AckFn) => {
      const identity = requirePerm(socket, ack, 'led.control');
      if (!identity) return;

      // Display commands are forwarded to the display room as-is
      io.to(`session:${payload.sessionId}:display`).emit('display:command', {
        sessionId: payload.sessionId,
        command: payload.command,
      });
      ack?.(ackOk());
    });
  });
}
