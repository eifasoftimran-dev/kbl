/**
 * Session join/leave handlers (M06 §2–§3).
 * - Admin clients join by sessionId
 * - Display clients join by 6-char public code
 */
import type { Server, Socket } from 'socket.io';
import { CLIENT_EVENTS, SERVER_EVENTS } from '@cmm/shared';
import { GameSession } from '../../modules/sessions/session.model';
import { runtimeRegistry } from '../game/game-session-runtime';
import { ackError, ackOk, type SocketIdentity } from '../io';
import { logger } from '../../utils/logger';

type AckFn = (result: ReturnType<typeof ackOk | typeof ackError>) => void;

export function registerSessionHandlers(io: Server): void {
  io.on('connection', (socket: Socket) => {
    // -----------------------------------------------------------------------
    // session:join — admin by sessionId, display by code
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.SESSION_JOIN, async (payload: { sessionId?: string; code?: string }, ack?: AckFn) => {
      try {
        const identity = (socket.data as { identity?: SocketIdentity }).identity;

        if (identity && payload.sessionId) {
          // Admin join by sessionId
          const session = await GameSession.findById(payload.sessionId).select('_id code name status').lean().exec();
          if (!session) {
            ack?.(ackError('NOT_FOUND', 'Session not found'));
            return;
          }

          const room = `session:${String(session._id)}:admin`;
          await socket.join(room);

          // Get or create runtime
          const rt = await runtimeRegistry.getOrCreate(String(session._id), io);
          const view = await rt.getGameView();

          socket.emit(SERVER_EVENTS.STATE_CHANGED, view);
          ack?.(ackOk({ sessionId: String(session._id), room }));
          logger.debug({ userId: identity.userId, sessionId: String(session._id) }, 'Admin joined session room');
          return;
        }

        if (payload.code) {
          // Display join by code
          const session = await GameSession.findOne({ code: payload.code.toUpperCase() })
            .select('_id code name status')
            .lean()
            .exec();
          if (!session) {
            ack?.(ackError('NOT_FOUND', 'Session code not found'));
            return;
          }

          const room = `session:${String(session._id)}:display`;
          await socket.join(room);

          // Get runtime (may not exist if session is draft)
          const rt = runtimeRegistry.get(String(session._id));
          if (rt) {
            const view = await rt.getDisplayView();
            socket.emit(SERVER_EVENTS.STATE_CHANGED, view);
          }

          ack?.(ackOk({ sessionId: String(session._id), room }));
          logger.debug({ code: payload.code }, 'Display joined session room');
          return;
        }

        ack?.(ackError('INVALID_PAYLOAD', 'Provide sessionId (admin) or code (display)'));
      } catch (err) {
        logger.error({ err }, 'session:join handler failed');
        ack?.(ackError('INTERNAL', 'Failed to join session'));
      }
    });

    // -----------------------------------------------------------------------
    // session:leave
    // -----------------------------------------------------------------------
    socket.on(CLIENT_EVENTS.SESSION_LEAVE, async (payload: { sessionId: string }, ack?: AckFn) => {
      const identity = (socket.data as { identity?: SocketIdentity }).identity;
      const roomType = identity ? 'admin' : 'display';
      const room = `session:${payload.sessionId}:${roomType}`;
      await socket.leave(room);
      ack?.(ackOk());
    });
  });
}
