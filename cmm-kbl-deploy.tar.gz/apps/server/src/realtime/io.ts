/**
 * Socket.io server setup (M06 §1–§2).
 * - JWT auth middleware for admin connections
 * - Anonymous display connections via session code
 * - Event handler registration
 */
import type { Server as HttpServer } from 'node:http';
import { Server as SocketIOServer } from 'socket.io';
import jwt from 'jsonwebtoken';
import type { Permission, Role } from '@cmm/shared';
import { roleHasPermission } from '@cmm/shared';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import { registerSessionHandlers } from './handlers/session';
import { registerControlHandlers } from './handlers/control';
import { runtimeRegistry } from './game/game-session-runtime';
import { startTicker } from './game/ticker';

export interface SocketIdentity {
  userId: string;
  role: Role;
  name: string;
}

export function createSocketIO(httpServer: HttpServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: env.WEB_ORIGIN.split(',').map((o) => o.trim()),
      credentials: true,
    },
    pingInterval: 10000,
    pingTimeout: 20000,
  });

  // -----------------------------------------------------------------------
  // Auth middleware (M06 §2)
  // -----------------------------------------------------------------------
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;

    if (token) {
      // Admin connection — verify JWT
      try {
        const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as {
          sub: string;
          role: Role;
          name: string;
          type: string;
        };
        if (payload.type !== 'access') {
          return next(new Error('UNAUTHORIZED: wrong token type'));
        }
        (socket.data as { identity?: SocketIdentity }).identity = {
          userId: payload.sub,
          role: payload.role,
          name: payload.name,
        };
        return next();
      } catch {
        return next(new Error('UNAUTHORIZED: invalid token'));
      }
    }

    // Display connection — anonymous, no identity required
    (socket.data as { identity?: SocketIdentity }).identity = undefined;
    return next();
  });

  // -----------------------------------------------------------------------
  // Connection handler
  // -----------------------------------------------------------------------
  io.on('connection', (socket) => {
    const identity = (socket.data as { identity?: SocketIdentity }).identity;

    socket.emit('connection:ok', {
      serverTime: Date.now(),
      socketId: socket.id,
      authenticated: !!identity,
      role: identity?.role,
    });

    if (identity) {
      logger.debug({ userId: identity.userId, role: identity.role }, 'Admin socket connected');
    } else {
      logger.debug('Display socket connected (anonymous)');
    }

    socket.on('disconnect', () => {
      logger.debug({ socketId: socket.id }, 'Socket disconnected');
    });
  });

  // Register event handlers
  registerSessionHandlers(io);
  registerControlHandlers(io);

  // Rehydrate live sessions from DB
  runtimeRegistry.rehydrateAll(io).then(() => {
    logger.info('Live session rehydration complete');
  });

  // Start the global game ticker
  startTicker();

  logger.info('Socket.io realtime engine initialized');
  return io;
}

/** Permission guard for socket events (M06 §3.1). */
export function socketHasPermission(socket: { data: { identity?: SocketIdentity } }, permission: string): boolean {
  const identity = socket.data.identity;
  if (!identity) return false;
  return roleHasPermission(identity.role, permission as Permission);
}

/** Create an ack error response. */
export function ackError(code: string, message: string): { ok: false; error: { code: string; message: string } } {
  return { ok: false, error: { code, message } };
}

/** Create an ack success response. */
export function ackOk<T = undefined>(data?: T): { ok: true; data?: T } {
  return { ok: true, data };
}
