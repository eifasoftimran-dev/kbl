import mongoose from 'mongoose';
import { env } from '../config/env';
import { logger } from '../utils/logger';

/**
 * MongoDB connection with bounded retries (M01 §5).
 * The dev-mongo launcher or docker-compose provides the actual mongod.
 */
export async function connectDb(
  uri: string = env.MONGO_URI,
  retries = 5,
  delayMs = 3_000,
): Promise<void> {
  mongoose.set('strictQuery', true);
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      await mongoose.connect(uri, { serverSelectionTimeoutMS: 5_000 });
      logger.info({ db: redactUri(uri) }, 'MongoDB connected');
      return;
    } catch (err) {
      if (attempt === retries) throw err;
      logger.warn({ attempt, retries, err: String(err) }, 'MongoDB connect failed — retrying…');
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
}

export async function disconnectDb(): Promise<void> {
  await mongoose.disconnect();
  logger.info('MongoDB disconnected');
}

/** Never log credentials embedded in the URI. */
function redactUri(uri: string): string {
  return uri.replace(/\/\/([^:/@]+):([^@]+)@/, '//$1:***@');
}
