import 'dotenv/config';
import type { Difficulty, LocalText, OptionKey, Role } from '@cmm/shared';
import { TIMER_DEFAULTS_BY_DIFFICULTY, TIMER_MAX_SECONDS } from '@cmm/shared';
import { env } from '../config/env';
import { connectDb, disconnectDb } from './connect';
import { hashPassword } from '../modules/auth/auth.service';
import { User } from '../modules/auth/user.model';
import { Category } from '../modules/questions/category.model';
import { Question } from '../modules/questions/question.model';
import { Counter } from '../modules/questions/counter.model';
import { Contestant } from '../modules/contestants/contestant.model';
import { GameSession } from '../modules/sessions/session.model';
import { PrizeLadderConfig, DEFAULT_LADDER_LEVELS } from '../modules/sessions/ladder-config.model';
import { ThemeSetting } from '../modules/settings/theme-setting.model';
import { TimerSetting, LifelineSetting } from '../modules/settings/settings.models';

/**
 * Seed script (M01 §6): demo dataset so the admin panel & display are usable
 * immediately. Idempotent — skips unless FORCE_SEED=true (then wipes first).
 *
 *   npm run seed              # first run only
 *   FORCE_SEED=true npm run seed   # wipe & reseed
 */

interface SeedUser {
  name: string;
  email: string;
  password: string;
  role: Role;
}

const SEED_USERS: SeedUser[] = [
  { name: 'Super Admin', email: env.SEED_ADMIN_EMAIL, password: env.SEED_ADMIN_PASSWORD, role: 'super_admin' },
  { name: 'Priya Nair', email: 'operator@quiz.local', password: 'Operator@123', role: 'operator' },
  { name: 'Aman Khanna', email: 'host@quiz.local', password: 'Host@123', role: 'host' },
  { name: 'Neha Joshi', email: 'editor@quiz.local', password: 'Editor@123', role: 'question_editor' },
];

const SEED_CATEGORIES: { name: LocalText; slug: string; color: string; sortOrder: number }[] = [
  { name: { hi: 'सामान्य ज्ञान', en: 'General Knowledge' }, slug: 'general-knowledge', color: '#1E5BFF', sortOrder: 1 },
  { name: { hi: 'इतिहास', en: 'History' }, slug: 'history', color: '#7B2FF7', sortOrder: 2 },
  { name: { hi: 'भूगोल', en: 'Geography' }, slug: 'geography', color: '#22C55E', sortOrder: 3 },
  { name: { hi: 'विज्ञान', en: 'Science' }, slug: 'science', color: '#EF4444', sortOrder: 4 },
  { name: { hi: 'खेल', en: 'Sports' }, slug: 'sports', color: '#FFC93C', sortOrder: 5 },
  { name: { hi: 'सिनेमा', en: 'Cinema' }, slug: 'cinema', color: '#EC4899', sortOrder: 6 },
  { name: { hi: 'भारतीय संस्कृति', en: 'Indian Culture' }, slug: 'indian-culture', color: '#14B8A6', sortOrder: 7 },
  { name: { hi: 'मौजूदा घटनाएँ', en: 'Current Affairs' }, slug: 'current-affairs', color: '#F97316', sortOrder: 8 },
];

interface SeedQuestion {
  text: LocalText;
  options: [LocalText, LocalText, LocalText, LocalText];
  correct: OptionKey;
  category: string;
  difficulty: Difficulty;
  explanation: LocalText;
}

const POINTS_BY_DIFFICULTY: Record<Difficulty, number> = { easy: 1000, medium: 2000, hard: 3000 };

const SEED_QUESTIONS: SeedQuestion[] = [
  // ---- EASY (15) ----------------------------------------------------------
  {
    text: { hi: 'भारत का राष्ट्रीय पशु कौन-सा है?', en: 'What is the national animal of India?' },
    options: [
      { hi: 'शेर', en: 'Lion' },
      { hi: 'बाघ', en: 'Tiger' },
      { hi: 'हाथी', en: 'Elephant' },
      { hi: 'गैंडा', en: 'Rhinoceros' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'easy',
    explanation: {
      hi: 'बंगाल टाइगर को 1973 से भारत का राष्ट्रीय पशु घोषित किया गया था।',
      en: 'The Bengal Tiger has been India’s national animal since 1973.',
    },
  },
  {
    text: { hi: 'भारत की राजधानी क्या है?', en: 'What is the capital of India?' },
    options: [
      { hi: 'मुंबई', en: 'Mumbai' },
      { hi: 'नई दिल्ली', en: 'New Delhi' },
      { hi: 'कोलकाता', en: 'Kolkata' },
      { hi: 'चेन्नई', en: 'Chennai' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'easy',
    explanation: { hi: 'नई दिल्ली भारत की राजधानी है।', en: 'New Delhi is the capital of India.' },
  },
  {
    text: { hi: 'एक सप्ताह में कितने दिन होते हैं?', en: 'How many days are there in a week?' },
    options: [
      { hi: '5', en: '5' },
      { hi: '6', en: '6' },
      { hi: '7', en: '7' },
      { hi: '8', en: '8' },
    ],
    correct: 'C',
    category: 'general-knowledge',
    difficulty: 'easy',
    explanation: { hi: 'एक सप्ताह में सात दिन होते हैं।', en: 'There are seven days in a week.' },
  },
  {
    text: { hi: 'भारत का राष्ट्रीय खेल किसे माना जाता है?', en: 'Which sport is regarded as India’s national game?' },
    options: [
      { hi: 'क्रिकेट', en: 'Cricket' },
      { hi: 'हॉकी', en: 'Hockey' },
      { hi: 'फुटबॉल', en: 'Football' },
      { hi: 'कबड्डी', en: 'Kabaddi' },
    ],
    correct: 'B',
    category: 'sports',
    difficulty: 'easy',
    explanation: {
      hi: 'फील्ड हॉकी को पारंपरिक रूप से भारत का राष्ट्रीय खेल माना जाता है।',
      en: 'Field hockey is traditionally regarded as India’s national game.',
    },
  },
  {
    text: { hi: '‘शोले’ फिल्म में गब्बर सिंह का किरदार किसने निभाया?', en: 'Who played the role of Gabbar Singh in the film ‘Sholay’?' },
    options: [
      { hi: 'अमजद खान', en: 'Amjad Khan' },
      { hi: 'अमिताभ बच्चन', en: 'Amitabh Bachchan' },
      { hi: 'धर्मेंद्र', en: 'Dharmendra' },
      { hi: 'संजीव कुमार', en: 'Sanjeev Kumar' },
    ],
    correct: 'A',
    category: 'cinema',
    difficulty: 'easy',
    explanation: {
      hi: 'अमजद खान ने 1975 की इस ब्लॉकबस्टर फिल्म में गब्बर सिंह का किरदार निभाया था।',
      en: 'Amjad Khan played Gabbar Singh in the 1975 blockbuster.',
    },
  },
  {
    text: { hi: 'सूर्य किस दिशा में उगता है?', en: 'In which direction does the sun rise?' },
    options: [
      { hi: 'उत्तर', en: 'North' },
      { hi: 'दक्षिण', en: 'South' },
      { hi: 'पूर्व', en: 'East' },
      { hi: 'पश्चिम', en: 'West' },
    ],
    correct: 'C',
    category: 'general-knowledge',
    difficulty: 'easy',
    explanation: { hi: 'सूर्य पूर्व दिशा में उगता है।', en: 'The sun rises in the east.' },
  },
  {
    text: { hi: 'भारत की राष्ट्रीय मुद्रा क्या है?', en: 'What is the currency of India?' },
    options: [
      { hi: 'डॉलर', en: 'Dollar' },
      { hi: 'रुपया', en: 'Rupee' },
      { hi: 'येन', en: 'Yen' },
      { hi: 'यूरो', en: 'Euro' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'easy',
    explanation: { hi: 'भारतीय रुपया (₹) भारत की आधिकारिक मुद्रा है।', en: 'The Indian Rupee (₹) is India’s official currency.' },
  },
  {
    text: { hi: 'राष्ट्रगान ‘जन गण मन’ की रचना किसने की?', en: 'Who composed the national anthem ‘Jana Gana Mana’?' },
    options: [
      { hi: 'बंकिम चंद्र चटर्जी', en: 'Bankim Chandra Chatterjee' },
      { hi: 'रवींद्रनाथ टैगोर', en: 'Rabindranath Tagore' },
      { hi: 'महात्मा गांधी', en: 'Mahatma Gandhi' },
      { hi: 'सरदार पटेल', en: 'Sardar Patel' },
    ],
    correct: 'B',
    category: 'indian-culture',
    difficulty: 'easy',
    explanation: {
      hi: 'रवींद्रनाथ टैगोर ने ‘जन गण मन’ की रचना की थी।',
      en: 'Rabindranath Tagore composed ‘Jana Gana Mana’.',
    },
  },
  {
    text: { hi: 'सबसे बड़ा महाद्वीप कौन-सा है?', en: 'Which is the largest continent?' },
    options: [
      { hi: 'अफ्रीका', en: 'Africa' },
      { hi: 'एशिया', en: 'Asia' },
      { hi: 'यूरोप', en: 'Europe' },
      { hi: 'ऑस्ट्रेलिया', en: 'Australia' },
    ],
    correct: 'B',
    category: 'geography',
    difficulty: 'easy',
    explanation: { hi: 'एशिया क्षेत्रफल और जनसंख्या दोनों में सबसे बड़ा महाद्वीप है।', en: 'Asia is the largest continent by both area and population.' },
  },
  {
    text: { hi: 'मानव शरीर का सबसे बड़ा अंग कौन-सा है?', en: 'Which is the largest organ of the human body?' },
    options: [
      { hi: 'यकृत', en: 'Liver' },
      { hi: 'हृदय', en: 'Heart' },
      { hi: 'त्वचा', en: 'Skin' },
      { hi: 'फेफड़े', en: 'Lungs' },
    ],
    correct: 'C',
    category: 'science',
    difficulty: 'easy',
    explanation: { hi: 'त्वचा मानव शरीर का सबसे बड़ा अंग है।', en: 'The skin is the largest organ of the human body.' },
  },
  {
    text: { hi: 'ताजमहल किस शहर में स्थित है?', en: 'In which city is the Taj Mahal located?' },
    options: [
      { hi: 'दिल्ली', en: 'Delhi' },
      { hi: 'आगरा', en: 'Agra' },
      { hi: 'जयपुर', en: 'Jaipur' },
      { hi: 'लखनऊ', en: 'Lucknow' },
    ],
    correct: 'B',
    category: 'history',
    difficulty: 'easy',
    explanation: { hi: 'ताजमहल आगरा, उत्तर प्रदेश में स्थित है।', en: 'The Taj Mahal is located in Agra, Uttar Pradesh.' },
  },
  {
    text: { hi: 'क्रिकेट के एक ओवर में कितनी गेंदें होती हैं?', en: 'How many balls are there in one over of cricket?' },
    options: [
      { hi: '4', en: '4' },
      { hi: '5', en: '5' },
      { hi: '6', en: '6' },
      { hi: '8', en: '8' },
    ],
    correct: 'C',
    category: 'sports',
    difficulty: 'easy',
    explanation: { hi: 'एक ओवर में छह गेंदें होती हैं।', en: 'One over consists of six balls.' },
  },
  {
    text: { hi: 'दीपावली की रात किस देवी की पूजा की जाती है?', en: 'Which goddess is worshipped on the night of Diwali?' },
    options: [
      { hi: 'दुर्गा', en: 'Durga' },
      { hi: 'लक्ष्मी', en: 'Lakshmi' },
      { hi: 'सरस्वती', en: 'Saraswati' },
      { hi: 'पार्वती', en: 'Parvati' },
    ],
    correct: 'B',
    category: 'indian-culture',
    difficulty: 'easy',
    explanation: { hi: 'दीपावली पर माँ लक्ष्मी की पूजा की जाती है।', en: 'Goddess Lakshmi is worshipped on Diwali.' },
  },
  {
    text: { hi: 'गंगा नदी का उद्गम स्थल कौन-सा है?', en: 'Where does the river Ganga originate?' },
    options: [
      { hi: 'गंगोत्री', en: 'Gangotri' },
      { hi: 'यमुनोत्री', en: 'Yamunotri' },
      { hi: 'केदारनाथ', en: 'Kedarnath' },
      { hi: 'बद्रीनाथ', en: 'Badrinath' },
    ],
    correct: 'A',
    category: 'geography',
    difficulty: 'easy',
    explanation: { hi: 'गंगा का उद्गम गंगोत्री (भागीरथी) से माना जाता है।', en: 'The Ganga originates from Gangotri (as Bhagirathi).' },
  },
  {
    text: { hi: 'भारत के पहले प्रधानमंत्री कौन थे?', en: 'Who was the first Prime Minister of India?' },
    options: [
      { hi: 'महात्मा गांधी', en: 'Mahatma Gandhi' },
      { hi: 'जवाहरलाल नेहरू', en: 'Jawaharlal Nehru' },
      { hi: 'सरदार पटेल', en: 'Sardar Patel' },
      { hi: 'डॉ. अंबेडकर', en: 'Dr. Ambedkar' },
    ],
    correct: 'B',
    category: 'history',
    difficulty: 'easy',
    explanation: { hi: 'पंडित जवाहरलाल नेहरू भारत के पहले प्रधानमंत्री थे।', en: 'Pandit Jawaharlal Nehru was India’s first Prime Minister.' },
  },

  // ---- MEDIUM (15) --------------------------------------------------------
  {
    text: { hi: 'भारत का संविधान कब लागू हुआ?', en: 'When did the Constitution of India come into effect?' },
    options: [
      { hi: '15 अगस्त 1947', en: '15 August 1947' },
      { hi: '26 जनवरी 1950', en: '26 January 1950' },
      { hi: '26 नवंबर 1949', en: '26 November 1949' },
      { hi: '2 अक्टूबर 1950', en: '2 October 1950' },
    ],
    correct: 'B',
    category: 'history',
    difficulty: 'medium',
    explanation: {
      hi: 'संविधान 26 नवंबर 1949 को अंगीकृत और 26 जनवरी 1950 को लागू हुआ।',
      en: 'It was adopted on 26 November 1949 and came into effect on 26 January 1950.',
    },
  },
  {
    text: { hi: 'किस ग्रह को ‘लाल ग्रह’ कहा जाता है?', en: 'Which planet is called the ‘Red Planet’?' },
    options: [
      { hi: 'शुक्र', en: 'Venus' },
      { hi: 'मंगल', en: 'Mars' },
      { hi: 'बृहस्पति', en: 'Jupiter' },
      { hi: 'शनि', en: 'Saturn' },
    ],
    correct: 'B',
    category: 'science',
    difficulty: 'medium',
    explanation: { hi: 'मंगल के लाल रंग का कारण उसकी मिट्टी में आयरन ऑक्साइड है।', en: 'Mars appears red due to iron oxide in its soil.' },
  },
  {
    text: { hi: '‘गोदान’ उपन्यास के लेखक कौन हैं?', en: 'Who is the author of the novel ‘Godaan’?' },
    options: [
      { hi: 'जयशंकर प्रसाद', en: 'Jaishankar Prasad' },
      { hi: 'प्रेमचंद', en: 'Premchand' },
      { hi: 'सुमित्रानंदन पंत', en: 'Sumitranandan Pant' },
      { hi: 'बालमुकुंद गुप्त', en: 'Balmukund Gupta' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'medium',
    explanation: { hi: 'मुंशी प्रेमचंद ने 1936 में ‘गोदान’ लिखा था।', en: 'Munshi Premchand wrote ‘Godaan’ in 1936.' },
  },
  {
    text: { hi: 'DNA की संरचना की खोज किसने की?', en: 'Who discovered the structure of DNA?' },
    options: [
      { hi: 'वाटसन और क्रिक', en: 'Watson and Crick' },
      { hi: 'आइज़क न्यूटन', en: 'Isaac Newton' },
      { hi: 'अल्बर्ट आइंस्टीन', en: 'Albert Einstein' },
      { hi: 'चार्ल्स डार्विन', en: 'Charles Darwin' },
    ],
    correct: 'A',
    category: 'science',
    difficulty: 'medium',
    explanation: { hi: '1953 में वाटसन और क्रिक ने DNA की डबल हेलिक्स संरचना खोजी।', en: 'Watson and Crick discovered the double-helix structure in 1953.' },
  },
  {
    text: { hi: 'भारत की सबसे लंबी नदी कौन-सी है?', en: 'Which is the longest river in India?' },
    options: [
      { hi: 'गोदावरी', en: 'Godavari' },
      { hi: 'गंगा', en: 'Ganga' },
      { hi: 'ब्रह्मपुत्र', en: 'Brahmaputra' },
      { hi: 'नर्मदा', en: 'Narmada' },
    ],
    correct: 'B',
    category: 'geography',
    difficulty: 'medium',
    explanation: { hi: 'भारत में गंगा सबसे लंबी नदी है (लगभग 2,525 किमी)।', en: 'The Ganga is the longest river in India (~2,525 km).' },
  },
  {
    text: { hi: 'ओलंपिक खेल कितने वर्षों के अंतराल पर आयोजित होते हैं?', en: 'The Olympic Games are held at an interval of how many years?' },
    options: [
      { hi: '2', en: '2' },
      { hi: '3', en: '3' },
      { hi: '4', en: '4' },
      { hi: '5', en: '5' },
    ],
    correct: 'C',
    category: 'sports',
    difficulty: 'medium',
    explanation: { hi: 'ग्रीष्मकालीन ओलंपिक हर चार वर्षों में होते हैं।', en: 'The Summer Olympics are held every four years.' },
  },
  {
    text: { hi: '‘मदर इंडिया’ फिल्म की मुख्य अभिनेत्री कौन थीं?', en: 'Who was the lead actress of the film ‘Mother India’?' },
    options: [
      { hi: 'मधुबाला', en: 'Madhubala' },
      { hi: 'नरगिस', en: 'Nargis' },
      { hi: 'मीना कुमारी', en: 'Meena Kumari' },
      { hi: 'वैजयंतीमाला', en: 'Vyjayanthimala' },
    ],
    correct: 'B',
    category: 'cinema',
    difficulty: 'medium',
    explanation: { hi: 'नरगिस ने 1957 की ‘मदर इंडिया’ में मुख्य भूमिका निभाई।', en: 'Nargis played the lead in the 1957 classic ‘Mother India’.' },
  },
  {
    text: { hi: 'भारत में कुल कितने राज्य हैं?', en: 'How many states are there in India?' },
    options: [
      { hi: '27', en: '27' },
      { hi: '28', en: '28' },
      { hi: '29', en: '29' },
      { hi: '30', en: '30' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'medium',
    explanation: { hi: 'भारत में 28 राज्य और 8 केंद्रशासित प्रदेश हैं।', en: 'India has 28 states and 8 union territories.' },
  },
  {
    text: { hi: 'कौन-सा देश ‘उगते सूरज की भूमि’ कहलाता है?', en: 'Which country is known as the ‘Land of the Rising Sun’?' },
    options: [
      { hi: 'चीन', en: 'China' },
      { hi: 'जापान', en: 'Japan' },
      { hi: 'कोरिया', en: 'Korea' },
      { hi: 'थाईलैंड', en: 'Thailand' },
    ],
    correct: 'B',
    category: 'geography',
    difficulty: 'medium',
    explanation: { hi: 'जापान को ‘उगते सूरज की भूमि’ कहा जाता है।', en: 'Japan is known as the ‘Land of the Rising Sun’.' },
  },
  {
    text: { hi: 'भारतीय रिज़र्व बैंक की स्थापना किस वर्ष हुई?', en: 'In which year was the Reserve Bank of India established?' },
    options: [
      { hi: '1935', en: '1935' },
      { hi: '1947', en: '1947' },
      { hi: '1949', en: '1949' },
      { hi: '1950', en: '1950' },
    ],
    correct: 'A',
    category: 'general-knowledge',
    difficulty: 'medium',
    explanation: { hi: 'RBI की स्थापना 1 अप्रैल 1935 को हुई थी।', en: 'The RBI was established on 1 April 1935.' },
  },
  {
    text: { hi: 'महात्मा गांधी का जन्म किस वर्ष हुआ?', en: 'In which year was Mahatma Gandhi born?' },
    options: [
      { hi: '1869', en: '1869' },
      { hi: '1879', en: '1879' },
      { hi: '1889', en: '1889' },
      { hi: '1899', en: '1899' },
    ],
    correct: 'A',
    category: 'history',
    difficulty: 'medium',
    explanation: { hi: 'गांधीजी का जन्म 2 अक्टूबर 1869 को पोरबंदर में हुआ।', en: 'Gandhi was born on 2 October 1869 in Porbandar.' },
  },
  {
    text: { hi: 'शतरंज में एक खिलाड़ी के पास कुल कितने मोहरे होते हैं?', en: 'How many pieces does each player have in chess?' },
    options: [
      { hi: '14', en: '14' },
      { hi: '15', en: '15' },
      { hi: '16', en: '16' },
      { hi: '18', en: '18' },
    ],
    correct: 'C',
    category: 'sports',
    difficulty: 'medium',
    explanation: { hi: 'शतरंज में प्रत्येक खिलाड़ी के पास 16 मोहरे होते हैं।', en: 'Each player has 16 pieces in chess.' },
  },
  {
    text: { hi: 'हॉकी टीम में कितने खिलाड़ी मैदान पर होते हैं?', en: 'How many players of a hockey team are on the field?' },
    options: [
      { hi: '9', en: '9' },
      { hi: '10', en: '10' },
      { hi: '11', en: '11' },
      { hi: '12', en: '12' },
    ],
    correct: 'C',
    category: 'sports',
    difficulty: 'medium',
    explanation: { hi: 'फील्ड हॉकी में प्रत्येक टीम के 11 खिलाड़ी मैदान पर होते हैं।', en: 'Each field hockey team fields 11 players.' },
  },
  {
    text: { hi: '‘आज़ाद हिंद फौज’ की स्थापना किसने की?', en: 'Who founded the ‘Azad Hind Fauj’ (Indian National Army)?' },
    options: [
      { hi: 'सुभाष चंद्र बोस', en: 'Subhash Chandra Bose' },
      { hi: 'भगत सिंह', en: 'Bhagat Singh' },
      { hi: 'चंद्रशेखर आज़ाद', en: 'Chandrashekhar Azad' },
      { hi: 'लाला लाजपत राय', en: 'Lala Lajpat Rai' },
    ],
    correct: 'A',
    category: 'history',
    difficulty: 'medium',
    explanation: { hi: '1943 में नेताजी सुभाष चंद्र बोस ने आज़ाद हिंद फौज का नेतृत्व किया।', en: 'Netaji Subhash Chandra Bose led the INA in 1943.' },
  },
  {
    text: { hi: 'संयुक्त राष्ट्र संघ की स्थापना किस वर्ष हुई?', en: 'In which year was the United Nations founded?' },
    options: [
      { hi: '1919', en: '1919' },
      { hi: '1945', en: '1945' },
      { hi: '1947', en: '1947' },
      { hi: '1950', en: '1950' },
    ],
    correct: 'B',
    category: 'current-affairs',
    difficulty: 'medium',
    explanation: { hi: 'संयुक्त राष्ट्र की स्थापना 24 अक्टूबर 1945 को हुई।', en: 'The UN was founded on 24 October 1945.' },
  },

  // ---- HARD (10) ----------------------------------------------------------
  {
    text: { hi: 'भारत की संविधान सभा के स्थायी अध्यक्ष कौन थे?', en: 'Who was the permanent president of India’s Constituent Assembly?' },
    options: [
      { hi: 'डॉ. राजेंद्र प्रसाद', en: 'Dr. Rajendra Prasad' },
      { hi: 'डॉ. बी.आर. अंबेडकर', en: 'Dr. B.R. Ambedkar' },
      { hi: 'जवाहरलाल नेहरू', en: 'Jawaharlal Nehru' },
      { hi: 'सरदार पटेल', en: 'Sardar Patel' },
    ],
    correct: 'A',
    category: 'history',
    difficulty: 'hard',
    explanation: { hi: 'डॉ. राजेंद्र प्रसाद संविधान सभा के स्थायी अध्यक्ष थे।', en: 'Dr. Rajendra Prasad was the permanent president of the Constituent Assembly.' },
  },
  {
    text: { hi: '‘अर्थशास्त्र’ ग्रंथ के रचनाकार कौन हैं?', en: 'Who is the author of the treatise ‘Arthashastra’?' },
    options: [
      { hi: 'कालिदास', en: 'Kalidasa' },
      { hi: 'चाणक्य (कौटिल्य)', en: 'Chanakya (Kautilya)' },
      { hi: 'पाणिनि', en: 'Panini' },
      { hi: 'भास', en: 'Bhasa' },
    ],
    correct: 'B',
    category: 'indian-culture',
    difficulty: 'hard',
    explanation: { hi: 'मौर्य काल के राजनीतिज्ञ चाणक्य ने ‘अर्थशास्त्र’ की रचना की।', en: 'Chanakya, the Mauryan statesman, authored the ‘Arthashastra’.' },
  },
  {
    text: { hi: 'वयस्क मानव शरीर में कुल कितनी हड्डियाँ होती हैं?', en: 'How many bones are there in an adult human body?' },
    options: [
      { hi: '196', en: '196' },
      { hi: '206', en: '206' },
      { hi: '216', en: '216' },
      { hi: '226', en: '226' },
    ],
    correct: 'B',
    category: 'science',
    difficulty: 'hard',
    explanation: { hi: 'वयस्क मानव शरीर में 206 हड्डियाँ होती हैं।', en: 'An adult human body has 206 bones.' },
  },
  {
    text: { hi: 'नोबेल पुरस्कार जीतने वाले पहले भारतीय कौन थे?', en: 'Who was the first Indian to win a Nobel Prize?' },
    options: [
      { hi: 'सी.वी. रमन', en: 'C.V. Raman' },
      { hi: 'रवींद्रनाथ टैगोर', en: 'Rabindranath Tagore' },
      { hi: 'हरगोबिंद खुराना', en: 'Hargobind Khorana' },
      { hi: 'मदर टेरेसा', en: 'Mother Teresa' },
    ],
    correct: 'B',
    category: 'general-knowledge',
    difficulty: 'hard',
    explanation: { hi: '1913 में रवींद्रनाथ टैगोर ने साहित्य का नोबेल जीता।', en: 'Rabindranath Tagore won the Nobel in Literature in 1913.' },
  },
  {
    text: { hi: '‘सत्यमेव जयते’ किस उपनिषद से लिया गया है?', en: 'From which Upanishad is ‘Satyameva Jayate’ taken?' },
    options: [
      { hi: 'कठोपनिषद', en: 'Katha Upanishad' },
      { hi: 'मुंडकोपनिषद', en: 'Mundaka Upanishad' },
      { hi: 'छांदोग्योपनिषद', en: 'Chandogya Upanishad' },
      { hi: 'ईशोपनिषद', en: 'Isha Upanishad' },
    ],
    correct: 'B',
    category: 'indian-culture',
    difficulty: 'hard',
    explanation: { hi: 'यह मुंडकोपनिषद का मंत्र है, राष्ट्रीय प्रतीक के नीचे अंकित है।', en: 'It is a mantra from the Mundaka Upanishad, inscribed below the national emblem.' },
  },
  {
    text: { hi: '1983 क्रिकेट विश्व कप के फाइनल में भारत ने किसे हराया?', en: 'Which team did India defeat in the 1983 Cricket World Cup final?' },
    options: [
      { hi: 'ऑस्ट्रेलिया', en: 'Australia' },
      { hi: 'इंग्लैंड', en: 'England' },
      { hi: 'वेस्टइंडीज', en: 'West Indies' },
      { hi: 'पाकिस्तान', en: 'Pakistan' },
    ],
    correct: 'C',
    category: 'sports',
    difficulty: 'hard',
    explanation: { hi: 'भारत ने लॉर्ड्स में वेस्टइंडीज को हराकर पहला विश्व कप जीता।', en: 'India beat the West Indies at Lord’s to win their first World Cup.' },
  },
  {
    text: { hi: 'माउंट एवरेस्ट की ऊँचाई लगभग कितनी है?', en: 'What is the approximate height of Mount Everest?' },
    options: [
      { hi: '8,611 मीटर', en: '8,611 m' },
      { hi: '8,848 मीटर', en: '8,848 m' },
      { hi: '8,448 मीटर', en: '8,448 m' },
      { hi: '9,028 मीटर', en: '9,028 m' },
    ],
    correct: 'B',
    category: 'geography',
    difficulty: 'hard',
    explanation: { hi: 'एवरेस्स्ट की ऊँचाई 8,848 मीटर है (8,611 मीटर K2 है)।', en: 'Everest stands 8,848 m tall (8,611 m is K2).' },
  },
  {
    text: { hi: 'प्रकाश की गति लगभग कितनी होती है?', en: 'What is the approximate speed of light?' },
    options: [
      { hi: '3 हज़ार किमी/सेकंड', en: '3,000 km/s' },
      { hi: '30 हज़ार किमी/सेकंड', en: '30,000 km/s' },
      { hi: '3 लाख किमी/सेकंड', en: '300,000 km/s' },
      { hi: '30 लाख किमी/सेकंड', en: '3,000,000 km/s' },
    ],
    correct: 'C',
    category: 'science',
    difficulty: 'hard',
    explanation: { hi: 'निर्वात में प्रकाश की गति लगभग 2,99,792 किमी/सेकंड है।', en: 'Light travels at ~299,792 km/s in vacuum.' },
  },
  {
    text: { hi: '‘भारत रत्न’ पुरस्कार की शुरुआत किस वर्ष हुई?', en: 'In which year was the ‘Bharat Ratna’ award instituted?' },
    options: [
      { hi: '1954', en: '1954' },
      { hi: '1950', en: '1950' },
      { hi: '1962', en: '1962' },
      { hi: '1947', en: '1947' },
    ],
    correct: 'A',
    category: 'general-knowledge',
    difficulty: 'hard',
    explanation: { hi: 'भारत रत्न 1954 में स्थापित भारत का सर्वोच्च नागरिक सम्मान है।', en: 'Bharat Ratna, instituted in 1954, is India’s highest civilian award.' },
  },
  {
    text: { hi: '‘वंदे मातरम्’ मूल रूप से किस रचना का हिस्सा है?', en: '‘Vande Mataram’ is originally part of which work?' },
    options: [
      { hi: 'रामचरितमानस', en: 'Ramcharitmanas' },
      { hi: 'आनंदमठ', en: 'Anandamath' },
      { hi: 'गीतांजलि', en: 'Gitanjali' },
      { hi: 'कामायनी', en: 'Kamayani' },
    ],
    correct: 'B',
    category: 'indian-culture',
    difficulty: 'hard',
    explanation: { hi: 'यह बंकिम चंद्र चटर्जी के उपन्यास ‘आनंदमठ’ (1882) से ली गई है।', en: 'It comes from Bankim Chandra Chatterjee’s novel ‘Anandamath’ (1882).' },
  },
];

const SEED_CONTESTANTS = [
  { name: 'Aarti Sharma', mobile: '9876543210', city: 'जयपुर' },
  { name: 'Rohit Verma', mobile: '9812345678', city: 'दिल्ली' },
  { name: 'Sneha Iyer', mobile: '9898989898', city: 'मुंबई' },
  { name: 'Vikram Singh', mobile: '9876501234', city: 'लखनऊ' },
];

async function main(): Promise<void> {
  await connectDb();

  const userCount = await User.countDocuments();
  if (userCount > 0 && !env.FORCE_SEED) {
    console.log(`Database already has ${userCount} users — seed skipped.`);
    console.log('Run with FORCE_SEED=true to wipe and reseed.');
    await disconnectDb();
    return;
  }

  if (env.FORCE_SEED) {
    console.log('FORCE_SEED=true — wiping existing data…');
    await Promise.all([
      User.deleteMany({}),
      Category.deleteMany({}),
      Question.deleteMany({}),
      Counter.deleteMany({}),
      Contestant.deleteMany({}),
      GameSession.deleteMany({}),
      PrizeLadderConfig.deleteMany({}),
      ThemeSetting.deleteMany({}),
      TimerSetting.deleteMany({}),
      LifelineSetting.deleteMany({}),
    ]);
  }

  // 1) Users
  const admin = await User.create({
    name: SEED_USERS[0].name,
    email: SEED_USERS[0].email,
    passwordHash: await hashPassword(SEED_USERS[0].password),
    role: SEED_USERS[0].role,
  });
  for (const u of SEED_USERS.slice(1)) {
    await User.create({ name: u.name, email: u.email, passwordHash: await hashPassword(u.password), role: u.role });
  }
  console.log(`✓ users: ${SEED_USERS.length}`);

  // 2) Categories
  const categoryDocs = await Category.create(SEED_CATEGORIES);
  const categoryBySlug = new Map(categoryDocs.map((c) => [c.slug, c._id]));
  console.log(`✓ categories: ${categoryDocs.length}`);

  // 3) Questions — codes Q001.., timer/points by difficulty
  const questionDocs = await Question.create(
    SEED_QUESTIONS.map((q, i) => ({
      code: `Q${String(i + 1).padStart(3, '0')}`,
      text: q.text,
      options: q.options.map((text, oi) => ({ key: (['A', 'B', 'C', 'D'] as const)[oi], text })),
      correctOption: q.correct,
      category: categoryBySlug.get(q.category),
      difficulty: q.difficulty,
      timerSeconds: TIMER_DEFAULTS_BY_DIFFICULTY[q.difficulty],
      points: POINTS_BY_DIFFICULTY[q.difficulty],
      explanation: q.explanation,
      status: 'active' as const,
      tags: [],
      createdBy: admin._id,
    })),
  );
  await Counter.findOneAndUpdate({ _id: 'question' }, { $set: { seq: questionDocs.length } }, { upsert: true });
  console.log(`✓ questions: ${questionDocs.length} (counter → ${questionDocs.length})`);

  // 4) Contestants
  const contestantDocs = await Contestant.create(SEED_CONTESTANTS.map((c) => ({ ...c, score: 0 })));
  console.log(`✓ contestants: ${contestantDocs.length}`);

  // 5) Default prize ladder
  const ladder = await PrizeLadderConfig.create({ name: 'Default Ladder', levels: DEFAULT_LADDER_LEVELS, isDefault: true });
  console.log('✓ prize ladder: 15 levels (safe havens 5 & 10)');

  // 6) Singletons (upsert so re-seeds don't duplicate)
  await ThemeSetting.findOneAndUpdate({ key: 'global' }, { $setOnInsert: { key: 'global' } }, { upsert: true });
  await TimerSetting.findOneAndUpdate(
    { key: 'global' },
    {
      $setOnInsert: {
        key: 'global',
        easy: TIMER_DEFAULTS_BY_DIFFICULTY.easy,
        medium: TIMER_DEFAULTS_BY_DIFFICULTY.medium,
        hard: TIMER_DEFAULTS_BY_DIFFICULTY.hard,
        max: TIMER_MAX_SECONDS,
      },
    },
    { upsert: true },
  );
  await LifelineSetting.findOneAndUpdate(
    { key: 'global' },
    {
      $setOnInsert: {
        key: 'global',
        fiftyFifty: { enabled: true, perContestant: 1 },
        audiencePoll: { enabled: true, perContestant: 1 },
        expertCall: { enabled: true, perContestant: 1, durationSeconds: 30 },
      },
    },
    { upsert: true },
  );
  console.log('✓ settings: theme, timers, lifelines');

  // 7) One draft session
  const session = await GameSession.create({
    name: 'Quiz 2024 — Grand Finale',
    code: 'KBL202',
    status: 'draft',
    questionIds: questionDocs.slice(0, 15).map((q) => q._id),
    currentQuestionIndex: -1,
    contestantOrder: contestantDocs.map((c) => c._id),
    rotationMode: 'round_robin',
    ladderConfigId: ladder._id,
    timerDefaults: {
      easy: TIMER_DEFAULTS_BY_DIFFICULTY.easy,
      medium: TIMER_DEFAULTS_BY_DIFFICULTY.medium,
      hard: TIMER_DEFAULTS_BY_DIFFICULTY.hard,
    },
    createdBy: admin._id,
  });
  console.log(`✓ session: "${session.name}" (display code KBL202, ${15} questions)`);

  console.log('\n──────────── seed complete ────────────');
  console.log('Login (super admin):');
  console.log(`  email:    ${SEED_USERS[0].email}`);
  console.log(`  password: ${SEED_USERS[0].password}`);
  console.log('Demo users:');
  for (const u of SEED_USERS.slice(1)) {
    console.log(`  ${u.role.padEnd(16)} ${u.email} / ${u.password}`);
  }
  console.log('────────────────────────────────────────');

  await disconnectDb();
}

main().catch((err: unknown) => {
  console.error('❌ seed failed:', err);
  process.exit(1);
});
