import type { Language } from '@cmm/shared';
import { LANGUAGES } from '@cmm/shared';

/** Resolve `?lang=` for GET routes (M04 §1) — defaults to `hi`. */
export function resolveLang(query: Record<string, unknown>): Language {
  const raw = typeof query.lang === 'string' ? query.lang.toLowerCase() : '';
  return (LANGUAGES as readonly string[]).includes(raw) ? (raw as Language) : 'hi';
}

/** Pick one language out of a bilingual field. */
export function pick(text: { hi: string; en: string }, lang: Language): string {
  return text[lang] ?? text.hi;
}
