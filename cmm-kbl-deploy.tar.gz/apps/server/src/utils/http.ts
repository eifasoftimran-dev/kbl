import type { RequestHandler, Response } from 'express';
import type { ApiErrorCode } from '@cmm/shared';
import { ERROR_STATUS } from '@cmm/shared';

/** Typed error → mapped to the API envelope by the central error handler (M04 §3). */
export class ApiError extends Error {
  readonly code: ApiErrorCode;
  readonly details?: unknown;

  constructor(code: ApiErrorCode, message: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.details = details;
  }

  get status(): number {
    return ERROR_STATUS[this.code];
  }
}

/** Success envelope: { ok: true, data } */
export function ok<T>(res: Response, data: T): void {
  res.status(200).json({ ok: true, data });
}

/** Wrap async controllers so rejections reach the central error handler (M04.3). */
export const asyncHandler =
  (fn: RequestHandler): RequestHandler =>
  (req, res, next) => {
    void Promise.resolve(fn(req, res, next)).catch(next);
  };
