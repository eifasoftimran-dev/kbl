import { z } from 'zod';

/** Pagination contract (M04 §1): ?page=1&limit=20, limit capped at 100. */
export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export interface Pagination {
  page: number;
  limit: number;
  skip: number;
}

export function parsePagination(query: Record<string, unknown>): Pagination {
  const { page, limit } = paginationSchema.parse(query);
  return { page, limit, skip: (page - 1) * limit };
}
