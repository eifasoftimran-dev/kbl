import pino from 'pino';

/** Structured logger (M12 §5): JSON to stdout, request-id correlated. */
export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  base: { app: 'cmm-kbl-server' },
});
