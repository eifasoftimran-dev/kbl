import type { Request, Response } from 'express';
import { z } from 'zod';
import { sessionCreateSchema, sessionUpdateSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { parsePagination } from '../../utils/list';
import { logAudit } from '../audit/audit.service';
import {
  createSession,
  getSession,
  listSessions,
  updateSession,
  type SessionFilter,
} from './session.service';

const listQuerySchema = z.object({
  search: z.string().trim().min(1).max(200).optional(),
  status: z.enum(['draft', 'live', 'paused', 'completed', 'cancelled']).optional(),
});

export async function listSessionsController(req: Request, res: Response): Promise<void> {
  const filter = listQuerySchema.parse(req.query) satisfies SessionFilter;
  const { page, limit } = parsePagination(req.query as Record<string, unknown>);
  ok(res, await listSessions(filter, page, limit));
}

export async function getSessionController(req: Request, res: Response): Promise<void> {
  ok(res, { session: await getSession(req.params.id) });
}

export async function createSessionController(req: Request, res: Response): Promise<void> {
  const input = sessionCreateSchema.parse(req.body);
  const session = await createSession(
    {
      name: input.name,
      questionIds: input.questionIds,
      contestantIds: input.contestantIds,
      rotationMode: input.rotationMode,
      onTimeout: input.onTimeout,
      dramaSeconds: input.dramaSeconds,
      buzzerMode: input.buzzerMode,
      ladderConfigId: input.ladderConfigId,
      lifelines: input.lifelines as Record<string, unknown> | undefined,
    },
    req.user!.id,
  );
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'session.create',
    targetType: 'session',
    targetId: session.id,
    payload: { code: session.code },
  });
  ok(res, { session });
}

export async function updateSessionController(req: Request, res: Response): Promise<void> {
  const input = sessionUpdateSchema.parse(req.body);
  const session = await updateSession(req.params.id, {
    ...(input.name !== undefined ? { name: input.name } : {}),
    ...(input.questionIds !== undefined ? { questionIds: input.questionIds } : {}),
    ...(input.contestantIds !== undefined ? { contestantIds: input.contestantIds } : {}),
    ...(input.rotationMode !== undefined ? { rotationMode: input.rotationMode } : {}),
    ...(input.onTimeout !== undefined ? { onTimeout: input.onTimeout } : {}),
    ...(input.dramaSeconds !== undefined ? { dramaSeconds: input.dramaSeconds } : {}),
    ...(input.buzzerMode !== undefined ? { buzzerMode: input.buzzerMode } : {}),
    ...(input.ladderConfigId !== undefined ? { ladderConfigId: input.ladderConfigId } : {}),
    ...(input.lifelines !== undefined ? { lifelines: input.lifelines as Record<string, unknown> } : {}),
  });
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'session.configure',
    targetType: 'session',
    targetId: req.params.id,
    payload: { fields: Object.keys(input) },
  });
  ok(res, { session });
}
