import { Schema, model } from 'mongoose';
import { DEFAULT_LADDER } from '@cmm/shared';

/** PrizeLadderConfig model (docs/plans/03-database-models.md §2.8) */
const ladderConfigSchema = new Schema({
  name: { type: String, required: true, trim: true },
  levels: {
    type: [
      {
        level: { type: Number, required: true, min: 1, max: 15 },
        amount: { type: Number, required: true, min: 0 },
        isSafeHaven: { type: Boolean, default: false },
      },
    ],
    required: true,
    validate: {
      validator: (levels: unknown[]) => levels.length === 15,
      message: 'Ladder must have exactly 15 levels',
    },
  },
  isDefault: { type: Boolean, default: false },
});

export interface LadderLevelDoc {
  level: number;
  amount: number;
  isSafeHaven: boolean;
}

export interface LadderConfigDoc {
  _id: unknown;
  name: string;
  levels: LadderLevelDoc[];
  isDefault: boolean;
}

export const PrizeLadderConfig = model<LadderConfigDoc>('PrizeLadderConfig', ladderConfigSchema);

/** The default 15-level ladder (₹500 → ₹1,00,00,000, safe havens 5 & 10). */
export const DEFAULT_LADDER_LEVELS = DEFAULT_LADDER.map((l) => ({ ...l }));
