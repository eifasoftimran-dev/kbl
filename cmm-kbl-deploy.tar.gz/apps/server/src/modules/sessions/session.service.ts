import type { Paginated, SessionSummaryDTO } from '@cmm/shared';
import { ApiError } from '../../utils/http';
import type { SessionDoc } from './session.model';
import { GameSession } from './session.model';

function toSessionSummaryDTO(doc: SessionDoc): SessionSummaryDTO {
  return {
    id: String(doc._id),
    name: doc.name,
    code: doc.code,
    status: doc.status,
    totalQuestions: doc.questionIds.length,
    currentQuestionIndex: doc.currentQuestionIndex,
    contestantIds: doc.contestantOrder.map(String),
    startedAt: doc.startedAt?.toISOString() ?? null,
    endedAt: doc.endedAt?.toISOString() ?? null,
  };
}

export interface SessionFilter {
  status?: string;
  search?: string;
}

export async function listSessions(
  filter: SessionFilter,
  page: number,
  limit: number,
): Promise<Paginated<SessionSummaryDTO>> {
  const query: Record<string, unknown> = {};
  if (filter.status) query.status = filter.status;
  if (filter.search) {
    query.name = { $regex: filter.search, $options: 'i' };
  }

  const [docs, total] = await Promise.all([
    GameSession.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .exec(),
    GameSession.countDocuments(query),
  ]);

  return { items: docs.map(toSessionSummaryDTO), total, page, limit };
}

export async function getSession(id: string): Promise<SessionSummaryDTO> {
  const doc = await GameSession.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Session not found');
  return toSessionSummaryDTO(doc);
}

export async function createSession(
  input: {
    name: string;
    questionIds: string[];
    contestantIds: string[];
    rotationMode?: string;
    onTimeout?: string;
    dramaSeconds?: number;
    buzzerMode?: boolean;
    ladderConfigId?: string;
    lifelines?: Record<string, unknown>;
  },
  userId: string,
): Promise<SessionSummaryDTO> {
  // generate a 6-char uppercase join code
  const code = generateCode();
  const existing = await GameSession.findOne({ code }).exec();
  if (existing) throw new ApiError('CONFLICT', 'Session code collision — try again');

  const doc = await GameSession.create({
    name: input.name,
    code,
    questionIds: input.questionIds,
    contestantOrder: input.contestantIds,
    rotationMode: input.rotationMode ?? 'round_robin',
    settings: {
      buzzerMode: input.buzzerMode ?? false,
      onTimeout: input.onTimeout ?? 'reveal_wrong',
      dramaSeconds: input.dramaSeconds ?? 2,
      ...(input.lifelines ? { lifelines: input.lifelines } : {}),
    },
    ladderConfigId: input.ladderConfigId ?? null,
    createdBy: userId,
  });
  return toSessionSummaryDTO(doc);
}

export async function updateSession(
  id: string,
  input: Partial<{
    name: string;
    questionIds: string[];
    contestantIds: string[];
    rotationMode: string;
    onTimeout: string;
    dramaSeconds: number;
    buzzerMode: boolean;
    ladderConfigId: string;
    lifelines: Record<string, unknown>;
  }>,
): Promise<SessionSummaryDTO> {
  const doc = await GameSession.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Session not found');
  if (doc.status !== 'draft') {
    throw new ApiError('CONFLICT', 'Only draft sessions can be configured');
  }

  if (input.name !== undefined) doc.name = input.name;
  if (input.questionIds !== undefined) doc.questionIds = input.questionIds as unknown as SessionDoc['questionIds'];
  if (input.contestantIds !== undefined) doc.contestantOrder = input.contestantIds as unknown as SessionDoc['contestantOrder'];
  if (input.rotationMode !== undefined) doc.rotationMode = input.rotationMode as SessionDoc['rotationMode'];
  if (input.buzzerMode !== undefined) doc.settings.buzzerMode = input.buzzerMode;
  if (input.onTimeout !== undefined) doc.settings.onTimeout = input.onTimeout as SessionDoc['settings']['onTimeout'];
  if (input.dramaSeconds !== undefined) doc.settings.dramaSeconds = input.dramaSeconds;
  if (input.ladderConfigId !== undefined) doc.ladderConfigId = input.ladderConfigId as unknown as SessionDoc['ladderConfigId'];
  if (input.lifelines) {
    Object.assign(doc.settings.lifelines, input.lifelines);
  }

  await doc.save();
  return toSessionSummaryDTO(doc);
}

function generateCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I/O/0/1 ambiguity
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}
