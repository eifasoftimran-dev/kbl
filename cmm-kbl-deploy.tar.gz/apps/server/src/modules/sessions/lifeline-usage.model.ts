import { Schema, model } from 'mongoose';
import type { LifelineType } from '@cmm/shared';
import { LIFELINE_TYPES } from '@cmm/shared';

/** LifelineUsage model (docs/plans/03-database-models.md §2.7) */
const lifelineUsageSchema = new Schema(
  {
    sessionId: { type: Schema.Types.ObjectId, ref: 'GameSession', required: true },
    contestantId: { type: Schema.Types.ObjectId, ref: 'Contestant', required: true },
    questionIndex: { type: Number, required: true },
    type: { type: String, enum: LIFELINE_TYPES, required: true },
    resultData: { type: Schema.Types.Mixed, required: true },
    usedAt: { type: Date, default: () => new Date() },
  },
);

lifelineUsageSchema.index({ sessionId: 1, contestantId: 1, type: 1 });

export interface LifelineUsageDoc {
  _id: unknown;
  sessionId: unknown;
  contestantId: unknown;
  questionIndex: number;
  type: LifelineType;
  resultData: Record<string, unknown>;
  usedAt?: Date;
}

export const LifelineUsage = model<LifelineUsageDoc>('LifelineUsage', lifelineUsageSchema);
