import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import {
  createSessionController,
  getSessionController,
  listSessionsController,
  updateSessionController,
} from './session.controller';

/** Sessions routes (M04 §2.5). */
export const sessionsRouter = Router();

sessionsRouter.get('/', requirePermission('sessions.read'), asyncHandler(listSessionsController));
sessionsRouter.get('/:id', requirePermission('sessions.read'), asyncHandler(getSessionController));
sessionsRouter.post('/', requirePermission('sessions.create'), asyncHandler(createSessionController));
sessionsRouter.patch('/:id', requirePermission('sessions.configure'), asyncHandler(updateSessionController));
