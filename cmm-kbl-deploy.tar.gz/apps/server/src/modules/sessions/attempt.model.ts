import { Schema, model } from 'mongoose';
import type { LifelineType, OptionKey } from '@cmm/shared';
import { LIFELINE_TYPES, OPTION_KEYS } from '@cmm/shared';

/** QuestionAttempt model (docs/plans/03-database-models.md §2.6) */
const attemptSchema = new Schema(
  {
    sessionId: { type: Schema.Types.ObjectId, ref: 'GameSession', required: true },
    questionId: { type: Schema.Types.ObjectId, ref: 'Question', required: true },
    questionIndex: { type: Number, required: true },
    contestantId: { type: Schema.Types.ObjectId, ref: 'Contestant', required: true },
    selectedOption: { type: String, enum: OPTION_KEYS, default: null }, // null = timeout
    isCorrect: { type: Boolean, required: true },
    pointsAwarded: { type: Number, required: true, default: 0 },
    responseMs: { type: Number, default: null }, // lock time − question start
    lifelinesUsed: { type: [String], enum: LIFELINE_TYPES, default: [] },
    lockedAt: { type: Date, default: null },
    revealedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

attemptSchema.index({ sessionId: 1, questionIndex: 1 });
attemptSchema.index({ sessionId: 1, contestantId: 1 });
attemptSchema.index({ questionId: 1 });

export interface AttemptDoc {
  _id: unknown;
  sessionId: unknown;
  questionId: unknown;
  questionIndex: number;
  contestantId: unknown;
  selectedOption?: OptionKey | null;
  isCorrect: boolean;
  pointsAwarded: number;
  responseMs?: number | null;
  lifelinesUsed: LifelineType[];
  lockedAt?: Date | null;
  revealedAt?: Date | null;
}

export const QuestionAttempt = model<AttemptDoc>('QuestionAttempt', attemptSchema);
