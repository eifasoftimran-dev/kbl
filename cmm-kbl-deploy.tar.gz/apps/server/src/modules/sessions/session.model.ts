import { Schema, model, type Types } from 'mongoose';
import type { GamePhase, RotationMode, SessionStatus } from '@cmm/shared';
import { ROTATION_MODES, SESSION_STATUSES } from '@cmm/shared';

/** GameSession model (docs/plans/03-database-models.md §2.5) */
const sessionSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    code: { type: String, required: true, unique: true }, // 6-char public display join code
    status: { type: String, enum: SESSION_STATUSES, default: 'draft' },
    questionIds: { type: [Schema.Types.ObjectId], ref: 'Question', default: [] },
    currentQuestionIndex: { type: Number, default: -1 }, // 0-based; -1 before start
    activeContestantId: { type: Schema.Types.ObjectId, ref: 'Contestant', default: null },
    contestantOrder: { type: [Schema.Types.ObjectId], ref: 'Contestant', default: [] },
    rotationMode: { type: String, enum: ROTATION_MODES, default: 'round_robin' },
    settings: {
      lifelines: {
        fiftyFifty: {
          enabled: { type: Boolean, default: true },
          perContestant: { type: Number, default: 1 },
        },
        audiencePoll: {
          enabled: { type: Boolean, default: true },
          perContestant: { type: Number, default: 1 },
        },
        expertCall: {
          enabled: { type: Boolean, default: true },
          perContestant: { type: Number, default: 1 },
          durationSeconds: { type: Number, default: 30 },
        },
      },
      buzzerMode: { type: Boolean, default: false },
      onTimeout: { type: String, enum: ['reveal_wrong', 'pause_for_host'], default: 'reveal_wrong' },
      dramaSeconds: { type: Number, default: 2.5 },
    },
    ladderConfigId: { type: Schema.Types.ObjectId, ref: 'PrizeLadderConfig' },
    timerDefaults: {
      easy: { type: Number, default: 30 },
      medium: { type: Number, default: 30 },
      hard: { type: Number, default: 45 },
    },
    startedAt: { type: Date, default: null },
    endedAt: { type: Date, default: null },
    /** last emitted GameView — server restart rehydration (M03 §3, M07 §1) */
    stateSnapshot: { type: Schema.Types.Mixed, default: null },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true },
);

sessionSchema.index({ status: 1, startedAt: -1 });

export interface SessionSettingsDoc {
  lifelines: {
    fiftyFifty: { enabled: boolean; perContestant: number };
    audiencePoll: { enabled: boolean; perContestant: number };
    expertCall: { enabled: boolean; perContestant: number; durationSeconds: number };
  };
  buzzerMode: boolean;
  onTimeout: 'reveal_wrong' | 'pause_for_host';
  dramaSeconds: number;
}

export interface SessionDoc {
  _id: unknown;
  name: string;
  code: string;
  status: SessionStatus;
  questionIds: Types.ObjectId[];
  currentQuestionIndex: number;
  activeContestantId?: Types.ObjectId | null;
  contestantOrder: Types.ObjectId[];
  rotationMode: RotationMode;
  settings: SessionSettingsDoc;
  ladderConfigId?: Types.ObjectId | null;
  timerDefaults: { easy: number; medium: number; hard: number };
  startedAt?: Date | null;
  endedAt?: Date | null;
  stateSnapshot?: { phase?: GamePhase; [k: string]: unknown } | null;
  createdBy: unknown;
}

export const GameSession = model<SessionDoc>('GameSession', sessionSchema);
