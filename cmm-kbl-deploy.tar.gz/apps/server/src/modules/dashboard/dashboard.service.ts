import type { DashboardStatsDTO } from '@cmm/shared';
import { Category } from '../questions/category.model';
import { Contestant } from '../contestants/contestant.model';
import { GameSession } from '../sessions/session.model';
import { Question } from '../questions/question.model';

export async function getDashboardStats(): Promise<DashboardStatsDTO> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [
    totalQuestions,
    categoryCount,
    contestantTotal,
    contestantActive,
    liveSessionsToday,
    completedSessionsToday,
    activeGame,
  ] = await Promise.all([
    Question.countDocuments({ deletedAt: null }),
    Category.countDocuments(),
    Contestant.countDocuments({ deletedAt: null }),
    Contestant.countDocuments({ deletedAt: null, isActive: true }),
    GameSession.countDocuments({ status: 'live', startedAt: { $gte: today } }),
    GameSession.countDocuments({ status: 'completed', endedAt: { $gte: today } }),
    GameSession.findOne({ status: { $in: ['live', 'paused'] } })
      .sort({ startedAt: -1 })
      .lean()
      .exec(),
  ]);

  return {
    activeGame: activeGame
      ? {
          sessionId: String(activeGame._id),
          name: activeGame.name,
          code: activeGame.code,
          phase: activeGame.stateSnapshot?.phase ?? 'idle',
          questionIndex: activeGame.currentQuestionIndex,
          total: activeGame.questionIds.length,
        }
      : null,
    totalQuestions,
    categoryCount,
    contestants: { total: contestantTotal, active: contestantActive },
    todaySessions: { live: liveSessionsToday, completed: completedSessionsToday },
  };
}
