import type { Request, Response } from 'express';
import { ok } from '../../utils/http';
import { getDashboardStats } from './dashboard.service';

export async function dashboardStatsController(_req: Request, res: Response): Promise<void> {
  ok(res, await getDashboardStats());
}
