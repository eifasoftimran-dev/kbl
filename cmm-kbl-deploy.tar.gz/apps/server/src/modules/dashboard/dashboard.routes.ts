import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import { dashboardStatsController } from './dashboard.controller';

/** Dashboard routes (M04 §2.1). */
export const dashboardRouter = Router();

dashboardRouter.get('/stats', requirePermission('dashboard.view'), asyncHandler(dashboardStatsController));
