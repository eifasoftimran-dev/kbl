import { Schema, model } from 'mongoose';
import { TIMER_DEFAULTS_BY_DIFFICULTY, TIMER_MAX_SECONDS } from '@cmm/shared';

/** TimerSetting singleton (key: 'global') — defaults per difficulty (M08 §3.9) */
const timerSettingSchema = new Schema({
  key: { type: String, required: true, unique: true, default: 'global' },
  easy: { type: Number, default: TIMER_DEFAULTS_BY_DIFFICULTY.easy, min: 10, max: 120 },
  medium: { type: Number, default: TIMER_DEFAULTS_BY_DIFFICULTY.medium, min: 10, max: 120 },
  hard: { type: Number, default: TIMER_DEFAULTS_BY_DIFFICULTY.hard, min: 10, max: 120 },
  max: { type: Number, default: TIMER_MAX_SECONDS, min: 10, max: 120 },
});

export interface TimerSettingDoc {
  _id: unknown;
  key: string;
  easy: number;
  medium: number;
  hard: number;
  max: number;
}

export const TimerSetting = model<TimerSettingDoc>('TimerSetting', timerSettingSchema);

/** LifelineSetting singleton (key: 'global') — global defaults (M08 §3.7) */
const lifelineSettingSchema = new Schema({
  key: { type: String, required: true, unique: true, default: 'global' },
  fiftyFifty: {
    enabled: { type: Boolean, default: true },
    perContestant: { type: Number, default: 1 },
  },
  audiencePoll: {
    enabled: { type: Boolean, default: true },
    perContestant: { type: Number, default: 1 },
  },
  expertCall: {
    enabled: { type: Boolean, default: true },
    perContestant: { type: Number, default: 1 },
    durationSeconds: { type: Number, default: 30 },
  },
});

export interface LifelineSettingDoc {
  _id: unknown;
  key: string;
  fiftyFifty: { enabled: boolean; perContestant: number };
  audiencePoll: { enabled: boolean; perContestant: number };
  expertCall: { enabled: boolean; perContestant: number; durationSeconds: number };
}

export const LifelineSetting = model<LifelineSettingDoc>('LifelineSetting', lifelineSettingSchema);
