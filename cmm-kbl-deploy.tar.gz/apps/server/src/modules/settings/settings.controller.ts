import type { Request, Response } from 'express';
import {
  lifelinesSettingsSchema,
  prizeLadderSettingsSchema,
  themeSettingsSchema,
  timerSettingsSchema,
} from '@cmm/shared';
import { ok } from '../../utils/http';
import { logAudit } from '../audit/audit.service';
import {
  getLifelineSettings,
  getPrizeLadder,
  getThemeSettings,
  getTimerSettings,
  updateLifelineSettings,
  updatePrizeLadder,
  updateThemeSettings,
  updateTimerSettings,
} from './settings.service';

// --- theme ---

export async function getThemeController(_req: Request, res: Response): Promise<void> {
  ok(res, { theme: await getThemeSettings() });
}

export async function updateThemeController(req: Request, res: Response): Promise<void> {
  const input = themeSettingsSchema.parse(req.body);
  const theme = await updateThemeSettings(input);
  logAudit({ actorId: req.user!.id, actorRole: req.user!.role, action: 'settings.theme', targetType: 'settings' });
  ok(res, { theme });
}

// --- timer ---

export async function getTimerController(_req: Request, res: Response): Promise<void> {
  ok(res, { timer: await getTimerSettings() });
}

export async function updateTimerController(req: Request, res: Response): Promise<void> {
  const input = timerSettingsSchema.parse(req.body);
  const timer = await updateTimerSettings(input);
  logAudit({ actorId: req.user!.id, actorRole: req.user!.role, action: 'settings.timer', targetType: 'settings' });
  ok(res, { timer });
}

// --- lifelines ---

export async function getLifelineController(_req: Request, res: Response): Promise<void> {
  ok(res, { lifelines: await getLifelineSettings() });
}

export async function updateLifelineController(req: Request, res: Response): Promise<void> {
  const input = lifelinesSettingsSchema.parse(req.body);
  const lifelines = await updateLifelineSettings(input);
  logAudit({ actorId: req.user!.id, actorRole: req.user!.role, action: 'settings.lifeline', targetType: 'settings' });
  ok(res, { lifelines });
}

// --- prize ladder ---

export async function getLadderController(_req: Request, res: Response): Promise<void> {
  ok(res, await getPrizeLadder());
}

export async function updateLadderController(req: Request, res: Response): Promise<void> {
  const input = prizeLadderSettingsSchema.parse(req.body);
  const ladder = await updatePrizeLadder(input);
  logAudit({ actorId: req.user!.id, actorRole: req.user!.role, action: 'settings.ladder', targetType: 'settings' });
  ok(res, ladder);
}
