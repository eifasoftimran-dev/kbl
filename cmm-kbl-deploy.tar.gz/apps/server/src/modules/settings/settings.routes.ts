import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import {
  getLadderController,
  getLifelineController,
  getThemeController,
  getTimerController,
  updateLadderController,
  updateLifelineController,
  updateThemeController,
  updateTimerController,
} from './settings.controller';

/** Settings routes (M04 §2.6). */
export const settingsRouter = Router();

// Theme
settingsRouter.get('/theme', requirePermission('settings.read'), asyncHandler(getThemeController));
settingsRouter.put('/theme', requirePermission('settings.write'), asyncHandler(updateThemeController));

// Timer
settingsRouter.get('/timer', requirePermission('settings.read'), asyncHandler(getTimerController));
settingsRouter.put('/timer', requirePermission('settings.write'), asyncHandler(updateTimerController));

// Lifelines
settingsRouter.get('/lifelines', requirePermission('settings.read'), asyncHandler(getLifelineController));
settingsRouter.put('/lifelines', requirePermission('settings.write'), asyncHandler(updateLifelineController));

// Prize ladder
settingsRouter.get('/ladder', requirePermission('settings.read'), asyncHandler(getLadderController));
settingsRouter.put('/ladder', requirePermission('settings.write'), asyncHandler(updateLadderController));
