import type { ThemeSettingsDTO, ThemeSettingsInput } from '@cmm/shared';
import { ApiError } from '../../utils/http';
import type { ThemeSettingDoc } from './theme-setting.model';
import { ThemeSetting } from './theme-setting.model';
import { LifelineSetting, TimerSetting } from './settings.models';
import type { LadderLevel } from '@cmm/shared';
import { PrizeLadderConfig } from '../sessions/ladder-config.model';

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

function toThemeDTO(doc: ThemeSettingDoc): ThemeSettingsDTO {
  return {
    logoUrl: doc.logoAssetId ? `/uploads/${String(doc.logoAssetId)}` : null,
    brandPrimary: doc.brandPrimary,
    brandAccent: doc.brandAccent,
    ledLayout: doc.ledLayout,
    buzzerMode: doc.buzzerMode,
    defaultLanguage: doc.defaultLanguage,
    showHostIllustration: doc.showHostIllustration,
    showReflection: doc.showReflection,
    slogans: {
      topLeft: { hi: doc.slogans.topLeft.hi, en: doc.slogans.topLeft.en },
      center: { hi: doc.slogans.center.hi, en: doc.slogans.center.en },
      topRight: { hi: doc.slogans.topRight.hi, en: doc.slogans.topRight.en },
    },
  };
}

export async function getThemeSettings(): Promise<ThemeSettingsDTO> {
  const doc = await ThemeSetting.findOne({ key: 'global' }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Theme settings not initialised');
  return toThemeDTO(doc);
}

export async function updateThemeSettings(input: ThemeSettingsInput): Promise<ThemeSettingsDTO> {
  const doc = await ThemeSetting.findOneAndUpdate(
    { key: 'global' },
    {
      $set: {
        brandPrimary: input.brandPrimary,
        brandAccent: input.brandAccent,
        ledLayout: input.ledLayout,
        buzzerMode: input.buzzerMode,
        defaultLanguage: input.defaultLanguage,
        showHostIllustration: input.showHostIllustration,
        showReflection: input.showReflection,
        slogans: input.slogans,
        logoAssetId: input.logoAssetId ?? null,
      },
    },
    { new: true, upsert: true },
  ).exec();
  return toThemeDTO(doc as unknown as ThemeSettingDoc);
}

// ---------------------------------------------------------------------------
// Timer
// ---------------------------------------------------------------------------

export async function getTimerSettings(): Promise<{ easy: number; medium: number; hard: number; max: number }> {
  const doc = await TimerSetting.findOne({ key: 'global' }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Timer settings not initialised');
  return { easy: doc.easy, medium: doc.medium, hard: doc.hard, max: doc.max };
}

export async function updateTimerSettings(input: {
  easy: number;
  medium: number;
  hard: number;
  max: number;
}): Promise<{ easy: number; medium: number; hard: number; max: number }> {
  const doc = await TimerSetting.findOneAndUpdate(
    { key: 'global' },
    { $set: input },
    { new: true, upsert: true },
  ).exec();
  return { easy: doc.easy, medium: doc.medium, hard: doc.hard, max: doc.max };
}

// ---------------------------------------------------------------------------
// Lifelines
// ---------------------------------------------------------------------------

export async function getLifelineSettings(): Promise<{
  fiftyFifty: { enabled: boolean; perContestant: number };
  audiencePoll: { enabled: boolean; perContestant: number };
  expertCall: { enabled: boolean; perContestant: number; durationSeconds: number };
}> {
  const doc = await LifelineSetting.findOne({ key: 'global' }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Lifeline settings not initialised');
  return {
    fiftyFifty: { enabled: doc.fiftyFifty.enabled, perContestant: doc.fiftyFifty.perContestant },
    audiencePoll: { enabled: doc.audiencePoll.enabled, perContestant: doc.audiencePoll.perContestant },
    expertCall: {
      enabled: doc.expertCall.enabled,
      perContestant: doc.expertCall.perContestant,
      durationSeconds: doc.expertCall.durationSeconds,
    },
  };
}

export async function updateLifelineSettings(input: {
  fiftyFifty?: { enabled: boolean; perContestant: number };
  audiencePoll?: { enabled: boolean; perContestant: number };
  expertCall?: { enabled: boolean; perContestant: number; durationSeconds: number };
}): Promise<ReturnType<typeof getLifelineSettings> extends Promise<infer T> ? T : never> {
  const $set: Record<string, unknown> = {};
  if (input.fiftyFifty) {
    $set['fiftyFifty.enabled'] = input.fiftyFifty.enabled;
    $set['fiftyFifty.perContestant'] = input.fiftyFifty.perContestant;
  }
  if (input.audiencePoll) {
    $set['audiencePoll.enabled'] = input.audiencePoll.enabled;
    $set['audiencePoll.perContestant'] = input.audiencePoll.perContestant;
  }
  if (input.expertCall) {
    $set['expertCall.enabled'] = input.expertCall.enabled;
    $set['expertCall.perContestant'] = input.expertCall.perContestant;
    $set['expertCall.durationSeconds'] = input.expertCall.durationSeconds;
  }

  const doc = await LifelineSetting.findOneAndUpdate(
    { key: 'global' },
    { $set },
    { new: true, upsert: true },
  ).exec();
  return {
    fiftyFifty: { enabled: doc.fiftyFifty.enabled, perContestant: doc.fiftyFifty.perContestant },
    audiencePoll: { enabled: doc.audiencePoll.enabled, perContestant: doc.audiencePoll.perContestant },
    expertCall: {
      enabled: doc.expertCall.enabled,
      perContestant: doc.expertCall.perContestant,
      durationSeconds: doc.expertCall.durationSeconds,
    },
  };
}

// ---------------------------------------------------------------------------
// Prize ladder
// ---------------------------------------------------------------------------

export async function getPrizeLadder(): Promise<{ levels: LadderLevel[] }> {
  const doc = await PrizeLadderConfig.findOne({ isDefault: true }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Prize ladder not initialised');
  return {
    levels: doc.levels.map((l) => ({ level: l.level, amount: l.amount, isSafeHaven: l.isSafeHaven })),
  };
}

export async function updatePrizeLadder(input: { levels: LadderLevel[] }): Promise<{ levels: LadderLevel[] }> {
  const doc = await PrizeLadderConfig.findOne({ isDefault: true }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Prize ladder not initialised');
  doc.levels = input.levels;
  await doc.save();
  return {
    levels: doc.levels.map((l) => ({ level: l.level, amount: l.amount, isSafeHaven: l.isSafeHaven })),
  };
}
