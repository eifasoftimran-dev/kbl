import { Schema, model } from 'mongoose';
import type { Language, LedLayout, LocalText } from '@cmm/shared';
import { LED_LAYOUTS, LANGUAGES } from '@cmm/shared';

/** ThemeSetting singleton (key: 'global') — docs/plans/03-database-models.md §2.9 */
const themeSettingSchema = new Schema({
  key: { type: String, required: true, unique: true, default: 'global' },
  logoAssetId: { type: Schema.Types.ObjectId, ref: 'MediaAsset', default: null },
  brandPrimary: { type: String, default: '#1E5BFF', match: /^#[0-9a-fA-F]{6}$/ },
  brandAccent: { type: String, default: '#FFC93C', match: /^#[0-9a-fA-F]{6}$/ },
  ledLayout: { type: String, enum: LED_LAYOUTS, default: 'classic' },
  buzzerMode: { type: Boolean, default: false },
  defaultLanguage: { type: String, enum: LANGUAGES, default: 'hi' },
  showHostIllustration: { type: Boolean, default: true },
  showReflection: { type: Boolean, default: true },
  slogans: {
    topLeft: {
      hi: { type: String, default: 'ज्ञान से बदलती है किस्मत' },
      en: { type: String, default: 'Knowledge Changes Destiny' },
    },
    center: {
      hi: { type: String, default: 'सोचो • चुनो • जीतो' },
      en: { type: String, default: 'Think • Choose • Win' },
    },
    topRight: {
      hi: { type: String, default: 'बड़े सवाल बड़े सपने' },
      en: { type: String, default: 'Big Questions, Big Dreams' },
    },
  },
});

export interface ThemeSettingDoc {
  _id: unknown;
  key: string;
  logoAssetId?: unknown;
  brandPrimary: string;
  brandAccent: string;
  ledLayout: LedLayout;
  buzzerMode: boolean;
  defaultLanguage: Language;
  showHostIllustration: boolean;
  showReflection: boolean;
  slogans: { topLeft: LocalText; center: LocalText; topRight: LocalText };
}

export const ThemeSetting = model<ThemeSettingDoc>('ThemeSetting', themeSettingSchema);
