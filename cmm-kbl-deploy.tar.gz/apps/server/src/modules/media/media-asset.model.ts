import { Schema, model } from 'mongoose';

/** MediaAsset model (docs/plans/03-database-models.md §2.10) */
const mediaAssetSchema = new Schema(
  {
    fileName: { type: String, required: true }, // uuid + ext on disk
    originalName: { type: String, required: true },
    mimeType: { type: String, required: true },
    kind: { type: String, enum: ['image', 'video', 'audio'], required: true },
    size: { type: Number, required: true }, // bytes
    storage: { type: String, enum: ['local', 's3'], default: 'local' },
    path: { type: String, required: true }, // relative path / object key
    thumbPath: { type: String, default: null },
    meta: {
      width: { type: Number, default: null },
      height: { type: Number, default: null },
      durationSeconds: { type: Number, default: null },
    },
    uploadedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true },
);

mediaAssetSchema.index({ kind: 1, createdAt: -1 });

export interface MediaAssetDoc {
  _id: unknown;
  fileName: string;
  originalName: string;
  mimeType: string;
  kind: 'image' | 'video' | 'audio';
  size: number;
  storage: 'local' | 's3';
  path: string;
  thumbPath?: string | null;
  meta: { width?: number | null; height?: number | null; durationSeconds?: number | null };
  uploadedBy: unknown;
}

export const MediaAsset = model<MediaAssetDoc>('MediaAsset', mediaAssetSchema);
