/**
 * HTTP control route (M07 §10 — single funnel).
 * All game control actions can be triggered via HTTP as well as sockets.
 * Both paths funnel into runtime.dispatch().
 */
import { Router } from 'express';
import { requirePermission } from '../../middlewares/rbac';
import { requireAuth } from '../../middlewares/auth';
import { asyncHandler, ok } from '../../utils/http';
import { runtimeRegistry } from '../../realtime/game/game-session-runtime';
import type { OptionKey, LifelineType } from '@cmm/shared';
import type { Request } from 'express';

export const controlRouter = Router();

/** GET /api/control/:sessionId/status — get current GameView */
controlRouter.get(
  '/:sessionId/status',
  requireAuth,
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) {
      // Try to hydrate
      const { Server } = await import('socket.io');
      // Without io reference, return session data from DB
      const { GameSession } = await import('../../modules/sessions/session.model');
      const session = await GameSession.findById(req.params.sessionId).lean().exec();
      if (!session) {
        res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not found' } });
        return;
      }
      ok(res, { phase: session.stateSnapshot?.phase ?? session.status, status: session.status, snapshot: session.stateSnapshot });
      return;
    }
    const view = await rt.getGameView();
    ok(res, view);
  }),
);

/** POST /api/control/:sessionId/start */
controlRouter.post(
  '/:sessionId/start',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const io = (req.app.get('io') as import('socket.io').Server);
    const rt = await runtimeRegistry.getOrCreate(req.params.sessionId, io);
    // Load first question BEFORE start so the intro broadcast includes it
    await rt.loadQuestion(0);
    const result = await rt.dispatchAction({ type: 'start', actorId: req.user!.id });
    if (!result.ok) {
      res.status(400).json({ ok: false, error: result.error });
      return;
    }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/pause */
controlRouter.post(
  '/:sessionId/pause',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'pause', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/resume */
controlRouter.post(
  '/:sessionId/resume',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'resume', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/select */
controlRouter.post(
  '/:sessionId/select',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'select', optionKey: req.body.optionKey as OptionKey, actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/lock */
controlRouter.post(
  '/:sessionId/lock',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'lock', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/reveal */
controlRouter.post(
  '/:sessionId/reveal',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'reveal', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/next */
controlRouter.post(
  '/:sessionId/next',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    // Guard: no more questions — the operator should end the session instead
    const nextIndex = rt.getState().questionIndex + 1;
    if (!rt.hasQuestion(nextIndex)) {
      res.status(400).json({ ok: false, error: { code: 'NO_MORE_QUESTIONS', message: 'No more questions in this session — end the game instead' } });
      return;
    }
    // Load next question BEFORE dispatch so the intro broadcast includes it
    await rt.loadQuestion(nextIndex);
    const result = await rt.dispatchAction({ type: 'next', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/end */
controlRouter.post(
  '/:sessionId/end',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'end', actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/reset */
controlRouter.post(
  '/:sessionId/reset',
  requirePermission('game.control'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'reset', confirm: true, actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    ok(res, { phase: rt.getState().phase });
  }),
);

/** POST /api/control/:sessionId/lifeline */
controlRouter.post(
  '/:sessionId/lifeline',
  requirePermission('lifelines.use'),
  asyncHandler(async (req: Request, res) => {
    const rt = runtimeRegistry.get(req.params.sessionId);
    if (!rt) { res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Session not active' } }); return; }
    const result = await rt.dispatchAction({ type: 'lifeline_use', lifelineType: req.body.type as LifelineType, actorId: req.user!.id });
    if (!result.ok) { res.status(400).json({ ok: false, error: result.error }); return; }
    const lifelineResult = await rt.processLifeline(req.body.type as LifelineType);
    // Re-broadcast so eliminated options / lifeline counts reach clients via state:changed
    await rt.broadcastNow();
    ok(res, { lifelineResult });
  }),
);
