import type { Role } from '@cmm/shared';
import { logger } from '../../utils/logger';
import { AuditLog } from './audit-log.model';

export interface AuditEntry {
  actorId?: string | null;
  actorRole?: Role | null;
  action: string;
  targetType: string;
  targetId?: string | null;
  payload?: Record<string, unknown>;
}

/** Fire-and-forget audit trail (M00 §8) — never blocks or breaks the request. */
export function logAudit(entry: AuditEntry): void {
  AuditLog.create({
    actorId: entry.actorId ?? null,
    actorRole: entry.actorRole ?? null,
    action: entry.action,
    targetType: entry.targetType,
    targetId: entry.targetId ?? null,
    payload: entry.payload ?? null,
  }).catch((err: unknown) => {
    logger.warn({ err, action: entry.action }, 'audit log write failed');
  });
}
