import { Schema, model } from 'mongoose';

/** AuditLog model (docs/plans/03-database-models.md §2.11) */
const auditLogSchema = new Schema({
  actorId: { type: Schema.Types.ObjectId, ref: 'User', default: null },
  actorRole: { type: String, default: null },
  action: { type: String, required: true }, // 'session.start', 'question.update', 'auth.login', …
  targetType: { type: String, required: true },
  targetId: { type: Schema.Types.ObjectId, default: null },
  payload: { type: Schema.Types.Mixed, default: null },
  at: { type: Date, default: () => new Date() },
});

auditLogSchema.index({ at: -1 });
auditLogSchema.index({ actorId: 1, at: -1 });

export interface AuditLogDoc {
  _id: unknown;
  actorId?: unknown;
  actorRole?: string | null;
  action: string;
  targetType: string;
  targetId?: unknown;
  payload?: Record<string, unknown> | null;
  at?: Date;
}

export const AuditLog = model<AuditLogDoc>('AuditLog', auditLogSchema);
