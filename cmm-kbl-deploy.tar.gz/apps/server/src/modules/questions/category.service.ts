import type { CategoryDTO } from '@cmm/shared';
import { ApiError } from '../../utils/http';
import { Question } from '../questions/question.model';
import type { CategoryDoc } from './category.model';
import { Category } from './category.model';

function toCategoryDTO(doc: CategoryDoc, questionCount?: number): CategoryDTO {
  return {
    id: String(doc._id),
    name: { hi: doc.name.hi, en: doc.name.en },
    slug: doc.slug,
    color: doc.color,
    sortOrder: doc.sortOrder,
    ...(questionCount !== undefined ? { questionCount } : {}),
  };
}

export async function listCategories(): Promise<CategoryDTO[]> {
  const docs = await Category.find().sort({ sortOrder: 1, name: 1 }).exec();
  // one aggregate for per-category counts (soft-deleted excluded)
  const counts = await Question.aggregate<{ _id: unknown; count: number }>([
    { $match: { deletedAt: null } },
    { $group: { _id: '$category', count: { $sum: 1 } } },
  ]);
  const byId = new Map(counts.map((c) => [String(c._id), c.count]));
  return docs.map((d) => toCategoryDTO(d, byId.get(String(d._id)) ?? 0));
}

export async function createCategory(input: {
  name: { hi: string; en: string };
  color: string;
  sortOrder?: number;
}): Promise<CategoryDTO> {
  const slug = slugify(input.name.en || input.name.hi);
  const dup = await Category.findOne({ slug }).exec();
  if (dup) throw new ApiError('CONFLICT', `Category slug '${slug}' already exists`);
  const doc = await Category.create({
    name: input.name,
    slug,
    color: input.color,
    sortOrder: input.sortOrder ?? 0,
  });
  return toCategoryDTO(doc, 0);
}

export async function updateCategory(
  id: string,
  input: Partial<{ name: { hi: string; en: string }; color: string; sortOrder: number }>,
): Promise<CategoryDTO> {
  const doc = await Category.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Category not found');
  if (input.name) doc.name = input.name;
  if (input.color !== undefined) doc.color = input.color;
  if (input.sortOrder !== undefined) doc.sortOrder = input.sortOrder;
  await doc.save();
  return toCategoryDTO(doc);
}

export async function deleteCategory(id: string): Promise<void> {
  const doc = await Category.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Category not found');
  const inUse = await Question.countDocuments({ category: id, deletedAt: null });
  if (inUse > 0) {
    throw new ApiError('CONFLICT', `Category '${doc.name.en}' is referenced by ${inUse} question(s)`, {
      questionCount: inUse,
    });
  }
  await doc.deleteOne();
}

function slugify(source: string): string {
  return source
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'category';
}
