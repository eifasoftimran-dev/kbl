import type { Request, Response } from 'express';
import { categoryCreateSchema, categoryUpdateSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { logAudit } from '../audit/audit.service';
import { createCategory, deleteCategory, listCategories, updateCategory } from './category.service';

export async function listCategoriesController(_req: Request, res: Response): Promise<void> {
  ok(res, { categories: await listCategories() });
}

export async function createCategoryController(req: Request, res: Response): Promise<void> {
  const input = categoryCreateSchema.parse(req.body);
  const category = await createCategory(input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'category.create',
    targetType: 'category',
    targetId: category.id,
  });
  ok(res, { category });
}

export async function updateCategoryController(req: Request, res: Response): Promise<void> {
  const input = categoryUpdateSchema.parse(req.body);
  const category = await updateCategory(req.params.id, input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'category.update',
    targetType: 'category',
    targetId: category.id,
    payload: { fields: Object.keys(input) },
  });
  ok(res, { category });
}

export async function deleteCategoryController(req: Request, res: Response): Promise<void> {
  await deleteCategory(req.params.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'category.delete',
    targetType: 'category',
    targetId: req.params.id,
  });
  ok(res, {});
}
