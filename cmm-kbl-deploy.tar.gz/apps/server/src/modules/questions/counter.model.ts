import { Schema, model } from 'mongoose';

/** Named monotonic counters (question code sequence — M03 §3) */
const counterSchema = new Schema({
  _id: { type: String, required: true },
  seq: { type: Number, default: 0 },
});

export interface CounterDoc {
  _id: string;
  seq: number;
}

export const Counter = model<CounterDoc>('Counter', counterSchema);

/** Atomically get the next sequence value for `name` (e.g. 'question' → 41). */
export async function nextSeq(name: string): Promise<number> {
  const doc = await Counter.findOneAndUpdate(
    { _id: name },
    { $inc: { seq: 1 } },
    { upsert: true, new: true },
  );
  return doc?.seq ?? 1;
}
