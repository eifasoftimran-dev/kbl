import type {
  CategoryDTO,
  Language,
  Paginated,
  QuestionDTO,
  QuestionListItemDTO,
} from '@cmm/shared';
import { ApiError } from '../../utils/http';
import { pick } from '../../utils/locale';
import { nextSeq } from './counter.model';
import type { CategoryDoc } from './category.model';
import { Category } from './category.model';
import type { QuestionDoc } from './question.model';
import { Question } from './question.model';

// ---------------------------------------------------------------------------
// DTO mappers
// ---------------------------------------------------------------------------

async function toCategoryDTO(id: unknown): Promise<CategoryDTO> {
  const cat = (await Category.findById(id).exec()) as CategoryDoc | null;
  if (!cat) throw new ApiError('INTERNAL', 'Question references a missing category');
  return {
    id: String(cat._id),
    name: { hi: cat.name.hi, en: cat.name.en },
    slug: cat.slug,
    color: cat.color,
    sortOrder: cat.sortOrder,
  };
}

/** Full admin DTO — bilingual fields kept raw for the editor. */
export async function toQuestionDTO(doc: QuestionDoc): Promise<QuestionDTO> {
  return {
    id: String(doc._id),
    code: doc.code,
    text: { hi: doc.text.hi, en: doc.text.en },
    options: doc.options.map((o) => ({ key: o.key, text: { hi: o.text.hi, en: o.text.en } })),
    correctOption: doc.correctOption,
    category: await toCategoryDTO(doc.category),
    difficulty: doc.difficulty,
    timerSeconds: doc.timerSeconds,
    points: doc.points,
    explanation: doc.explanation ? { hi: doc.explanation.hi, en: doc.explanation.en } : null,
    media: doc.media && doc.media.kind !== 'none' && doc.media.assetId
      ? {
          kind: doc.media.kind as 'image' | 'video',
          assetId: String(doc.media.assetId),
          url: `/media/${String(doc.media.assetId)}/file`,
        }
      : null,
    status: doc.status,
    createdAt: doc.createdAt?.toISOString(),
    updatedAt: doc.updatedAt?.toISOString(),
  };
}

/** List-row DTO after server-side lang resolution (M04 §1). */
function toListItem(doc: QuestionDoc, category: CategoryDoc | null, lang: Language): QuestionListItemDTO {
  return {
    id: String(doc._id),
    code: doc.code,
    text: pick(doc.text, lang),
    options: doc.options.map((o) => ({ key: o.key, text: pick(o.text, lang) })),
    correctOption: doc.correctOption,
    category: {
      id: category ? String(category._id) : String(doc.category),
      name: category ? pick(category.name, lang) : '—',
      color: category?.color ?? '#1E5BFF',
    },
    difficulty: doc.difficulty,
    timerSeconds: doc.timerSeconds,
    points: doc.points,
    status: doc.status,
    createdAt: doc.createdAt?.toISOString(),
    updatedAt: doc.updatedAt?.toISOString(),
  };
}

// ---------------------------------------------------------------------------
// List & filter
// ---------------------------------------------------------------------------

export interface QuestionFilter {
  search?: string;
  categoryId?: string;
  difficulty?: string;
  status?: string;
}

export async function listQuestions(
  filter: QuestionFilter,
  lang: Language,
  page: number,
  limit: number,
): Promise<Paginated<QuestionListItemDTO>> {
  const query: Record<string, unknown> = { deletedAt: null };
  if (filter.categoryId) query.category = filter.categoryId;
  if (filter.difficulty) query.difficulty = filter.difficulty;
  if (filter.status) query.status = filter.status;
  if (filter.search) {
    // text index covers hi/en question + option text (M03 §2.3)
    query.$text = { $search: filter.search };
  }

  const [docs, total] = await Promise.all([
    Question.find(query)
      .sort({ code: 1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .exec(),
    Question.countDocuments(query),
  ]);

  const categoryIds = [...new Set(docs.map((d) => String(d.category)))];
  const categories = await Category.find({ _id: { $in: categoryIds } }).exec();
  const catById = new Map(categories.map((c) => [String(c._id), c]));

  return {
    items: docs.map((d) => toListItem(d, catById.get(String(d.category)) ?? null, lang)),
    total,
    page,
    limit,
  };
}

export async function getQuestion(id: string): Promise<QuestionDTO> {
  const doc = await Question.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Question not found');
  return toQuestionDTO(doc);
}

// ---------------------------------------------------------------------------
// Mutations
// ---------------------------------------------------------------------------

export interface QuestionCreateInput {
  text: { hi: string; en: string };
  options: { key: string; text: { hi: string; en: string } }[];
  correctOption: string;
  category: string;
  difficulty: string;
  timerSeconds?: number;
  points?: number;
  explanation?: { hi: string; en: string } | null | undefined;
  media?: { kind: 'image' | 'video'; assetId: string } | null | undefined;
  status?: string;
  tags?: string[];
}

export async function createQuestion(input: QuestionCreateInput, userId: string): Promise<QuestionDTO> {
  const category = await Category.findById(input.category).exec();
  if (!category) throw new ApiError('VALIDATION_ERROR', 'Category does not exist', { path: 'category' });

  const seq = await nextSeq('question');
  const doc = await Question.create({
    code: `Q${String(seq).padStart(3, '0')}`,
    text: input.text,
    options: input.options.map((o) => ({ key: o.key, text: o.text })),
    correctOption: input.correctOption,
    category: input.category,
    difficulty: input.difficulty,
    timerSeconds: input.timerSeconds ?? 30,
    points: input.points ?? 1000,
    ...(input.explanation ? { explanation: input.explanation } : {}),
    ...(input.media ? { media: input.media } : {}),
    status: input.status ?? 'active',
    tags: input.tags ?? [],
    createdBy: userId,
  });
  return toQuestionDTO(doc);
}

export async function updateQuestion(
  id: string,
  input: Partial<QuestionCreateInput>,
  userId: string,
): Promise<QuestionDTO> {
  const doc = await Question.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Question not found');

  if (input.category) {
    const category = await Category.findById(input.category).exec();
    if (!category) throw new ApiError('VALIDATION_ERROR', 'Category does not exist', { path: 'category' });
    doc.category = input.category as QuestionDoc['category'];
  }
  if (input.text) doc.text = input.text;
  if (input.options) doc.options = input.options.map((o) => ({ key: o.key, text: o.text })) as QuestionDoc['options'];
  if (input.correctOption) doc.correctOption = input.correctOption as QuestionDoc['correctOption'];
  if (input.difficulty) doc.difficulty = input.difficulty as QuestionDoc['difficulty'];
  if (input.timerSeconds !== undefined) doc.timerSeconds = input.timerSeconds;
  if (input.points !== undefined) doc.points = input.points;
  if (input.explanation !== undefined) doc.explanation = input.explanation ?? undefined;
  if (input.media !== undefined) {
    doc.media = input.media
      ? { kind: input.media.kind, assetId: input.media.assetId }
      : { kind: 'none', assetId: null };
  }
  if (input.status) doc.status = input.status as QuestionDoc['status'];
  if (input.tags !== undefined) doc.tags = input.tags;

  doc.updatedBy = userId;
  await doc.save();
  return toQuestionDTO(doc);
}

export async function deleteQuestion(id: string): Promise<void> {
  const doc = await Question.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Question not found');
  doc.deletedAt = new Date();
  await doc.save();
}

export async function setQuestionStatus(id: string, status: 'active' | 'inactive', userId: string): Promise<QuestionDTO> {
  const doc = await Question.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Question not found');
  doc.status = status;
  doc.updatedBy = userId;
  await doc.save();
  return toQuestionDTO(doc);
}
