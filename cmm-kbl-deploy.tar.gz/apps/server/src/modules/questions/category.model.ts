import { Schema, model } from 'mongoose';
import type { LocalText } from '@cmm/shared';

/** Category model (docs/plans/03-database-models.md §2.2) */
const categorySchema = new Schema(
  {
    name: {
      type: { hi: { type: String, required: true, trim: true }, en: { type: String, required: true, trim: true } },
      required: true,
    },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    color: { type: String, required: true, match: /^#[0-9a-fA-F]{6}$/ },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true },
);

export interface CategoryDoc {
  _id: unknown;
  name: LocalText;
  slug: string;
  color: string;
  sortOrder: number;
}

export const Category = model<CategoryDoc>('Category', categorySchema);
