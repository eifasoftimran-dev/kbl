import type { Request, Response } from 'express';
import { z } from 'zod';
import { questionCreateSchema, questionUpdateSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { resolveLang } from '../../utils/locale';
import { parsePagination } from '../../utils/list';
import { logAudit } from '../audit/audit.service';
import {
  createQuestion,
  deleteQuestion,
  getQuestion,
  listQuestions,
  setQuestionStatus,
  updateQuestion,
  type QuestionFilter,
} from './question.service';

const listQuerySchema = z.object({
  search: z.string().trim().min(1).max(200).optional(),
  categoryId: z.string().trim().min(1).optional(),
  difficulty: z.enum(['easy', 'medium', 'hard']).optional(),
  status: z.enum(['active', 'inactive']).optional(),
});

export async function listQuestionsController(req: Request, res: Response): Promise<void> {
  const filter = listQuerySchema.parse(req.query) satisfies QuestionFilter;
  const lang = resolveLang(req.query as Record<string, unknown>);
  const { page, limit } = parsePagination(req.query as Record<string, unknown>);
  ok(res, await listQuestions(filter, lang, page, limit));
}

export async function getQuestionController(req: Request, res: Response): Promise<void> {
  ok(res, { question: await getQuestion(req.params.id) });
}

export async function createQuestionController(req: Request, res: Response): Promise<void> {
  const input = questionCreateSchema.parse(req.body);
  const question = await createQuestion(input, req.user!.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'question.create',
    targetType: 'question',
    targetId: question.id,
    payload: { code: question.code },
  });
  ok(res, { question });
}

export async function updateQuestionController(req: Request, res: Response): Promise<void> {
  const input = questionUpdateSchema.parse(req.body);
  const question = await updateQuestion(req.params.id, input, req.user!.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'question.update',
    targetType: 'question',
    targetId: question.id,
    payload: { fields: Object.keys(input) },
  });
  ok(res, { question });
}

export async function deleteQuestionController(req: Request, res: Response): Promise<void> {
  await deleteQuestion(req.params.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'question.delete',
    targetType: 'question',
    targetId: req.params.id,
  });
  ok(res, {});
}

const statusSchema = z.object({ status: z.enum(['active', 'inactive']) });

export async function questionStatusController(req: Request, res: Response): Promise<void> {
  const { status } = statusSchema.parse(req.body);
  const question = await setQuestionStatus(req.params.id, status, req.user!.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'question.status',
    targetType: 'question',
    targetId: question.id,
    payload: { status },
  });
  ok(res, { question });
}
