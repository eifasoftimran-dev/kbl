import { Schema, model } from 'mongoose';
import type { Difficulty, LocalText, OptionKey, QuestionStatus } from '@cmm/shared';
import { DIFFICULTIES, OPTION_KEYS, QUESTION_STATUSES } from '@cmm/shared';

/** Question model (docs/plans/03-database-models.md §2.3) */
const localText = {
  hi: { type: String, required: true, trim: true },
  en: { type: String, required: true, trim: true },
};

const questionSchema = new Schema(
  {
    code: { type: String, required: true, unique: true }, // human ID 'Q001'
    text: { type: localText, required: true },
    options: {
      type: [
        {
          key: { type: String, enum: OPTION_KEYS, required: true },
          text: { type: localText, required: true },
        },
      ],
      required: true,
      validate: {
        validator: (opts: { key: OptionKey }[]) => opts.length === 4,
        message: 'Exactly 4 options are required',
      },
    },
    correctOption: { type: String, enum: OPTION_KEYS, required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true, index: true },
    difficulty: { type: String, enum: DIFFICULTIES, required: true },
    timerSeconds: { type: Number, required: true, min: 10, max: 120 },
    points: { type: Number, required: true, min: 0 },
    explanation: { type: localText, required: false },
    media: {
      kind: { type: String, enum: ['none', 'image', 'video'], default: 'none' },
      assetId: { type: Schema.Types.ObjectId, ref: 'MediaAsset', default: null },
    },
    status: { type: String, enum: QUESTION_STATUSES, default: 'active' },
    tags: { type: [String], default: [] },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    deletedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

questionSchema.index({ category: 1, difficulty: 1, status: 1 });
questionSchema.index({ 'text.hi': 'text', 'text.en': 'text', 'options.text.hi': 'text' });

export interface QuestionOptionDoc {
  key: OptionKey;
  text: LocalText;
}

export interface QuestionDoc {
  _id: unknown;
  code: string;
  text: LocalText;
  options: QuestionOptionDoc[];
  correctOption: OptionKey;
  category: unknown;
  difficulty: Difficulty;
  timerSeconds: number;
  points: number;
  explanation?: LocalText;
  media: { kind: 'image' | 'video' | 'none'; assetId: unknown };
  status: QuestionStatus;
  tags: string[];
  createdBy: unknown;
  updatedBy?: unknown;
  deletedAt?: Date | null;
  createdAt?: Date;
  updatedAt?: Date;
}

export const Question = model<QuestionDoc>('Question', questionSchema);
