import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import {
  createCategoryController,
  deleteCategoryController,
  listCategoriesController,
  updateCategoryController,
} from './category.controller';
import {
  createQuestionController,
  deleteQuestionController,
  getQuestionController,
  listQuestionsController,
  questionStatusController,
  updateQuestionController,
} from './question.controller';

/** Questions & categories routes (M04 §2.3). */
export const questionsRouter = Router();

questionsRouter.get('/categories', requirePermission('questions.read'), asyncHandler(listCategoriesController));
questionsRouter.post('/categories', requirePermission('categories.write'), asyncHandler(createCategoryController));
questionsRouter.patch(
  '/categories/:id',
  requirePermission('categories.write'),
  asyncHandler(updateCategoryController),
);
questionsRouter.delete(
  '/categories/:id',
  requirePermission('categories.write'),
  asyncHandler(deleteCategoryController),
);

questionsRouter.get('/', requirePermission('questions.read'), asyncHandler(listQuestionsController));
questionsRouter.get('/:id', requirePermission('questions.read'), asyncHandler(getQuestionController));
questionsRouter.post('/', requirePermission('questions.write'), asyncHandler(createQuestionController));
questionsRouter.patch('/:id', requirePermission('questions.write'), asyncHandler(updateQuestionController));
questionsRouter.patch('/:id/status', requirePermission('questions.write'), asyncHandler(questionStatusController));
questionsRouter.delete('/:id', requirePermission('questions.delete'), asyncHandler(deleteQuestionController));
