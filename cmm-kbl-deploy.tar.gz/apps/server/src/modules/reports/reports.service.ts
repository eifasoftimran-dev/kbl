import type { Language, ReportSummaryDTO } from '@cmm/shared';
import { ApiError } from '../../utils/http';
import { pick } from '../../utils/locale';
import { Contestant } from '../contestants/contestant.model';
import { Question } from '../questions/question.model';
import { GameSession } from '../sessions/session.model';
import { QuestionAttempt } from '../sessions/attempt.model';

interface Acc {
  attempted: number;
  correct: number;
  timeouts: number;
  responseMsSum: number;
  responseMsCount: number;
}

function newAcc(): Acc {
  return { attempted: 0, correct: 0, timeouts: 0, responseMsSum: 0, responseMsCount: 0 };
}

function bump(acc: Acc, isCorrect: boolean, responseMs?: number | null): void {
  acc.attempted += 1;
  if (isCorrect) acc.correct += 1;
  if (responseMs == null) acc.timeouts += 1;
  else {
    acc.responseMsSum += responseMs;
    acc.responseMsCount += 1;
  }
}

function pct(part: number, total: number): number {
  return total > 0 ? Math.round((part / total) * 1000) / 10 : 0;
}

function avg(sum: number, count: number): number | null {
  return count > 0 ? Math.round(sum / count) : null;
}

/** Session results aggregation (docs/plans/11-media-reports-export.md §2). */
export async function getReportSummary(
  sessionId: string | undefined,
  lang: Language,
): Promise<ReportSummaryDTO> {
  let sessionDoc = null;
  if (sessionId) {
    sessionDoc = await GameSession.findById(sessionId).exec();
    if (!sessionDoc) throw new ApiError('NOT_FOUND', 'Session not found');
  }

  const attempts = await QuestionAttempt.find(sessionId ? { sessionId } : {}).lean().exec();

  let correctTotal = 0;
  const responseMsSumTotal = { sum: 0, count: 0 };
  const byContestant = new Map<string, Acc & { score: number }>();
  const byQuestion = new Map<string, Acc>();

  for (const a of attempts) {
    const cid = String(a.contestantId);
    const qid = String(a.questionId);
    const isCorrect = a.isCorrect === true;
    if (isCorrect) correctTotal += 1;

    const cAcc = byContestant.get(cid) ?? { ...newAcc(), score: 0 };
    bump(cAcc, isCorrect, a.responseMs);
    cAcc.score += a.pointsAwarded ?? 0;
    byContestant.set(cid, cAcc);

    const qAcc = byQuestion.get(qid) ?? newAcc();
    bump(qAcc, isCorrect, a.responseMs);
    byQuestion.set(qid, qAcc);

    if (typeof a.responseMs === 'number' && a.responseMs > 0) {
      responseMsSumTotal.sum += a.responseMs;
      responseMsSumTotal.count += 1;
    }
  }

  const [contestantDocs, questionDocs] = await Promise.all([
    Contestant.find({ _id: { $in: [...byContestant.keys()] } }).exec(),
    Question.find({ _id: { $in: [...byQuestion.keys()] } }).exec(),
  ]);

  const contestants: ReportSummaryDTO['contestants'] = contestantDocs
    .map((c) => {
      const acc = byContestant.get(String(c._id))!;
      return {
        contestantId: String(c._id),
        name: c.name,
        city: c.city ?? null,
        score: acc.score,
        correctCount: acc.correct,
        attempted: acc.attempted,
        accuracyPct: pct(acc.correct, acc.attempted),
        avgResponseMs: avg(acc.responseMsSum, acc.responseMsCount),
      };
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));

  const questions: ReportSummaryDTO['questions'] = questionDocs
    .map((q) => {
      const acc = byQuestion.get(String(q._id))!;
      return {
        questionId: String(q._id),
        code: q.code,
        text: pick(q.text, lang),
        difficulty: q.difficulty,
        attempted: acc.attempted,
        correctCount: acc.correct,
        correctPct: pct(acc.correct, acc.attempted),
        timeoutCount: acc.timeouts,
        avgResponseMs: avg(acc.responseMsSum, acc.responseMsCount),
      };
    })
    .sort((a, b) => a.code.localeCompare(b.code));

  return {
    session: sessionDoc
      ? {
          id: String(sessionDoc._id),
          name: sessionDoc.name,
          code: sessionDoc.code,
          status: sessionDoc.status,
          startedAt: sessionDoc.startedAt?.toISOString() ?? null,
          endedAt: sessionDoc.endedAt?.toISOString() ?? null,
          totalQuestions: sessionDoc.questionIds.length,
        }
      : null,
    overall: {
      attempts: attempts.length,
      correct: correctTotal,
      accuracyPct: pct(correctTotal, attempts.length),
      avgResponseMs: avg(responseMsSumTotal.sum, responseMsSumTotal.count),
    },
    contestants,
    questions,
  };
}
