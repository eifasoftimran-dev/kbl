import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import { reportSummaryController } from './reports.controller';

/** Reports routes (M11 §2) — read-only aggregations over QuestionAttempt. */
export const reportsRouter = Router();

reportsRouter.get('/summary', requirePermission('reports.read'), asyncHandler(reportSummaryController));
