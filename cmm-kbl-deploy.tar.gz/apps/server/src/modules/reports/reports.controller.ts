import type { Request, Response } from 'express';
import { z } from 'zod';
import { ok } from '../../utils/http';
import { resolveLang } from '../../utils/locale';
import { getReportSummary } from './reports.service';

const summaryQuerySchema = z.object({
  sessionId: z.string().trim().min(1).optional(),
});

export async function reportSummaryController(req: Request, res: Response): Promise<void> {
  const { sessionId } = summaryQuerySchema.parse(req.query);
  const lang = resolveLang(req.query as Record<string, unknown>);
  ok(res, await getReportSummary(sessionId, lang));
}
