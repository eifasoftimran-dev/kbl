import type { Request, Response } from 'express';
import { loginSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { logAudit } from '../audit/audit.service';
import { login, logout, refresh, REFRESH_COOKIE, refreshCookieOptions, toUserPublic } from './auth.service';
import { User } from './user.model';

export async function loginController(req: Request, res: Response): Promise<void> {
  const input = loginSchema.parse(req.body);
  const result = await login(input.email, input.password);
  res.cookie(REFRESH_COOKIE, result.refreshToken, refreshCookieOptions());
  logAudit({
    actorId: result.user.id,
    actorRole: result.user.role,
    action: 'auth.login',
    targetType: 'user',
    targetId: result.user.id,
  });
  ok(res, { user: result.user, accessToken: result.accessToken });
}

export async function refreshController(req: Request, res: Response): Promise<void> {
  const accessToken = await refresh(req.cookies?.[REFRESH_COOKIE]);
  ok(res, { accessToken });
}

export async function logoutController(req: Request, res: Response): Promise<void> {
  res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
  if (req.user) {
    await logout(req.user.id);
    logAudit({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: 'auth.logout',
      targetType: 'user',
      targetId: req.user.id,
    });
  }
  ok(res, {});
}

export async function meController(req: Request, res: Response): Promise<void> {
  const doc = await User.findById(req.user!.id).exec();
  if (!doc || !doc.isActive) {
    res.status(401).json({ ok: false, error: { code: 'UNAUTHORIZED', message: 'User not found or inactive' } });
    return;
  }
  ok(res, { user: toUserPublic(doc) });
}
