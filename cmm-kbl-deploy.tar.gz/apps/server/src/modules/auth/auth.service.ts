import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { UserPublic } from '@cmm/shared';
import { env, parseDurationMs } from '../../config/env';
import { ApiError } from '../../utils/http';
import { logger } from '../../utils/logger';
import type { UserDoc } from './user.model';
import { User } from './user.model';

export const REFRESH_COOKIE = 'cmm_refresh';
const BCRYPT_ROUNDS = 12;

interface RefreshTokenPayload {
  sub: string;
  type: 'refresh';
  /** per-user version — bumping invalidates outstanding refresh tokens (M05 §2) */
  v: number;
}

export function toUserPublic(doc: UserDoc): UserPublic {
  return {
    id: String(doc._id),
    name: doc.name,
    email: doc.email,
    role: doc.role,
    isActive: doc.isActive,
    lastLoginAt: doc.lastLoginAt ? doc.lastLoginAt.toISOString() : null,
  };
}

export function signAccessToken(user: UserDoc): string {
  return jwt.sign(
    { sub: String(user._id), role: user.role, name: user.name, type: 'access' },
    env.JWT_ACCESS_SECRET,
    // seconds — newer @types/jsonwebtoken only accepts number | StringValue
    { expiresIn: parseDurationMs(env.ACCESS_TOKEN_TTL) / 1000 },
  );
}

function signRefreshToken(user: UserDoc): string {
  return jwt.sign(
    { sub: String(user._id), type: 'refresh', v: user.tokenVersion },
    env.JWT_REFRESH_SECRET,
    { expiresIn: parseDurationMs(env.REFRESH_TOKEN_TTL) / 1000 },
  );
}

export function refreshCookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'strict' as const,
    secure: env.NODE_ENV === 'production',
    path: '/api/auth',
    maxAge: parseDurationMs(env.REFRESH_TOKEN_TTL),
  };
}

export async function login(email: string, password: string): Promise<{ user: UserPublic; accessToken: string; refreshToken: string }> {
  const doc = await User.findOne({ email: email.toLowerCase() }).exec();
  const invalid = new ApiError('UNAUTHORIZED', 'Invalid email or password');
  if (!doc || !doc.isActive) {
    logger.warn({ email }, 'login failed (no user / inactive)');
    throw invalid;
  }
  const match = await bcrypt.compare(password, doc.passwordHash);
  if (!match) {
    logger.warn({ email }, 'login failed (bad password)');
    throw invalid;
  }
  doc.lastLoginAt = new Date();
  await doc.save();
  return {
    user: toUserPublic(doc),
    accessToken: signAccessToken(doc),
    refreshToken: signRefreshToken(doc),
  };
}

export async function refresh(refreshToken: string | undefined): Promise<string> {
  if (!refreshToken) throw new ApiError('UNAUTHORIZED', 'Missing refresh cookie');
  let payload: RefreshTokenPayload;
  try {
    payload = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as RefreshTokenPayload;
  } catch {
    throw new ApiError('UNAUTHORIZED', 'Invalid or expired refresh token');
  }
  if (payload.type !== 'refresh') throw new ApiError('UNAUTHORIZED', 'Wrong token type');
  const doc = await User.findById(payload.sub).exec();
  if (!doc || !doc.isActive) throw new ApiError('UNAUTHORIZED', 'User not found or inactive');
  if (doc.tokenVersion !== payload.v) throw new ApiError('UNAUTHORIZED', 'Session revoked');
  return signAccessToken(doc);
}

export async function logout(userId?: string): Promise<void> {
  if (!userId) return;
  await User.updateOne({ _id: userId }, { $inc: { tokenVersion: 1 } }).exec();
}

/** Used by the seed script and user creation (P1). */
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, BCRYPT_ROUNDS);
}
