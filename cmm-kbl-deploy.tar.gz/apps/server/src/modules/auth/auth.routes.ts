import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { asyncHandler } from '../../utils/http';
import { requireAuth } from '../../middlewares/auth';
import { loginController, logoutController, meController, refreshController } from './auth.controller';

const loginLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { ok: false, error: { code: 'RATE_LIMITED', message: 'Too many login attempts — try again in a few minutes' } },
});

export const authRouter = Router();
authRouter.post('/login', loginLimiter, asyncHandler(loginController));
authRouter.post('/refresh', asyncHandler(refreshController));
authRouter.post('/logout', requireAuth, asyncHandler(logoutController));
authRouter.get('/me', requireAuth, asyncHandler(meController));
