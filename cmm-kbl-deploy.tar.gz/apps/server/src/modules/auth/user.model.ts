import { Schema, model } from 'mongoose';
import type { Role } from '@cmm/shared';
import { ROLES } from '@cmm/shared';

/** User model (docs/plans/03-database-models.md §2.1 + tokenVersion from M05 §2) */
const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ROLES, required: true },
    isActive: { type: Boolean, default: true },
    /** bumped on logout/password reset/deactivation → invalidates refresh tokens */
    tokenVersion: { type: Number, default: 0 },
    lastLoginAt: { type: Date, default: null },
  },
  { timestamps: true },
);

export interface UserDoc {
  _id: unknown;
  name: string;
  email: string;
  passwordHash: string;
  role: Role;
  isActive: boolean;
  tokenVersion: number;
  lastLoginAt?: Date | null;
  createdAt?: Date;
  updatedAt?: Date;
}

export const User = model<UserDoc>('User', userSchema);
