import type { Request, Response } from 'express';
import { z } from 'zod';
import { passwordResetSchema, userCreateSchema, userUpdateSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { parsePagination } from '../../utils/list';
import { logAudit } from '../audit/audit.service';
import {
  activateUser,
  createUser,
  deactivateUser,
  getUser,
  listUsers,
  resetPassword,
  updateUser,
  type UserFilter,
} from './user.service';

const listQuerySchema = z.object({
  search: z.string().trim().min(1).max(200).optional(),
  role: z.enum(['super_admin', 'operator', 'host', 'question_editor']).optional(),
  isActive: z
    .string()
    .optional()
    .transform((v) => (v === 'true' ? true : v === 'false' ? false : undefined)),
});

export async function listUsersController(req: Request, res: Response): Promise<void> {
  const filter = listQuerySchema.parse(req.query) satisfies UserFilter;
  const { page, limit } = parsePagination(req.query as Record<string, unknown>);
  ok(res, await listUsers(filter, page, limit));
}

export async function getUserController(req: Request, res: Response): Promise<void> {
  ok(res, { user: await getUser(req.params.id) });
}

export async function createUserController(req: Request, res: Response): Promise<void> {
  const input = userCreateSchema.parse(req.body);
  const user = await createUser(input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'user.create',
    targetType: 'user',
    targetId: user.id,
    payload: { email: user.email, role: user.role },
  });
  ok(res, { user });
}

export async function updateUserController(req: Request, res: Response): Promise<void> {
  const input = userUpdateSchema.parse(req.body);
  const user = await updateUser(req.params.id, input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'user.update',
    targetType: 'user',
    targetId: req.params.id,
    payload: { fields: Object.keys(input) },
  });
  ok(res, { user });
}

export async function resetPasswordController(req: Request, res: Response): Promise<void> {
  const { password } = passwordResetSchema.parse(req.body);
  await resetPassword(req.params.id, password);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'user.password_reset',
    targetType: 'user',
    targetId: req.params.id,
  });
  ok(res, {});
}

export async function deactivateUserController(req: Request, res: Response): Promise<void> {
  const user = await deactivateUser(req.params.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'user.deactivate',
    targetType: 'user',
    targetId: req.params.id,
  });
  ok(res, { user });
}

export async function activateUserController(req: Request, res: Response): Promise<void> {
  const user = await activateUser(req.params.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'user.activate',
    targetType: 'user',
    targetId: req.params.id,
  });
  ok(res, { user });
}
