import type { Paginated, UserPublic } from '@cmm/shared';
import bcrypt from 'bcryptjs';
import { ApiError } from '../../utils/http';
import type { UserDoc } from '../auth/user.model';
import { User } from '../auth/user.model';

function toUserPublic(doc: UserDoc): UserPublic {
  return {
    id: String(doc._id),
    name: doc.name,
    email: doc.email,
    role: doc.role,
    isActive: doc.isActive,
    lastLoginAt: doc.lastLoginAt?.toISOString() ?? null,
  };
}

export interface UserFilter {
  search?: string;
  role?: string;
  isActive?: boolean;
}

export async function listUsers(
  filter: UserFilter,
  page: number,
  limit: number,
): Promise<Paginated<UserPublic>> {
  const query: Record<string, unknown> = {};
  if (filter.role) query.role = filter.role;
  if (filter.isActive !== undefined) query.isActive = filter.isActive;
  if (filter.search) {
    const regex = new RegExp(filter.search, 'i');
    query.$or = [{ name: regex }, { email: regex }];
  }

  const [docs, total] = await Promise.all([
    User.find(query).sort({ name: 1 }).skip((page - 1) * limit).limit(limit).exec(),
    User.countDocuments(query),
  ]);

  return { items: docs.map(toUserPublic), total, page, limit };
}

export async function getUser(id: string): Promise<UserPublic> {
  const doc = await User.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'User not found');
  return toUserPublic(doc);
}

export async function createUser(input: {
  name: string;
  email: string;
  password: string;
  role: string;
}): Promise<UserPublic> {
  const dup = await User.findOne({ email: input.email.toLowerCase() }).exec();
  if (dup) throw new ApiError('CONFLICT', `Email '${input.email}' is already registered`);

  const passwordHash = await bcrypt.hash(input.password, 12);
  const doc = await User.create({
    name: input.name,
    email: input.email.toLowerCase(),
    passwordHash,
    role: input.role,
  });
  return toUserPublic(doc);
}

export async function updateUser(
  id: string,
  input: Partial<{ name: string; email: string; role: string }>,
): Promise<UserPublic> {
  const doc = await User.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'User not found');

  if (input.email && input.email.toLowerCase() !== doc.email) {
    const dup = await User.findOne({ email: input.email.toLowerCase() }).exec();
    if (dup) throw new ApiError('CONFLICT', `Email '${input.email}' is already registered`);
    doc.email = input.email.toLowerCase();
  }
  if (input.name) doc.name = input.name;
  if (input.role) doc.role = input.role as UserDoc['role'];
  await doc.save();
  return toUserPublic(doc);
}

export async function resetPassword(id: string, newPassword: string): Promise<void> {
  const doc = await User.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'User not found');
  doc.passwordHash = await bcrypt.hash(newPassword, 12);
  doc.tokenVersion = doc.tokenVersion + 1; // invalidate all refresh tokens
  await doc.save();
}

export async function deactivateUser(id: string): Promise<UserPublic> {
  const doc = await User.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'User not found');
  doc.isActive = false;
  doc.tokenVersion = doc.tokenVersion + 1;
  await doc.save();
  return toUserPublic(doc);
}

export async function activateUser(id: string): Promise<UserPublic> {
  const doc = await User.findById(id).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'User not found');
  doc.isActive = true;
  await doc.save();
  return toUserPublic(doc);
}
