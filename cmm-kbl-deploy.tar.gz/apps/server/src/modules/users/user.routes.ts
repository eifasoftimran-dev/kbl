import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import {
  activateUserController,
  createUserController,
  deactivateUserController,
  getUserController,
  listUsersController,
  resetPasswordController,
  updateUserController,
} from './user.controller';

/** Users management routes (M05 — users.manage permission). */
export const usersRouter = Router();

usersRouter.get('/', requirePermission('users.manage'), asyncHandler(listUsersController));
usersRouter.get('/:id', requirePermission('users.manage'), asyncHandler(getUserController));
usersRouter.post('/', requirePermission('users.manage'), asyncHandler(createUserController));
usersRouter.patch('/:id', requirePermission('users.manage'), asyncHandler(updateUserController));
usersRouter.post('/:id/password', requirePermission('users.manage'), asyncHandler(resetPasswordController));
usersRouter.post('/:id/deactivate', requirePermission('users.manage'), asyncHandler(deactivateUserController));
usersRouter.post('/:id/activate', requirePermission('users.manage'), asyncHandler(activateUserController));
