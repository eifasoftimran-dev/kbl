import type { ContestantDTO, Paginated } from '@cmm/shared';
import { ApiError } from '../../utils/http';
import type { ContestantDoc } from './contestant.model';
import { Contestant } from './contestant.model';

function toContestantDTO(doc: ContestantDoc): ContestantDTO {
  return {
    id: String(doc._id),
    name: doc.name,
    mobile: doc.mobile,
    city: doc.city,
    avatarUrl: doc.avatarAssetId ? `/media/${String(doc.avatarAssetId)}/file` : null,
    score: doc.score,
    isActive: doc.isActive,
  };
}

export interface ContestantFilter {
  search?: string;
  isActive?: boolean;
}

export async function listContestants(
  filter: ContestantFilter,
  page: number,
  limit: number,
): Promise<Paginated<ContestantDTO>> {
  const query: Record<string, unknown> = { deletedAt: null };
  if (filter.isActive !== undefined) query.isActive = filter.isActive;
  if (filter.search) {
    const regex = new RegExp(filter.search, 'i');
    query.$or = [{ name: regex }, { city: regex }, { mobile: regex }];
  }

  const [docs, total] = await Promise.all([
    Contestant.find(query).sort({ name: 1 }).skip((page - 1) * limit).limit(limit).exec(),
    Contestant.countDocuments(query),
  ]);

  return { items: docs.map(toContestantDTO), total, page, limit };
}

export async function getContestant(id: string): Promise<ContestantDTO> {
  const doc = await Contestant.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Contestant not found');
  return toContestantDTO(doc);
}

export async function createContestant(input: {
  name: string;
  mobile: string;
  city: string;
  avatarAssetId?: string | null;
}): Promise<ContestantDTO> {
  const dup = await Contestant.findOne({ mobile: input.mobile }).exec();
  if (dup) throw new ApiError('CONFLICT', `Mobile ${input.mobile} already registered`);
  const doc = await Contestant.create({ ...input, score: 0 });
  return toContestantDTO(doc);
}

export async function updateContestant(
  id: string,
  input: Partial<{ name: string; mobile: string; city: string; avatarAssetId: string | null }>,
): Promise<ContestantDTO> {
  const doc = await Contestant.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Contestant not found');
  if (input.mobile && input.mobile !== doc.mobile) {
    const dup = await Contestant.findOne({ mobile: input.mobile }).exec();
    if (dup) throw new ApiError('CONFLICT', `Mobile ${input.mobile} already registered`);
    doc.mobile = input.mobile;
  }
  if (input.name) doc.name = input.name;
  if (input.city) doc.city = input.city;
  if (input.avatarAssetId !== undefined) doc.avatarAssetId = input.avatarAssetId;
  await doc.save();
  return toContestantDTO(doc);
}

export async function deleteContestant(id: string): Promise<void> {
  const doc = await Contestant.findOne({ _id: id, deletedAt: null }).exec();
  if (!doc) throw new ApiError('NOT_FOUND', 'Contestant not found');
  doc.deletedAt = new Date();
  await doc.save();
}
