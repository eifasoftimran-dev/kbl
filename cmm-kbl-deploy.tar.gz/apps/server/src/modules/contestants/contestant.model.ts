import { Schema, model } from 'mongoose';

/** Contestant model (docs/plans/03-database-models.md §2.4) */
const contestantSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    mobile: { type: String, required: true, unique: true, match: /^[6-9]\d{9}$/ },
    city: { type: String, required: true, trim: true, maxlength: 60 },
    avatarAssetId: { type: Schema.Types.ObjectId, ref: 'MediaAsset', default: null },
    score: { type: Number, default: 0 }, // denormalized cache (M03 §3)
    isActive: { type: Boolean, default: true },
    deletedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

export interface ContestantDoc {
  _id: unknown;
  name: string;
  mobile: string;
  city: string;
  avatarAssetId?: unknown;
  score: number;
  isActive: boolean;
  deletedAt?: Date | null;
}

export const Contestant = model<ContestantDoc>('Contestant', contestantSchema);
