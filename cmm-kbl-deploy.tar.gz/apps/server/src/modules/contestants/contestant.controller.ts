import type { Request, Response } from 'express';
import { z } from 'zod';
import { contestantCreateSchema, contestantUpdateSchema } from '@cmm/shared';
import { ok } from '../../utils/http';
import { parsePagination } from '../../utils/list';
import { logAudit } from '../audit/audit.service';
import {
  createContestant,
  deleteContestant,
  getContestant,
  listContestants,
  updateContestant,
  type ContestantFilter,
} from './contestant.service';

const listQuerySchema = z.object({
  search: z.string().trim().min(1).max(200).optional(),
  isActive: z
    .string()
    .optional()
    .transform((v) => (v === 'true' ? true : v === 'false' ? false : undefined)),
});

export async function listContestantsController(req: Request, res: Response): Promise<void> {
  const filter = listQuerySchema.parse(req.query) satisfies ContestantFilter;
  const { page, limit } = parsePagination(req.query as Record<string, unknown>);
  ok(res, await listContestants(filter, page, limit));
}

export async function getContestantController(req: Request, res: Response): Promise<void> {
  ok(res, { contestant: await getContestant(req.params.id) });
}

export async function createContestantController(req: Request, res: Response): Promise<void> {
  const input = contestantCreateSchema.parse(req.body);
  const contestant = await createContestant(input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'contestant.create',
    targetType: 'contestant',
    targetId: contestant.id,
  });
  ok(res, { contestant });
}

export async function updateContestantController(req: Request, res: Response): Promise<void> {
  const input = contestantUpdateSchema.parse(req.body);
  const contestant = await updateContestant(req.params.id, input);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'contestant.update',
    targetType: 'contestant',
    targetId: contestant.id,
    payload: { fields: Object.keys(input) },
  });
  ok(res, { contestant });
}

export async function deleteContestantController(req: Request, res: Response): Promise<void> {
  await deleteContestant(req.params.id);
  logAudit({
    actorId: req.user!.id,
    actorRole: req.user!.role,
    action: 'contestant.delete',
    targetType: 'contestant',
    targetId: req.params.id,
  });
  ok(res, {});
}
