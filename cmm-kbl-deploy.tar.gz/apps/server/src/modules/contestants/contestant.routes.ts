import { Router } from 'express';
import { asyncHandler } from '../../utils/http';
import { requirePermission } from '../../middlewares/rbac';
import {
  createContestantController,
  deleteContestantController,
  getContestantController,
  listContestantsController,
  updateContestantController,
} from './contestant.controller';

/** Contestants routes (M04 §2.4). */
export const contestantsRouter = Router();

contestantsRouter.get('/', requirePermission('contestants.read'), asyncHandler(listContestantsController));
contestantsRouter.get('/:id', requirePermission('contestants.read'), asyncHandler(getContestantController));
contestantsRouter.post('/', requirePermission('contestants.write'), asyncHandler(createContestantController));
contestantsRouter.patch('/:id', requirePermission('contestants.write'), asyncHandler(updateContestantController));
contestantsRouter.delete('/:id', requirePermission('contestants.write'), asyncHandler(deleteContestantController));
