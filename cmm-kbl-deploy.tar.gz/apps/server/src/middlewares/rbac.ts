import type { RequestHandler } from 'express';
import type { Permission } from '@cmm/shared';
import { roleHasPermission } from '@cmm/shared';
import { ApiError } from '../utils/http';
import { requireAuth } from './auth';

/** requirePermission (M05.4): single matrix lookup shared by REST + sockets. */
export function requirePermission(permission: Permission): RequestHandler[] {
  return [
    requireAuth,
    (req, _res, next) => {
      if (!req.user) {
        next(new ApiError('UNAUTHORIZED', 'Not authenticated'));
        return;
      }
      if (!roleHasPermission(req.user.role, permission)) {
        next(new ApiError('FORBIDDEN', `Role '${req.user.role}' lacks '${permission}'`, { required: permission }));
        return;
      }
      next();
    },
  ];
}
