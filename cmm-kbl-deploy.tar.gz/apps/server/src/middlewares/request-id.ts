import { randomUUID } from 'node:crypto';
import type { RequestHandler } from 'express';

/** Assigns req.id (echoed as x-request-id, correlated in logs — M04.8). */
export const requestId: RequestHandler = (req, res, next) => {
  const id = randomUUID();
  req.id = id;
  res.setHeader('x-request-id', id);
  next();
};
