import jwt from 'jsonwebtoken';
import type { RequestHandler } from 'express';
import type { Role } from '@cmm/shared';
import { env } from '../config/env';
import { ApiError } from '../utils/http';

export interface AccessTokenPayload {
  sub: string;
  role: Role;
  name: string;
  type: 'access';
}

/** requireAuth (M05.4): verifies the Bearer access JWT → attaches req.user. */
export const requireAuth: RequestHandler = (req, _res, next) => {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    next(new ApiError('UNAUTHORIZED', 'Missing bearer token'));
    return;
  }
  try {
    const payload = jwt.verify(header.slice(7), env.JWT_ACCESS_SECRET) as AccessTokenPayload;
    if (payload.type !== 'access') throw new Error('wrong token type');
    req.user = { id: payload.sub, role: payload.role, name: payload.name };
    next();
  } catch {
    next(new ApiError('UNAUTHORIZED', 'Invalid or expired token'));
  }
};
