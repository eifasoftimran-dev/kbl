import { z } from 'zod';

/**
 * Environment validated at startup (docs/plans/01-project-setup.md §3).
 * Fail fast with a clear message instead of mystery runtime errors.
 */
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  MONGO_URI: z.string().min(1).default('mongodb://localhost:27017/cmm-kbl'),
  JWT_ACCESS_SECRET: z.string().min(16).default('dev-access-secret-change-me-please-32chars'),
  JWT_REFRESH_SECRET: z.string().min(16).default('dev-refresh-secret-change-me-please-32ch'),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_TTL: z.string().default('7d'),
  WEB_ORIGIN: z.string().default('http://localhost:5173'),
  UPLOAD_DIR: z.string().default('./uploads'),
  MAX_IMAGE_MB: z.coerce.number().int().positive().default(5),
  MAX_VIDEO_MB: z.coerce.number().int().positive().default(100),
  SEED_ADMIN_EMAIL: z.string().default('admin@quiz.local'),
  SEED_ADMIN_PASSWORD: z.string().default('SuperAdmin@123'),
  FORCE_SEED: z
    .string()
    .optional()
    .transform((v) => v === 'true' || v === '1'),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error('❌ Invalid environment configuration:\n', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;

const DEV_DEFAULT_SECRETS = [
  'dev-access-secret-change-me-please-32chars',
  'dev-refresh-secret-change-me-please-32ch',
];
if (env.NODE_ENV === 'production' && DEV_DEFAULT_SECRETS.includes(env.JWT_ACCESS_SECRET)) {
  // eslint-disable-next-line no-console
  console.error('❌ Refusing to start in production with a development JWT secret.');
  process.exit(1);
}

/** Parse simple duration strings like "15m", "7d", "45s" → milliseconds. */
export function parseDurationMs(value: string): number {
  const match = /^(\d+)(s|m|h|d)$/.exec(value.trim());
  if (!match) return 7 * 24 * 60 * 60 * 1000; // default: 7 days
  const n = Number(match[1]);
  const unitMs: Record<string, number> = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  return n * unitMs[match[2]];
}
