import 'dotenv/config';
import http from 'node:http';
import { env } from './config/env';
import { connectDb, disconnectDb } from './db/connect';
import { createApp } from './app';
import { createSocketIO } from './realtime/io';
import { logger } from './utils/logger';

/** Bootstrap (M01 §5): env → db → http + io → listen. */
async function main(): Promise<void> {
  await connectDb();

  const app = createApp();
  const server = http.createServer(app);

  // Realtime engine (M06) — Socket.io with JWT auth, game handlers, ticker
  const io = createSocketIO(server);

  // Store io reference on the Express app for HTTP control routes
  app.set('io', io);

  server.listen(env.PORT, () => {
    logger.info(`🚀 API + realtime listening on http://localhost:${env.PORT} (env=${env.NODE_ENV})`);
    logger.info(`   healthz → http://localhost:${env.PORT}/healthz`);
  });

  const shutdown = (signal: string): void => {
    logger.info(`${signal} received — draining…`);
    io.close();
    server.close(() => {
      void disconnectDb().finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(0), 5_000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((err: unknown) => {
  logger.error({ err }, 'fatal startup error');
  process.exit(1);
});
