import type { Language, Role } from '@cmm/shared';

declare global {
  namespace Express {
    interface Request {
      /** assigned by the requestId middleware; echoed as x-request-id */
      id: string;
      /** assigned by requireAuth (M05 §4) */
      user?: { id: string; role: Role; name: string };
      /** resolved from ?lang= by list/detail controllers (M04 §1) */
      lang?: Language;
    }
  }
}

export {};
