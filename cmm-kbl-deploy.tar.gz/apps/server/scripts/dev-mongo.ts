import path from 'node:path';
import fs from 'node:fs';
import { MongoMemoryServer } from 'mongodb-memory-server';

/**
 * Dev database launcher (M01 §5) — for machines without Docker/MongoDB.
 * Runs an in-process mongod on 127.0.0.1:27017 with a PERSISTENT dbPath
 * (<repo>/.mongo) so data survives restarts. Binary download is cached
 * by mongodb-memory-server on first run.
 *
 * If you have Docker or a real MongoDB, skip this script and just run the server.
 */
const DB_PATH = path.resolve(process.cwd(), '../../.mongo');

async function main(): Promise<void> {
  fs.mkdirSync(DB_PATH, { recursive: true });

  const mongod = await MongoMemoryServer.create({
    instance: {
      ip: '127.0.0.1',
      port: 27017,
      dbPath: DB_PATH,
      storageEngine: 'wiredTiger',
    },
  });

  console.log(`🟢 dev-mongo listening at ${mongod.getUri()} (dbPath: ${DB_PATH})`);
  console.log('   Ctrl+C to stop. Data persists across restarts.');

  const shutdown = (): void => {
    console.log('\n🔴 dev-mongo shutting down…');
    void mongod.stop().finally(() => process.exit(0));
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch((err: unknown) => {
  console.error('❌ dev-mongo failed to start:', err);
  process.exit(1);
});
