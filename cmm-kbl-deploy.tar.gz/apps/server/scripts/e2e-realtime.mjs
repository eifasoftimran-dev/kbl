/**
 * E2E realtime smoke test (M06 §8 / M07 §11):
 * drives a full question loop over sockets: join → start → select → lock →
 * reveal → next, verifying state:changed snapshots and sanitization.
 * Run: node scripts/e2e-realtime.mjs (server must be running on :4000)
 */
import { io } from 'socket.io-client';

const API = 'http://localhost:4000';

async function login() {
  const res = await fetch(`${API}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'admin@quiz.local', password: 'SuperAdmin@123' }),
  });
  const body = await res.json();
  if (!body.ok) throw new Error('login failed');
  return body.data.accessToken;
}

async function getSessions(token) {
  const res = await fetch(`${API}/api/sessions?limit=5`, { headers: { Authorization: `Bearer ${token}` } });
  const body = await res.json();
  return body.data.items;
}

function waitFor(emitter, event, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout waiting for ${event}`)), timeoutMs);
    emitter.on(event, (payload) => {
      clearTimeout(timer);
      resolve(payload);
    });
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  console.log('1. login…');
  const token = await login();

  console.log('2. find session…');
  const sessions = await getSessions(token);
  const session =
    sessions.find((s) => s.code === 'KBL202') ??
    sessions.find((s) => s.status === 'draft') ??
    sessions[0];
  if (!session) throw new Error('no session available — run the seed script');
  console.log(`   session: ${session.name} (${session.code}) — ${session.status}`);

  // ---- admin socket ----
  console.log('3. admin socket connect + join…');
  const admin = io(API, { auth: { token }, transports: ['websocket'] });
  const adminJoinAck = await new Promise((resolve) => {
    admin.on('connect', () => admin.emit('session:join', { sessionId: session.id }, resolve));
  });
  if (!adminJoinAck.ok) throw new Error(`admin join failed: ${adminJoinAck.error?.message}`);
  console.log('   admin joined ✓');

  // ---- display socket (anonymous, by code) ----
  console.log('4. display socket connect + join by code…');
  const display = io(API, { transports: ['websocket'] });
  const displayJoinAck = await new Promise((resolve) => {
    display.on('connect', () => display.emit('session:join', { code: session.code }, resolve));
  });
  if (!displayJoinAck.ok) throw new Error(`display join failed: ${displayJoinAck.error?.message}`);
  console.log('   display joined ✓');

  // Track latest views
  let adminView = null;
  let displayView = null;
  admin.on('state:changed', (v) => { adminView = v; });
  display.on('state:changed', (v) => { displayView = v; });

  const control = (event, payload = {}) =>
    new Promise((resolve) => admin.emit(event, { sessionId: session.id, ...payload }, resolve));

  // ---- sanitize check on every snapshot ----
  const assertNoLeak = (label) => {
    if (!displayView) return;
    const phase = displayView.phase;
    const leaked = phase !== 'answer_revealed' && displayView.reveal != null;
    if (leaked) throw new Error(`SANITIZATION LEAK at ${label} (phase=${phase}) — reveal present pre-reveal!`);
    // correctOption must never be a top-level field
    if ('correctOption' in displayView) throw new Error('SANITIZATION LEAK — correctOption at top level');
  };

  // ---- reset any leftover state so the test is repeatable ----
  if (session.status !== 'draft' || adminView?.phase !== 'idle') {
    console.log('2b. reset leftover state…');
    await control('control:reset', { confirm: true });
    await sleep(400);
    console.log(`   phase after reset: ${adminView?.phase}`);
  }

  // ---- drive the loop ----
  console.log('5. start…');
  let ack = await control('control:start');
  if (!ack.ok) throw new Error(`start failed: ${ack.error?.message}`);
  await sleep(300);
  assertNoLeak('start');

  // wait for question_active (intro is 1.5s)
  console.log('   waiting for question_active (intro 1.5s)…');
  const activeView = await waitForPhase(admin, 'question_active', 5000, () => adminView);
  assertNoLeak('question_active');
  console.log(`   phase=${activeView.phase} q=${activeView.question?.numberLabel} timer=${activeView.timer?.durationMs}ms`);

  // ---- 50:50 lifeline ----
  console.log('6. lifeline 50:50…');
  ack = await control('lifeline:use', { type: 'fifty_fifty' });
  if (!ack.ok) throw new Error(`lifeline failed: ${ack.error?.message}`);
  await sleep(300);
  const hiddenCount = (displayView?.question?.options ?? []).filter((o) => !o.visible).length;
  console.log(`   hidden options on display: ${hiddenCount}`);
  if (hiddenCount !== 2) throw new Error('expected 2 hidden options after 50:50');

  // ---- audience poll ----
  console.log('7. lifeline audience_poll…');
  ack = await control('lifeline:use', { type: 'audience_poll' });
  if (!ack.ok) throw new Error(`lifeline failed: ${ack.error?.message}`);
  await sleep(300);

  // ---- select + lock ----
  const visibleOptions = (displayView?.question?.options ?? []).filter((o) => o.visible);
  const pick = visibleOptions[0]?.key ?? 'A';
  console.log(`8. select ${pick} (visible after 50:50) + lock…`);
  ack = await control('control:select', { optionKey: pick });
  if (!ack.ok) throw new Error(`select failed: ${ack.error?.message}`);
  await sleep(200);
  assertNoLeak('answer_selected');

  ack = await control('control:lock');
  if (!ack.ok) throw new Error(`lock failed: ${ack.error?.message}`);
  await sleep(200);
  assertNoLeak('answer_locked');
  console.log(`   locked. display lockedOption=${displayView?.lockedOption}`);

  // ---- reveal ----
  console.log('9. reveal…');
  ack = await control('control:reveal');
  if (!ack.ok) throw new Error(`reveal failed: ${ack.error?.message}`);

  await waitForPhase(admin, 'answer_revealed', 6000, () => adminView);
  await sleep(200);
  // Now the reveal IS allowed on display
  if (!displayView?.reveal) throw new Error('display missing reveal in answer_revealed phase');
  if (!adminView?.reveal) throw new Error('admin missing reveal in answer_revealed phase');
  console.log(`   reveal: correct=${adminView.reveal.correctOption} isCorrect=${adminView.reveal.isCorrect} points=${adminView.reveal.pointsAwarded}`);
  console.log(`   display sees reveal: correctOption=${displayView.reveal.correctOption} ✓ (allowed post-reveal)`);

  // ---- next ----
  console.log('10. next…');
  ack = await control('control:next');
  if (!ack.ok) throw new Error(`next failed: ${ack.error?.message}`);
  await sleep(300);
  assertNoLeak('after next');
  console.log(`   phase=${adminView.phase} q=${adminView.question?.numberLabel ?? 'n/a'}`);

  // ---- end ----
  console.log('11. end…');
  ack = await control('control:end');
  if (!ack.ok) throw new Error(`end failed: ${ack.error?.message}`);
  await sleep(300);
  console.log(`   phase=${adminView.phase}`);

  // ---- reset back to draft so this test is repeatable ----
  console.log('12. reset (confirm)…');
  ack = await control('control:reset', { confirm: true });
  if (!ack.ok) throw new Error(`reset failed: ${ack.error?.message}`);
  await sleep(300);
  console.log(`   final phase=${adminView.phase}`);

  admin.disconnect();
  display.disconnect();

  console.log('\n✅ E2E REALTIME LOOP PASSED — join, start, lifelines (50:50 + poll), select, lock, reveal, next, end, reset all OK; no answer leak to display.');
}

/**
 * Wait for a target phase by polling the latest tracked view (via getLatest),
 * which the persistent `state:changed` listener keeps fresh. Avoids the
 * missed-event race of subscribing after transitions already fired.
 */
function waitForPhase(socket, target, timeoutMs, getLatest) {
  return new Promise((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const finish = (fn) => {
      clearInterval(poll);
      socket.off('state:changed', onChange);
      fn();
    };
    const check = () => {
      const view = getLatest();
      if (view?.phase === target) finish(() => resolve(view));
      else if (Date.now() > deadline)
        finish(() => reject(new Error(`timeout waiting for phase '${target}' (last: ${view?.phase ?? 'none'})`)));
    };
    const onChange = () => check();
    const poll = setInterval(check, 100);
    socket.on('state:changed', onChange);
    check();
  });
}

main().catch((err) => {
  console.error('\n❌ E2E FAILED:', err.message);
  process.exit(1);
});
