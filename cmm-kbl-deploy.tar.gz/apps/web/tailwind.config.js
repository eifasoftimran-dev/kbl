/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      // Design tokens — docs/plans/02-design-system.md §1 (no hardcoded hex in components)
      colors: {
        ink: '#E6ECFF',
        navy: { 950: '#05091F', 900: '#0A1437', 800: '#101B4A', 700: '#1A2A5E' },
        electric: { 400: '#4C7DFF', 500: '#1E5BFF' },
        gold: { 300: '#FFDD7A', 400: '#FFC93C' },
        violet: { 400: '#9D5CFF', 500: '#7B2FF7', 600: '#5B1FBF' },
        success: { 400: '#4ADE80', 500: '#22C55E' },
        warning: { 400: '#FBBF24', 500: '#F59E0B' },
        danger: { 400: '#FF6B6B', 500: '#EF4444' },
      },
      fontFamily: {
        devanagari: ['"Noto Sans Devanagari"', 'system-ui', 'sans-serif'],
        display: ['Mukta', '"Noto Sans Devanagari"', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'glow-gold':
          '0 0 0 1px rgba(255,201,60,.35), 0 0 24px rgba(255,201,60,.25), inset 0 0 12px rgba(255,201,60,.08)',
        'glow-blue':
          '0 0 0 1px rgba(30,91,255,.35), 0 0 24px rgba(30,91,255,.25), inset 0 0 12px rgba(30,91,255,.08)',
        'glow-green': '0 0 0 1px rgba(34,197,94,.5), 0 0 32px rgba(34,197,94,.35)',
        'glow-red': '0 0 0 1px rgba(239,68,68,.5), 0 0 32px rgba(239,68,68,.35)',
      },
      zIndex: { card: '10', nav: '20', modal: '30', reveal: '40', toast: '50' },
    },
  },
  plugins: [],
};
