import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

const sharedSrc = fileURLToPath(new URL('../../packages/shared/src', import.meta.url));
const webSrc = fileURLToPath(new URL('./src', import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // Consume the shared package straight from source (M01 §2) — no build step.
      '@cmm/shared': sharedSrc,
      '@': webSrc,
    },
  },
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:4000', changeOrigin: true },
      '/healthz': { target: 'http://localhost:4000', changeOrigin: true },
      '/socket.io': { target: 'http://localhost:4000', ws: true },
      '/uploads': { target: 'http://localhost:4000', changeOrigin: true },
    },
  },
});
