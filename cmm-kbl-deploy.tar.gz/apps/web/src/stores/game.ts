/**
 * Game state store (M06 §7).
 * Zustand store that ingests GameView snapshots with version guard,
 * tracks server time offset, and exposes derived selectors.
 */
import { create } from 'zustand';
import type { GameView, GamePhase, OptionKey, LifelineResult, LifelineType } from '@cmm/shared';
import { CLIENT_EVENTS } from '@cmm/shared';
import {
  onStateChanged,
  onRevealEffect,
  onLifelineResult,
  onSessionEnded,
  onConnectionChange,
  emitControl,
} from '../sockets/client';

interface GameState {
  // Core snapshot
  view: GameView | null;
  version: number;

  // Connection
  connected: boolean;
  sessionId: string | null;

  // Effects
  lastRevealEffect: { effect: string; correctOption?: OptionKey } | null;
  lastLifelineResult: LifelineResult | null;
  standings: unknown[] | null;

  // Server clock offset (EMA-smoothed)
  serverOffset: number;

  // Actions
  setView: (view: GameView) => void;
  setConnected: (connected: boolean) => void;
  setSessionId: (sessionId: string | null) => void;
  setRevealEffect: (effect: { effect: string; correctOption?: OptionKey } | null) => void;
  setLifelineResult: (result: LifelineResult | null) => void;
  setStandings: (standings: unknown[] | null) => void;

  // Control actions
  start: () => Promise<void>;
  pause: () => Promise<void>;
  resume: () => Promise<void>;
  selectOption: (key: OptionKey) => Promise<void>;
  lock: () => Promise<void>;
  reveal: () => Promise<void>;
  next: () => Promise<void>;
  end: () => Promise<void>;
  reset: () => Promise<void>;
  useLifeline: (type: LifelineType) => Promise<void>;
  switchContestant: (contestantId: string) => Promise<void>;
}

export const useGameStore = create<GameState>((set, get) => {
  // Wire up socket listeners
  const unsubState = onStateChanged((view) => {
    const state = get();
    // Version guard — ignore stale snapshots
    if (view.version <= state.version) return;
    set({ view, version: view.version });
  });

  const unsubReveal = onRevealEffect((payload) => {
    set({ lastRevealEffect: { effect: payload.effect, correctOption: payload.correctOption } });
  });

  const unsubLifeline = onLifelineResult((payload) => {
    const { sessionId, ...result } = payload;
    set({ lastLifelineResult: result as LifelineResult });
  });

  const unsubEnded = onSessionEnded((payload) => {
    set({ standings: payload.standings });
  });

  const unsubConn = onConnectionChange((connected) => {
    set({ connected });
  });

  // Update server offset from view
  const origSetView = set;

  return {
    view: null,
    version: -1,
    connected: false,
    sessionId: null,
    lastRevealEffect: null,
    lastLifelineResult: null,
    standings: null,
    serverOffset: 0,

    setView: (view) => {
      const state = get();
      if (view.version <= state.version) return;
      const offset = view.serverTime - Date.now();
      const smoothed = state.serverOffset * 0.7 + offset * 0.3; // EMA
      origSetView({ view, version: view.version, serverOffset: smoothed });
    },

    setConnected: (connected) => set({ connected }),
    setSessionId: (sessionId) => set({ sessionId }),
    setRevealEffect: (effect) => set({ lastRevealEffect: effect }),
    setLifelineResult: (result) => set({ lastLifelineResult: result }),
    setStandings: (standings) => set({ standings }),

    // Control actions
    start: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_START, { sessionId });
    },

    pause: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_PAUSE, { sessionId });
    },

    resume: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_RESUME, { sessionId });
    },

    selectOption: async (key) => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_SELECT, { sessionId, optionKey: key });
    },

    lock: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_LOCK, { sessionId });
    },

    reveal: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_REVEAL, { sessionId });
    },

    next: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_NEXT, { sessionId });
    },

    end: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_END, { sessionId });
    },

    reset: async () => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTROL_RESET, { sessionId, confirm: true });
    },

    useLifeline: async (type) => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.LIFELINE_USE, { sessionId, type });
    },

    switchContestant: async (contestantId) => {
      const { sessionId } = get();
      if (!sessionId) return;
      await emitControl(CLIENT_EVENTS.CONTESTANT_TURN, { sessionId, contestantId });
    },
  };
});

// Cleanup on module unload (HMR)
if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    // Listeners are cleaned up by zustand store destruction
  });
}

/** Derived hook — remaining ms that ticks with local clock. */
export function useRemainingMs(): number | null {
  const view = useGameStore((s) => s.view);
  const offset = useGameStore((s) => s.serverOffset);

  if (!view?.timer?.endsAt) return view?.timer?.remainingMs ?? null;
  const now = Date.now() + offset;
  return Math.max(0, view.timer.endsAt - now);
}

/** Current phase shorthand. */
export function usePhase(): GamePhase {
  return useGameStore((s) => s.view?.phase ?? 'idle');
}
