import { create } from 'zustand';
import type { Language } from '@cmm/shared';

/** UI state (M10.1): language persisted in localStorage('lang'), default hi. */
interface UiState {
  lang: Language;
  setLang: (lang: Language) => void;
}

function initialLang(): Language {
  const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('lang') : null;
  return stored === 'en' ? 'en' : 'hi';
}

export const useUiStore = create<UiState>((set) => ({
  lang: initialLang(),
  setLang: (lang) => {
    try {
      localStorage.setItem('lang', lang);
    } catch {
      /* storage unavailable — in-memory only */
    }
    set({ lang });
  },
}));
