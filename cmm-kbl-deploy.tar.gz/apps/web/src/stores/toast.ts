import { create } from 'zustand';

export type ToastTone = 'success' | 'warning' | 'danger' | 'info';

export interface Toast {
  id: string;
  tone: ToastTone;
  message: string;
  /** auto-dismiss ms (default 4000) */
  duration: number;
}

interface ToastState {
  toasts: Toast[];
  push: (tone: ToastTone, message: string, duration?: number) => void;
  dismiss: (id: string) => void;
}

let counter = 0;

export const useToastStore = create<ToastState>((set, get) => ({
  toasts: [],

  push: (tone, message, duration = 4000) => {
    const id = `t${++counter}`;
    set({ toasts: [...get().toasts, { id, tone, message, duration }] });
    if (duration > 0) {
      setTimeout(() => get().dismiss(id), duration);
    }
  },

  dismiss: (id) => {
    set({ toasts: get().toasts.filter((t) => t.id !== id) });
  },
}));

/**
 * Stable toast actions — created once at module scope so consumers can safely
 * put `toast` in hook dependency arrays without re-render loops (actions read
 * the latest store state via getState(), no subscription needed).
 */
const toastApi = {
  success: (msg: string) => useToastStore.getState().push('success', msg),
  info: (msg: string) => useToastStore.getState().push('info', msg),
  warning: (msg: string) => useToastStore.getState().push('warning', msg),
  error: (msg: string) => useToastStore.getState().push('danger', msg),
  dismiss: (id: string) => useToastStore.getState().dismiss(id),
};

/** Convenience hook — matches the server ApiClientError shape. Returns a stable reference. */
export function useToast() {
  return toastApi;
}
