/**
 * Stage scaling (M09 §2): the stage is designed at a fixed 1920×1080 canvas;
 * scale = min(vw/1920, vh/1080) — pixel-exact layout at any TV resolution.
 */
import { useEffect, useState, useCallback } from 'react';

export const STAGE_W = 1920;
export const STAGE_H = 1080;

export function useStageScaling(): { scale: number } {
  const [scale, setScale] = useState(() => calcScale());

  useEffect(() => {
    const onResize = () => setScale(calcScale());
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return { scale };
}

function calcScale(): number {
  const vw = typeof window !== 'undefined' ? window.innerWidth : STAGE_W;
  const vh = typeof window !== 'undefined' ? window.innerHeight : STAGE_H;
  return Math.min(vw / STAGE_W, vh / STAGE_H);
}

/**
 * Kiosk behaviors (M09 §1): fullscreen request, cursor auto-hide,
 * no text selection, no overscroll.
 */
export function useKioskMode(enabled: boolean): void {
  const requestFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      void document.documentElement.requestFullscreen().catch(() => {
        /* user gesture required — ignore */
      });
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;

    document.body.classList.add('kiosk-mode');

    // Auto-request fullscreen (browsers may require a gesture; retry on click)
    requestFullscreen();
    const onClick = () => requestFullscreen();
    document.addEventListener('click', onClick);

    // Hide cursor after 3s idle
    let hideTimer: ReturnType<typeof setTimeout> | null = null;
    const showCursor = () => {
      document.body.classList.remove('cursor-hidden');
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(() => document.body.classList.add('cursor-hidden'), 3000);
    };
    showCursor();
    document.addEventListener('mousemove', showCursor);

    return () => {
      document.body.classList.remove('kiosk-mode', 'cursor-hidden');
      document.removeEventListener('click', onClick);
      document.removeEventListener('mousemove', showCursor);
      if (hideTimer) clearTimeout(hideTimer);
    };
  }, [enabled, requestFullscreen]);
}

/**
 * 60fps rAF interpolation between server ticks (M09 §5).
 * Returns remaining ms updated on every animation frame —
 * pause freezes exactly because endsAt is undefined while paused.
 */
export function useSmoothRemainingMs(
  endsAt: number | undefined,
  remainingMs: number | undefined,
  serverOffset: number,
): number | null {
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    if (endsAt == null) return;

    let rafId = 0;
    const loop = () => {
      forceUpdate((n) => (n + 1) % 1000000);
      rafId = requestAnimationFrame(loop);
    };
    rafId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafId);
  }, [endsAt]);

  if (endsAt != null) {
    const now = Date.now() + serverOffset;
    return Math.max(0, endsAt - now);
  }
  return remainingMs ?? null;
}
