import type { ReactElement } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './lib/auth';
import LoginPage from './pages/LoginPage';
import AdminLayout from './pages/admin/AdminLayout';
import DashboardPage from './pages/admin/DashboardPage';
import QuestionsPage from './pages/admin/QuestionsPage';
import ContestantsPage from './pages/admin/ContestantsPage';
import SessionsPage from './pages/admin/SessionsPage';
import UsersPage from './pages/admin/UsersPage';
import SettingsPage from './pages/admin/SettingsPage';
import ModulePlaceholderPage from './pages/admin/ModulePlaceholderPage';
import OperatorCockpitPage from './pages/admin/operator/OperatorCockpitPage';
import DisplayPage from './pages/DisplayPage';
import StyleguidePage from './pages/StyleguidePage';
import { Toaster } from './components/ui/Toaster';
import { AuthProvider } from './lib/auth';

/** Route guard (M05 §5): unauthenticated users bounce to /login. */
function RequireAuth({ children }: { children: ReactElement }) {
  const { user, booting } = useAuth();
  if (booting) return null; // avoid a login flash while /me resolves
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster />
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        <Route
          path="/admin"
          element={
            <RequireAuth>
              <AdminLayout />
            </RequireAuth>
          }
        >
          <Route index element={<DashboardPage />} />
          <Route path="questions" element={<QuestionsPage />} />
          <Route path="contestants" element={<ContestantsPage />} />
          <Route path="sessions" element={<SessionsPage />} />
          <Route path="display" element={<OperatorCockpitPage />} />
          <Route path="reports" element={<ModulePlaceholderPage labelKey="nav:reports" />} />
          <Route path="users" element={<UsersPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>

        <Route path="/display/:code" element={<DisplayPage />} />
        <Route path="/styleguide" element={<StyleguidePage />} />
        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Routes>
    </BrowserRouter>
    </AuthProvider>
  );
}
