/**
 * Socket.io client singleton (M06 §6).
 * - Auto-reconnect with infinite attempts
 * - Re-joins session room on every (re)connect
 * - Typed emit-with-ack wrappers
 */
import { io, type Socket } from 'socket.io-client';
import { CLIENT_EVENTS, SERVER_EVENTS } from '@cmm/shared';
import type { GameView, LifelineResult, OptionKey } from '@cmm/shared';
import { getAccessToken } from '../lib/api';

type AckResult = { ok: true; data?: unknown } | { ok: false; error: { code: string; message: string } };

let socket: Socket | null = null;
let currentSessionId: string | null = null;
let joinCode: string | null = null;

type StateChangedListener = (view: GameView) => void;
type RevealEffectListener = (payload: { sessionId: string; effect: string; correctOption?: OptionKey }) => void;
type LifelineResultListener = (payload: { sessionId: string } & LifelineResult) => void;
type SessionEndedListener = (payload: { sessionId: string; standings: unknown[] }) => void;
type ConnectionListener = (connected: boolean) => void;

const stateChangedListeners = new Set<StateChangedListener>();
const revealEffectListeners = new Set<RevealEffectListener>();
const lifelineResultListeners = new Set<LifelineResultListener>();
const sessionEndedListeners = new Set<SessionEndedListener>();
const connectionListeners = new Set<ConnectionListener>();

/** Get or create the socket connection. */
export function getSocket(): Socket {
  if (socket) return socket;

  socket = io(window.location.origin, {
    auth: { token: getAccessToken() },
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelayMax: 5000,
    transports: ['websocket', 'polling'],
  });

  // On every (re)connect, re-join the session room
  socket.on('connect', () => {
    connectionListeners.forEach((fn) => fn(true));

    // Re-join admin session
    if (currentSessionId) {
      socket!.emit(CLIENT_EVENTS.SESSION_JOIN, { sessionId: currentSessionId });
    }
    // Re-join display session
    if (joinCode) {
      socket!.emit(CLIENT_EVENTS.SESSION_JOIN, { code: joinCode });
    }
  });

  socket.on('disconnect', () => {
    connectionListeners.forEach((fn) => fn(false));
  });

  // Server events
  socket.on(SERVER_EVENTS.STATE_CHANGED, (view: GameView) => {
    stateChangedListeners.forEach((fn) => fn(view));
  });

  socket.on(SERVER_EVENTS.REVEAL_EFFECT, (payload: { sessionId: string; effect: string; correctOption?: OptionKey }) => {
    revealEffectListeners.forEach((fn) => fn(payload));
  });

  socket.on(SERVER_EVENTS.LIFELINE_RESULT, (payload: { sessionId: string } & LifelineResult) => {
    lifelineResultListeners.forEach((fn) => fn(payload));
  });

  socket.on(SERVER_EVENTS.SESSION_ENDED, (payload: { sessionId: string; standings: unknown[] }) => {
    sessionEndedListeners.forEach((fn) => fn(payload));
  });

  return socket;
}

/** Connect as admin and join a session room by ID. */
export function joinAdminSession(sessionId: string): Promise<AckResult> {
  currentSessionId = sessionId;
  joinCode = null;
  const s = getSocket();
  return new Promise((resolve) => {
    s.emit(CLIENT_EVENTS.SESSION_JOIN, { sessionId }, (ack: AckResult) => {
      resolve(ack);
    });
  });
}

/** Connect as display and join a session room by code. */
export function joinDisplaySession(code: string): Promise<AckResult> {
  joinCode = code;
  currentSessionId = null;
  // Display uses anonymous connection (no token)
  if (socket) {
    socket.disconnect();
    socket = null;
  }
  const s = io(window.location.origin, {
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelayMax: 5000,
    transports: ['websocket', 'polling'],
  });
  socket = s;

  s.on('connect', () => {
    connectionListeners.forEach((fn) => fn(true));
    if (joinCode) {
      s.emit(CLIENT_EVENTS.SESSION_JOIN, { code: joinCode });
    }
  });

  s.on('disconnect', () => {
    connectionListeners.forEach((fn) => fn(false));
  });

  s.on(SERVER_EVENTS.STATE_CHANGED, (view: GameView) => {
    stateChangedListeners.forEach((fn) => fn(view));
  });

  s.on(SERVER_EVENTS.REVEAL_EFFECT, (payload: { sessionId: string; effect: string; correctOption?: OptionKey }) => {
    revealEffectListeners.forEach((fn) => fn(payload));
  });

  s.on(SERVER_EVENTS.LIFELINE_RESULT, (payload: { sessionId: string } & LifelineResult) => {
    lifelineResultListeners.forEach((fn) => fn(payload));
  });

  s.on(SERVER_EVENTS.SESSION_ENDED, (payload: { sessionId: string; standings: unknown[] }) => {
    sessionEndedListeners.forEach((fn) => fn(payload));
  });

  return new Promise((resolve) => {
    s.emit(CLIENT_EVENTS.SESSION_JOIN, { code }, (ack: AckResult) => {
      resolve(ack);
    });
  });
}

/** Emit a control event with ack. */
export function emitControl(event: string, payload: Record<string, unknown>): Promise<AckResult> {
  const s = getSocket();
  return new Promise((resolve) => {
    s.emit(event, payload, (ack: AckResult) => {
      resolve(ack);
    });
  });
}

/** Leave current session. */
export function leaveSession(): void {
  if (!socket) return;
  if (currentSessionId) {
    socket.emit(CLIENT_EVENTS.SESSION_LEAVE, { sessionId: currentSessionId });
  }
  currentSessionId = null;
  joinCode = null;
}

/** Disconnect and clean up. */
export function disconnectSocket(): void {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
  currentSessionId = null;
  joinCode = null;
}

// ---------------------------------------------------------------------------
// Listener registration
// ---------------------------------------------------------------------------

export function onStateChanged(fn: StateChangedListener): () => void {
  stateChangedListeners.add(fn);
  return () => stateChangedListeners.delete(fn);
}

export function onRevealEffect(fn: RevealEffectListener): () => void {
  revealEffectListeners.add(fn);
  return () => revealEffectListeners.delete(fn);
}

export function onLifelineResult(fn: LifelineResultListener): () => void {
  lifelineResultListeners.add(fn);
  return () => lifelineResultListeners.delete(fn);
}

export function onSessionEnded(fn: SessionEndedListener): () => void {
  sessionEndedListeners.add(fn);
  return () => sessionEndedListeners.delete(fn);
}

export function onConnectionChange(fn: ConnectionListener): () => void {
  connectionListeners.add(fn);
  return () => connectionListeners.delete(fn);
}

/** Check if socket is currently connected. */
export function isConnected(): boolean {
  return socket?.connected ?? false;
}
