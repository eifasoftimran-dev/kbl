/**
 * RevealOverlay (M09 §4): full-screen drama on answer_revealed —
 * correct → green ✓ + confetti; wrong → red ✗ + correct option outlined gold.
 * GameOverFinale: standings podium, trophy, winner spotlight.
 */
import { useTranslation } from 'react-i18next';
import { Trophy } from 'lucide-react';
import type { GameView } from '@cmm/shared';
import { formatINR } from './TimerRing';

export function RevealOverlay({ view }: { view: GameView }) {
  const { t } = useTranslation('display');
  const reveal = view.reveal;
  if (!reveal) return null;

  return (
    <div className="reveal-overlay">
      <div className={`reveal-card ${reveal.isCorrect ? 'reveal-card--correct' : 'reveal-card--wrong'}`}>
        <p className={`font-display text-6xl font-extrabold ${reveal.isCorrect ? 'text-success-400' : 'text-danger-400'}`}>
          {reveal.isCorrect ? t('branding.reveal.correct') : t('branding.reveal.wrong')}
        </p>

        {!reveal.isCorrect && reveal.correctOption && (
          <p className="mt-3 text-xl font-bold text-gold-400">
            {t('branding.reveal.correctWas', { key: reveal.correctOption })} {reveal.correctOption}
          </p>
        )}

        {reveal.pointsAwarded > 0 && (
          <p className="tabular mt-4 text-2xl font-extrabold text-gold-400">
            + ₹{formatINR(reveal.pointsAwarded)}
          </p>
        )}

        {reveal.explanation && (
          <div className="glass mt-6 max-w-2xl px-6 py-4 text-center">
            <p className="text-sm font-semibold leading-relaxed text-ink/80">{reveal.explanation}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export function GameOverFinale({ view }: { view: GameView }) {
  const { t } = useTranslation('display');
  const sorted = [...view.contestants].sort((a, b) => b.score - a.score);
  const winner = sorted[0];
  const rest = sorted.slice(1);

  return (
    <div className="flex h-full flex-col items-center justify-center gap-10">
      <div className="flex items-center gap-4">
        <Trophy className="h-12 w-12 text-gold-400 trophy-pulse" aria-hidden />
        <p className="font-display text-3xl font-extrabold uppercase tracking-[0.3em] text-gold-400">
          {t('branding.gameOver')}
        </p>
      </div>

      {/* Winner podium */}
      {winner && (
        <div className="winner-spotlight glass glass--gold px-20 py-12 text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-ink/50">{t('branding.winner')}</p>
          <p className="mt-3 font-display text-6xl font-extrabold text-gold-400">{winner.name}</p>
          <p className="tabular mt-4 font-display text-4xl font-extrabold text-ink">₹{formatINR(winner.score)}</p>
        </div>
      )}

      {/* Runners up */}
      {rest.length > 0 && (
        <div className="flex items-end justify-center gap-6">
          {rest.map((c, i) => (
            <div key={c.id} className="glass rounded-xl px-8 py-5 text-center">
              <p className="text-xs font-bold text-ink/40">#{i + 2}</p>
              <p className="mt-1 font-display text-2xl font-bold text-ink">{c.name}</p>
              <p className="tabular mt-1 text-lg font-bold text-gold-300/80">₹{formatINR(c.score)}</p>
            </div>
          ))}
        </div>
      )}

      <p className="font-display text-xl font-bold text-ink/50">{t('branding.thankYou')}</p>
    </div>
  );
}

/** Branding screen (idle / display:command branding) — M09 §7. */
export function BrandingScreen({ code, slogans }: { code: string; slogans?: { topLeft: string; center: string; topRight: string } }) {
  const { t } = useTranslation('display');

  return (
    <div className="flex h-full flex-col items-center justify-center gap-8">
      {/* Pulsing logo mark */}
      <div className="logo-pulse flex h-28 w-28 items-center justify-center rounded-full border-2 border-gold-400/60 shadow-glow-gold">
        <span className="font-display text-4xl font-extrabold text-gold-400">?</span>
      </div>

      <div className="text-center">
        <p className="font-display text-2xl font-bold text-ink/70">{slogans?.center ?? 'सोचो • चुनो • जीतो'}</p>
        <p className="mt-2 text-sm font-semibold text-ink/40">{slogans?.topLeft ?? 'ज्ञान से बदलती है किस्मत'}</p>
      </div>

      <div className="glass glass--gold px-16 py-8 text-center">
        <p className="mb-3 text-xs font-bold uppercase tracking-widest text-ink/50">{t('branding.joinPrompt')}</p>
        <p className="tabular font-display text-6xl font-extrabold tracking-[0.25em] text-gold-400 drop-shadow-[0_0_24px_rgba(255,201,60,0.35)]">
          {code.toUpperCase()}
        </p>
      </div>

      <p className="animate-pulse font-display text-lg font-bold uppercase tracking-[0.3em] text-gold-400/80">
        {t('branding.startingSoon')}
      </p>
    </div>
  );
}

/** Paused veil overlay (M09 §4). */
export function PausedVeil() {
  const { t } = useTranslation('display');
  return (
    <div className="paused-veil">
      <div className="text-center">
        <p className="text-7xl">⏸</p>
        <p className="mt-4 font-display text-2xl font-bold text-ink/80">{t('branding.paused')}</p>
      </div>
    </div>
  );
}
