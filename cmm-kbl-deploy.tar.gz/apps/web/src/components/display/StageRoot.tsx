/**
 * StageRoot (M09 §2): fixed 1920×1080 canvas scaled to viewport,
 * centered with letterbox bars showing the backdrop gradient.
 */
import type { ReactNode } from 'react';
import { useStageScaling, STAGE_W, STAGE_H } from '../../hooks/stage';

export function StageRoot({ children }: { children: ReactNode }) {
  const { scale } = useStageScaling();

  return (
    <div className="stage-bg fixed inset-0 overflow-hidden">
      <div
        style={{
          width: STAGE_W,
          height: STAGE_H,
          transform: `translate(-50%, -50%) scale(${scale})`,
          position: 'absolute',
          left: '50%',
          top: '50%',
        }}
      >
        {children}
      </div>
    </div>
  );
}

/**
 * StageBackdrop (M09 §2): ambient spotlights + floor reflection +
 * audience silhouettes — pure visual layers behind the zones.
 */
export function StageBackdrop({ showReflection = true }: { showReflection?: boolean }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* Rotating spotlights */}
      <div className="stage-spotlight stage-spotlight--left" />
      <div className="stage-spotlight stage-spotlight--right" />

      {/* Bokeh particles */}
      <div className="stage-bokeh stage-bokeh--1" />
      <div className="stage-bokeh stage-bokeh--2" />
      <div className="stage-bokeh stage-bokeh--3" />
      <div className="stage-bokeh stage-bokeh--4" />
      <div className="stage-bokeh stage-bokeh--5" />

      {/* Reflective floor */}
      {showReflection && <div className="stage-floor" />}

      {/* Audience silhouettes */}
      <div className="stage-silhouettes">
        {Array.from({ length: 24 }).map((_, i) => (
          <div
            key={i}
            className="stage-silhouette"
            style={{
              left: `${(i * 4.2) % 100}%`,
              height: `${30 + ((i * 17) % 40)}px`,
              animationDelay: `${(i * 0.7) % 4}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
