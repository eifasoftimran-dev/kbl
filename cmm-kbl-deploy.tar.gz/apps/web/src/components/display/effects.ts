/**
 * Confetti + audio effects (M09 §8).
 * - Confetti: gold/blue burst on correct reveal; sustained rain at game over.
 * - Audio: howler-based tick/lock/suspense/correct/wrong — optional;
 *   never blocks the show if audio is unavailable.
 */
import { useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Howl } from 'howler';
import type { GamePhase } from '@cmm/shared';

const GOLD = '#FFC93C';
const BLUE = '#1E5BFF';

/** Fire a one-shot gold/blue confetti burst (correct answer). */
export function fireCorrectBurst(): void {
  if (prefersReducedMotion()) return;
  void confetti({
    particleCount: 160,
    spread: 100,
    startVelocity: 45,
    origin: { x: 0.5, y: 0.6 },
    colors: [GOLD, BLUE, '#FFFFFF'],
    disableForReducedMotion: true,
  });
}

/** Sustained confetti rain (game-over finale) — returns a stop fn. */
export function startFinaleRain(): () => void {
  if (prefersReducedMotion()) return () => undefined;
  const end = Date.now() + 6000;

  const frame = () => {
    void confetti({
      particleCount: 4,
      angle: 60,
      spread: 60,
      origin: { x: 0, y: 0.7 },
      colors: [GOLD],
      disableForReducedMotion: true,
    });
    void confetti({
      particleCount: 4,
      angle: 120,
      spread: 60,
      origin: { x: 1, y: 0.7 },
      colors: [BLUE, '#FFFFFF'],
      disableForReducedMotion: true,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);

  return () => undefined; // rain self-terminates after 6s
}

function prefersReducedMotion(): boolean {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// ---------------------------------------------------------------------------
// Audio
// ---------------------------------------------------------------------------

export type StageSound = 'tick' | 'lock' | 'suspense' | 'correct' | 'wrong' | 'finale';

/**
 * useStageAudio (M09 §8): optional audio hooks.
 * Sounds are synthesized fallbacks (no asset files yet) via WebAudio —
 * a single AudioContext unlocks on first user gesture.
 */
export function useStageAudio(): { play: (sound: StageSound) => void } {
  const ctxRef = useRef<AudioContext | null>(null);

  const ensureCtx = useCallback((): AudioContext | null => {
    if (typeof window === 'undefined') return null;
    if (!ctxRef.current) {
      try {
        const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return null;
        ctxRef.current = new AC();
      } catch {
        return null;
      }
    }
    // Autoplay policy: resume on (user-initiated) call
    if (ctxRef.current.state === 'suspended') void ctxRef.current.resume().catch(() => undefined);
    return ctxRef.current;
  }, []);

  const play = useCallback(
    (sound: StageSound) => {
      const ctx = ensureCtx();
      if (!ctx) return;
      const now = ctx.currentTime;

      const tone = (freq: number, start: number, dur: number, type: OscillatorType = 'sine', gain = 0.15) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = type;
        osc.frequency.value = freq;
        g.gain.setValueAtTime(gain, now + start);
        g.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
        osc.connect(g).connect(ctx.destination);
        osc.start(now + start);
        osc.stop(now + start + dur);
      };

      switch (sound) {
        case 'tick':
          tone(880, 0, 0.06, 'square', 0.05);
          break;
        case 'lock':
          tone(140, 0, 0.25, 'sawtooth', 0.2);
          tone(90, 0.05, 0.3, 'sine', 0.25);
          break;
        case 'suspense':
          // heartbeat — two low thumps
          tone(70, 0, 0.15, 'sine', 0.3);
          tone(60, 0.25, 0.2, 'sine', 0.3);
          break;
        case 'correct':
          // rising fanfare arpeggio
          tone(523, 0, 0.15, 'triangle', 0.2);
          tone(659, 0.12, 0.15, 'triangle', 0.2);
          tone(784, 0.24, 0.2, 'triangle', 0.2);
          tone(1047, 0.36, 0.35, 'triangle', 0.25);
          break;
        case 'wrong':
          // descending buzz
          tone(220, 0, 0.2, 'sawtooth', 0.18);
          tone(165, 0.15, 0.25, 'sawtooth', 0.18);
          tone(110, 0.3, 0.35, 'sawtooth', 0.2);
          break;
        case 'finale':
          // grand chord
          tone(523, 0, 0.6, 'triangle', 0.15);
          tone(659, 0.05, 0.6, 'triangle', 0.15);
          tone(784, 0.1, 0.6, 'triangle', 0.15);
          tone(1047, 0.15, 0.8, 'triangle', 0.2);
          break;
      }
    },
    [ensureCtx],
  );

  return { play };
}

/**
 * useStageEffects: reacts to phase transitions + reveal effects —
 * fires confetti and audio in sync with the show.
 */
export function useStageEffects(phase: GamePhase, lastRevealEffect: { effect: string } | null): void {
  const { play } = useStageAudio();
  const prevPhase = useRef<GamePhase>(phase);
  const prevEffect = useRef<string | null>(null);
  const rainStop = useRef<(() => void) | null>(null);

  useEffect(() => {
    const phaseChanged = prevPhase.current !== phase;
    const prev = prevPhase.current;
    prevPhase.current = phase;

    if (!phaseChanged) return;

    // Phase-based effects
    if (phase === 'reveal_suspense') {
      play('suspense');
    } else if (phase === 'answer_locked') {
      play('lock');
    } else if (phase === 'answer_revealed' && prev === 'reveal_suspense') {
      // reveal result handled by the reveal effect below
    } else if (phase === 'game_over') {
      play('finale');
      rainStop.current = startFinaleRain();
    } else if (phase === 'question_intro' && prev === 'game_over') {
      rainStop.current?.();
      rainStop.current = null;
    }
  }, [phase, play]);

  useEffect(() => {
    if (!lastRevealEffect) return;
    if (prevEffect.current === lastRevealEffect.effect) return;
    prevEffect.current = lastRevealEffect.effect;

    if (lastRevealEffect.effect === 'correct') {
      play('correct');
      fireCorrectBurst();
    } else if (lastRevealEffect.effect === 'wrong') {
      play('wrong');
    }
  }, [lastRevealEffect, play]);
}

// Re-export Howl type check so the import is used (audio asset pipeline M12)
export type { Howl as HowlType };
