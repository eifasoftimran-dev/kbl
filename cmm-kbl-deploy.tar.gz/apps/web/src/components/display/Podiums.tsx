/**
 * Podiums (M09 §7): 3 contestant stands with illuminated name plates,
 * ScoreCounter count-up, and active-turn spotlight cone.
 */
import { useEffect, useRef, useState } from 'react';
import { Mic } from 'lucide-react';
import { formatINR } from './TimerRing';

interface PodiumProps {
  contestants: { id: string; name: string; score: number; isActive: boolean }[];
}

export function Podiums({ contestants }: PodiumProps) {
  if (contestants.length === 0) return null;

  return (
    <div className="flex items-end gap-6">
      {contestants.map((c) => (
        <Podium key={c.id} name={c.name} score={c.score} isActive={c.isActive} />
      ))}
    </div>
  );
}

function Podium({ name, score, isActive }: { name: string; score: number; isActive: boolean }) {
  return (
    <div className={`relative flex w-[220px] flex-col items-center gap-2 ${isActive ? 'podium--active' : ''}`}>
      {/* Active-turn spotlight cone */}
      {isActive && <div className="podium-spotlight" aria-hidden />}

      {/* Mic */}
      {isActive && <Mic className="h-6 w-6 text-electric-400" aria-hidden />}

      {/* Score counter */}
      <ScoreCounter score={score} highlight={isActive} />

      {/* Name plate */}
      <div
        className={`w-full rounded-t-xl border-x border-t px-4 py-3 text-center ${
          isActive
            ? 'border-gold-400/60 bg-gradient-to-b from-gold-400/25 to-navy-800/80 shadow-glow-gold'
            : 'border-white/10 bg-navy-800/60'
        }`}
      >
        <span className={`font-display text-xl font-bold tracking-wide ${isActive ? 'text-gold-400' : 'text-ink/70'}`}>
          {name}
        </span>
      </div>

      {/* Stand */}
      <div
        className={`h-16 w-full rounded-b-xl border-x border-b ${
          isActive ? 'border-gold-400/40 bg-gradient-to-b from-navy-700 to-navy-900' : 'border-white/5 bg-navy-900/60'
        }`}
      />
    </div>
  );
}

/**
 * ScoreCounter (M09 §7): animates the displayed value toward the real score
 * (count-up) — updates land on T7 reveal.
 */
function ScoreCounter({ score, highlight }: { score: number; highlight: boolean }) {
  const [display, setDisplay] = useState(score);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    // Animate from current display toward the new score
    const from = display;
    const to = score;
    if (from === to) return;

    const duration = 800;
    const startTime = performance.now();

    const step = (now: number) => {
      const t = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - t, 3); // ease-out cubic
      setDisplay(Math.round(from + (to - from) * eased));
      if (t < 1) {
        rafRef.current = requestAnimationFrame(step);
      }
    };
    rafRef.current = requestAnimationFrame(step);

    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [score]);

  return (
    <div
      className={`glass tabular flex items-center gap-2 rounded-xl px-4 py-2 ${
        highlight ? 'shadow-glow-gold' : 'opacity-80'
      }`}
    >
      <span className={`font-display text-2xl font-extrabold ${highlight ? 'text-gold-400' : 'text-ink/80'}`}>
        ₹{formatINR(display)}
      </span>
    </div>
  );
}

/**
 * FlowStrip (M09 §7): "लाइव गेमप्ले फ़्लो" — 4 mini glass screens showing the
 * current stage of the show: ① question ② selection ③ lock ④ result.
 */
import { useTranslation } from 'react-i18next';
import type { GamePhase } from '@cmm/shared';

export function FlowStrip({ phase }: { phase: GamePhase }) {
  const { t } = useTranslation('display');

  const stepStates: ('done' | 'active' | 'todo')[] = [
    // Step 1: प्रश्न दिखता है — active during intro/active, done after
    phase === 'question_intro' || phase === 'question_active' ? 'active' : 'done',
    // Step 2: प्रतियोगी उत्तर चुनता है
    phase === 'answer_selected' ? 'active' : ['answer_locked', 'reveal_suspense', 'answer_revealed'].includes(phase) ? 'done' : 'todo',
    // Step 3: उत्तर की पुष्टि
    phase === 'answer_locked' || phase === 'reveal_suspense' ? 'active' : phase === 'answer_revealed' ? 'done' : 'todo',
    // Step 4: सही/गलत रिज़ल्ट
    phase === 'answer_revealed' ? 'active' : 'todo',
  ];

  return (
    <div className="glass flex items-center gap-3 p-3">
      {stepStates.map((state, i) => (
        <div
          key={i}
          className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${
            state === 'active'
              ? 'border-gold-400/60 bg-gold-400/15 shadow-glow-gold'
              : state === 'done'
                ? 'border-success-400/30 bg-success-500/10'
                : 'border-white/5 bg-navy-900/40 opacity-50'
          }`}
        >
          <span
            className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-extrabold ${
              state === 'active'
                ? 'bg-gold-400 text-navy-900'
                : state === 'done'
                  ? 'bg-success-500/30 text-success-400'
                  : 'bg-navy-700 text-ink/40'
            }`}
          >
            {state === 'done' ? '✓' : i + 1}
          </span>
          <span className={`text-xs font-bold ${state === 'active' ? 'text-gold-400' : 'text-ink/60'}`}>
            {t(`branding.flow.step${i + 1}`)}
          </span>
        </div>
      ))}
    </div>
  );
}
