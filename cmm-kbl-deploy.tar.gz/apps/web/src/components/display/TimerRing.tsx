/**
 * TimerRing (M09 §5): SVG circle with progress via stroke-dashoffset.
 * Color thresholds: >10s green · 5–10s amber · <5s red + pulse.
 * Paused → frozen + gray + pause icon.
 */
import { useTranslation } from 'react-i18next';

interface TimerRingProps {
  remainingMs: number | null;
  durationMs: number;
  paused: boolean;
  active: boolean;
}

const R = 100;
const CIRCUMFERENCE = 2 * Math.PI * R;

export function TimerRing({ remainingMs, durationMs, paused, active }: TimerRingProps) {
  const { t } = useTranslation('display');

  if (remainingMs == null || !active) {
    return (
      <div className="glass flex h-[220px] w-[220px] items-center justify-center rounded-full opacity-40">
        <span className="font-display text-5xl font-extrabold text-ink/30">—</span>
      </div>
    );
  }

  const seconds = Math.ceil(remainingMs / 1000);
  const pct = Math.max(0, Math.min(1, remainingMs / durationMs));
  const offset = CIRCUMFERENCE * (1 - pct);

  const color = paused
    ? 'text-ink/30'
    : seconds > 10
      ? 'text-success-400'
      : seconds > 5
        ? 'text-warning-400'
        : 'text-danger-400';

  const strokeColor = paused
    ? 'rgba(230,236,255,0.15)'
    : seconds > 10
      ? '#4ADE80'
      : seconds > 5
        ? '#FBBF24'
        : '#EF4444';

  return (
    <div className={`relative h-[220px] w-[220px] ${seconds <= 5 && !paused ? 'timer-warning' : ''}`}>
      <svg width="220" height="220" viewBox="0 0 220 220" className="-rotate-90">
        {/* Track */}
        <circle cx="110" cy="110" r={R} fill="none" stroke="rgba(230,236,255,0.08)" strokeWidth="10" />
        {/* Progress */}
        <circle
          cx="110"
          cy="110"
          r={R}
          fill="none"
          stroke={strokeColor}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 200ms linear' }}
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {paused ? (
          <span className="text-5xl text-ink/40">⏸</span>
        ) : (
          <>
            <span className={`font-display tabular text-6xl font-extrabold ${color}`}>{seconds}</span>
            <span className="mt-1 text-sm font-bold uppercase tracking-widest text-ink/40">
              {t('branding.timer.seconds')}
            </span>
          </>
        )}
      </div>
    </div>
  );
}

/**
 * PrizeLadder (M09 §3): compact 15-level column — current level highlighted
 * gold, safe havens starred, achieved levels bright.
 */
interface PrizeLadderProps {
  levels: { level: number; amount: number; isSafeHaven: boolean }[];
  currentLevel: number;
}

export function PrizeLadder({ levels, currentLevel }: PrizeLadderProps) {
  // Show 7 levels around current for compactness
  const windowSize = 7;
  const start = Math.max(0, Math.min(currentLevel - 2, levels.length - windowSize));
  const visible = levels.slice(start, start + windowSize);

  return (
    <div className="glass flex w-[180px] flex-col gap-0.5 p-2">
      {[...visible].reverse().map((l) => {
        const isCurrent = l.level === currentLevel;
        const isAchieved = l.level < currentLevel;
        return (
          <div
            key={l.level}
            className={`flex items-center justify-between rounded px-3 py-1.5 text-sm ${
              isCurrent
                ? 'bg-gold-400/20 font-extrabold text-gold-400 shadow-glow-gold'
                : isAchieved
                  ? 'font-bold text-gold-300/70'
                  : l.isSafeHaven
                    ? 'font-semibold text-gold-400/50'
                    : 'text-ink/40'
            }`}
          >
            <span className="tabular w-6">{l.level}</span>
            <span className="tabular">₹{formatINR(l.amount)}</span>
            {l.isSafeHaven && <span className="text-gold-400">★</span>}
          </div>
        );
      })}
    </div>
  );
}

/** Indian number formatting: 1,00,00,000 style */
export function formatINR(amount: number): string {
  return amount.toLocaleString('en-IN');
}
