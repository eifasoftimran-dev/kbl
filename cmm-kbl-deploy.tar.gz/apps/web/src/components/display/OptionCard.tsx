/**
 * OptionCard (M09 §6): KBC-style glass card with gold-framed hexagon letter plate.
 * States: default → selected → locked → eliminated → correct → wrong → dimmed.
 * Non-interactive by design — the contestant's choice enters via host/operator.
 */
import type { OptionKey } from '@cmm/shared';
import { Lock } from 'lucide-react';

export type OptionVisualState =
  | 'default'
  | 'dimmed'
  | 'selected'
  | 'locked'
  | 'suspense'
  | 'eliminated'
  | 'correct'
  | 'wrong';

interface OptionCardProps {
  optKey: OptionKey;
  text: string;
  state: OptionVisualState;
  /** stagger delay in ms for fade-in during question_intro */
  enterDelay?: number;
}

export function OptionCard({ optKey, text, state, enterDelay = 0 }: OptionCardProps) {
  if (state === 'eliminated') {
    return (
      <div className="option-card option-card--eliminated" style={{ animationDelay: `${enterDelay}ms` }}>
        <span className="option-plate option-plate--eliminated">{optKey}</span>
        <span className="option-text option-text--eliminated">{text}</span>
      </div>
    );
  }

  const stateClass = `option-card--${state}`;

  return (
    <div className={`option-card ${stateClass}`} style={{ animationDelay: `${enterDelay}ms` }}>
      <span className={`option-plate ${state === 'locked' || state === 'correct' ? 'option-plate--filled' : ''}`}>
        {optKey}
      </span>
      <span className="option-text">{text}</span>
      {state === 'locked' && <Lock className="ml-2 h-7 w-7 shrink-0 text-navy-900" aria-hidden />}
      {state === 'suspense' && <span className="option-suspense-dots" aria-hidden>•••</span>}
    </div>
  );
}

/**
 * QuestionBox (M09 §3): प्रश्न 01 plate + question text + optional media.
 */
interface QuestionBoxProps {
  numberLabel: string;
  total: number;
  text: string;
  difficulty: string;
  media?: { kind: 'image' | 'video'; url: string } | null;
  introPhase: boolean;
}

export function QuestionBox({ numberLabel, total, text, difficulty, media, introPhase }: QuestionBoxProps) {
  return (
    <div className={`glass glass--blue flex flex-col gap-4 p-6 ${introPhase ? 'question-intro' : ''}`}>
      {/* Question plate */}
      <div className="flex items-center gap-4">
        <span className="question-number-plate">{numberLabel}</span>
        <span className="text-sm font-bold uppercase tracking-widest text-ink/40">/ {total}</span>
        <span
          className={`ml-auto rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
            difficulty === 'easy'
              ? 'bg-success-500/15 text-success-400'
              : difficulty === 'medium'
                ? 'bg-warning-500/15 text-warning-400'
                : 'bg-danger-500/15 text-danger-400'
          }`}
        >
          {difficulty}
        </span>
      </div>

      {/* Question text */}
      <p className="font-display text-3xl font-bold leading-snug text-ink">{text}</p>

      {/* Media */}
      {media && (
        <div className="overflow-hidden rounded-xl border border-white/10">
          {media.kind === 'image' ? (
            <img src={media.url} alt="" className="max-h-[200px] w-full object-cover" />
          ) : (
            <video src={media.url} controls={false} muted loop autoPlay className="max-h-[200px] w-full object-cover" />
          )}
        </div>
      )}
    </div>
  );
}

/**
 * LifelinesRow (M09 §3): the 3 lifeline badges for the active contestant —
 * grayed out + strikethrough when exhausted; poll result bars overlay.
 */
import type { LifelineType } from '@cmm/shared';
import { useTranslation } from 'react-i18next';

interface LifelinesRowProps {
  lifelines: Record<LifelineType, number>;
  pollDistribution?: Record<string, number> | null;
}

export function LifelinesRow({ lifelines, pollDistribution }: LifelinesRowProps) {
  const { t } = useTranslation('display');

  return (
    <div className="flex items-center gap-4">
      <LifelineBadge icon="50:50" label="50:50" count={lifelines.fifty_fifty} />
      <LifelineBadge icon="👥" label={t('branding.lifelines.audiencePoll')} count={lifelines.audience_poll} />
      <LifelineBadge icon="📞" label={t('branding.lifelines.expertCall')} count={lifelines.expert_call} />

      {/* Audience poll bars overlay */}
      {pollDistribution && (
        <div className="glass ml-4 flex items-end gap-3 rounded-xl px-4 py-2">
          {(['A', 'B', 'C', 'D'] as const).map((key) => {
            const pct = pollDistribution[key] ?? 0;
            return (
              <div key={key} className="flex flex-col items-center gap-1">
                <div className="flex h-16 w-10 items-end overflow-hidden rounded-md bg-navy-800">
                  <div
                    className="w-full rounded-md bg-gradient-to-t from-electric-500 to-gold-400 transition-all duration-700"
                    style={{ height: `${pct}%` }}
                  />
                </div>
                <span className="tabular text-xs font-bold text-ink/60">{pct}%</span>
                <span className="text-xs font-bold text-electric-400">{key}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function LifelineBadge({ icon, label, count }: { icon: string; label: string; count: number }) {
  const exhausted = count <= 0;
  return (
    <div
      className={`flex items-center gap-2 rounded-full border px-4 py-2 ${
        exhausted
          ? 'border-white/5 bg-navy-900/40 opacity-40'
          : 'border-gold-400/30 bg-navy-800/60 shadow-glow-gold'
      }`}
    >
      <span className={`text-lg ${exhausted ? 'line-through' : ''}`}>{icon}</span>
      <span className={`text-sm font-bold ${exhausted ? 'text-ink/30 line-through' : 'text-gold-400'}`}>{label}</span>
      {!exhausted && <span className="tabular text-xs text-ink/50">×{count}</span>}
    </div>
  );
}
