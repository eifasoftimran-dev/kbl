import { forwardRef, type InputHTMLAttributes } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

/** Dark input (M02 §3): navy.700 fill, gold focus ring. */
export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, hint, id, className = '', ...rest },
  ref,
) {
  const inputId = id ?? rest.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="mb-1.5 block text-sm font-bold text-ink/80">
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={inputId}
        className={`w-full rounded-xl border bg-navy-700/60 px-3.5 py-2.5 text-ink placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-gold-400/30 ${
          error ? 'border-danger-500/60 focus:border-danger-500' : 'border-white/10 focus:border-gold-400'
        } ${className}`}
        aria-invalid={error ? true : undefined}
        {...rest}
      />
      {error && <p className="mt-1.5 text-xs font-semibold text-danger-400">{error}</p>}
      {!error && hint && <p className="mt-1.5 text-xs text-ink/50">{hint}</p>}
    </div>
  );
});
