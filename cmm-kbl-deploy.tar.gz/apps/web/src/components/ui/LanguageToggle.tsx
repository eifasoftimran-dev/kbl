import type { Language } from '@cmm/shared';
import { useTranslation } from 'react-i18next';
import { useUiStore } from '../../stores/ui';

/** hi / EN pill switch (M10.1) — instant, no reload. */
export function LanguageToggle() {
  const { i18n } = useTranslation();
  const setLang = useUiStore((s) => s.setLang);

  const choose = (lang: Language): void => {
    void i18n.changeLanguage(lang);
    setLang(lang);
  };

  const current = (i18n.resolvedLanguage ?? i18n.language ?? 'hi') as Language;

  return (
    <div
      role="group"
      aria-label={i18n.t('common:language')}
      className="inline-flex items-center rounded-full border border-white/10 bg-navy-800/60 p-0.5 text-xs font-bold"
    >
      {(['hi', 'en'] as const).map((lang) => (
        <button
          key={lang}
          type="button"
          onClick={() => choose(lang)}
          aria-pressed={current === lang}
          className={`rounded-full px-3 py-1 transition-colors ${
            current === lang ? 'bg-gold-400 text-navy-900' : 'text-ink/70 hover:text-ink'
          }`}
        >
          {lang === 'hi' ? 'हिं' : 'EN'}
        </button>
      ))}
    </div>
  );
}
