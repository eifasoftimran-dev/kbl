import { AlertTriangle } from 'lucide-react';
import { Modal } from './Modal';
import { GlowButton } from './GlowButton';

interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  /** default 'danger' */
  variant?: 'danger' | 'gold' | 'blue';
  loading?: boolean;
}

/** Confirmation modal for destructive / irreversible actions (M08 §4). */
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'Confirm',
  variant = 'danger',
  loading = false,
}: ConfirmDialogProps) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm">
      <div className="flex items-start gap-3 py-2">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-warning-400" aria-hidden />
        <p className="text-sm text-ink/80">{message}</p>
      </div>
      <div className="mt-5 flex justify-end gap-3">
        <GlowButton variant="ghost" size="sm" onClick={onClose} disabled={loading}>
          Cancel
        </GlowButton>
        <GlowButton variant={variant} size="sm" onClick={onConfirm} loading={loading}>
          {confirmLabel}
        </GlowButton>
      </div>
    </Modal>
  );
}
