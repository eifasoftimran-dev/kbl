import { forwardRef, type SelectHTMLAttributes } from 'react';

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  /** first disabled option acting as placeholder */
  placeholder?: string;
}

/** Dark select dropdown matching the Input style. */
export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select(
  { label, error, placeholder, id, className = '', children, ...rest },
  ref,
) {
  const selectId = id ?? rest.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={selectId} className="mb-1.5 block text-sm font-bold text-ink/80">
          {label}
        </label>
      )}
      <select
        ref={ref}
        id={selectId}
        className={`w-full rounded-xl border bg-navy-700/60 px-3.5 py-2.5 text-ink focus:outline-none focus:ring-2 focus:ring-gold-400/30 ${
          error ? 'border-danger-500/60 focus:border-danger-500' : 'border-white/10 focus:border-gold-400'
        } ${className}`}
        aria-invalid={error ? true : undefined}
        {...rest}
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {children}
      </select>
      {error && <p className="mt-1.5 text-xs font-semibold text-danger-400">{error}</p>}
    </div>
  );
});
