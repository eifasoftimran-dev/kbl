import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Loader2 } from 'lucide-react';

export type GlowVariant = 'gold' | 'blue' | 'violet' | 'danger' | 'ghost';
export type GlowSize = 'sm' | 'md' | 'lg' | 'xl';

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: GlowVariant;
  size?: GlowSize;
  /** shows a spinner and disables interaction */
  loading?: boolean;
  icon?: ReactNode;
  children?: ReactNode;
}

const VARIANT_CLASSES: Record<GlowVariant, string> = {
  gold: 'bg-gradient-to-b from-gold-300 to-gold-400 text-navy-900 hover:shadow-glow-gold',
  blue: 'bg-gradient-to-b from-electric-400 to-electric-500 text-white hover:shadow-glow-blue',
  violet: 'bg-gradient-to-b from-violet-400 to-violet-500 text-white hover:shadow-glow-blue',
  danger: 'bg-gradient-to-b from-danger-400 to-danger-500 text-white hover:shadow-glow-red',
  ghost: 'border border-white/15 text-ink hover:bg-white/5',
};

const SIZE_CLASSES: Record<GlowSize, string> = {
  sm: 'h-9 px-3.5 text-sm gap-1.5',
  md: 'h-10 px-4 text-sm gap-2',
  lg: 'h-12 px-6 text-base gap-2',
  xl: 'h-14 px-8 text-xl gap-3',
};

/** Primary action button (M02 §3): gradient fill + glow on hover. */
export function GlowButton({
  variant = 'gold',
  size = 'md',
  loading = false,
  icon,
  children,
  className = '',
  disabled,
  type = 'button',
  ...rest
}: GlowButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled ?? loading}
      className={`inline-flex items-center justify-center rounded-xl font-bold transition-all duration-200 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400 focus-visible:ring-offset-2 focus-visible:ring-offset-navy-900 disabled:pointer-events-none disabled:opacity-50 ${VARIANT_CLASSES[variant]} ${SIZE_CLASSES[size]} ${className}`}
      {...rest}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  );
}
