import type { ReactNode } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { GlassCard } from './GlassCard';
import { TableSkeleton } from './Skeleton';
import { GlowButton } from './GlowButton';

export interface Column<T> {
  key: string;
  header: string;
  /** custom cell renderer; default: `row[key]` */
  render?: (row: T) => ReactNode;
  /** tailwind width class e.g. 'w-20' */
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  /** row key extractor */
  rowKey: (row: T) => string;
  /** click handler for the entire row */
  onRowClick?: (row: T) => void;
  /** pagination */
  page?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;
  /** states */
  loading?: boolean;
  emptyMessage?: string;
  /** optional header action (e.g. "+ Add" button) */
  headerAction?: ReactNode;
  title?: string;
}

/** Paginated data table with skeleton + empty states (M02 §3, M08 §4). */
export function DataTable<T>({
  columns,
  data,
  rowKey,
  onRowClick,
  page = 1,
  totalPages = 1,
  onPageChange,
  loading = false,
  emptyMessage = 'No data found',
  headerAction,
  title,
}: DataTableProps<T>) {
  return (
    <GlassCard className="overflow-hidden">
      {/* header */}
      {(title || headerAction) && (
        <div className="flex items-center justify-between border-b border-white/5 px-5 py-3.5">
          {title && <h3 className="text-sm font-bold text-ink">{title}</h3>}
          <div className="ml-auto">{headerAction}</div>
        </div>
      )}

      {/* body */}
      {loading ? (
        <TableSkeleton rows={5} cols={columns.length} />
      ) : data.length === 0 ? (
        <div className="flex items-center justify-center py-12 text-sm text-ink/50">{emptyMessage}</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/5 text-xs font-bold uppercase tracking-wider text-ink/50">
                {columns.map((col) => (
                  <th key={col.key} className={`px-5 py-3 ${col.className ?? ''}`}>
                    {col.header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr
                  key={rowKey(row)}
                  onClick={() => onRowClick?.(row)}
                  className={`border-b border-white/5 transition-colors last:border-b-0 ${
                    onRowClick ? 'cursor-pointer hover:bg-white/5' : ''
                  }`}
                >
                  {columns.map((col) => (
                    <td key={col.key} className={`px-5 py-3 tabular-nums text-ink/90 ${col.className ?? ''}`}>
                      {col.render ? col.render(row) : (row as Record<string, unknown>)[col.key] as ReactNode}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* pagination */}
      {onPageChange && totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-white/5 px-5 py-3">
          <span className="text-xs text-ink/50">
            Page {page} of {totalPages}
          </span>
          <div className="flex gap-2">
            <GlowButton variant="ghost" size="sm" disabled={page <= 1} onClick={() => onPageChange(page - 1)}>
              <ChevronLeft className="h-4 w-4" aria-hidden />
            </GlowButton>
            <GlowButton
              variant="ghost"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => onPageChange(page + 1)}
            >
              <ChevronRight className="h-4 w-4" aria-hidden />
            </GlowButton>
          </div>
        </div>
      )}
    </GlassCard>
  );
}
