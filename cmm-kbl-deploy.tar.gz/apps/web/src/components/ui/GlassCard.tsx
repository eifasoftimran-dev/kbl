import type { HTMLAttributes } from 'react';

/** Base glassmorphic panel (M02 §3) — `.glass` recipe lives in index.css. */
export type GlassTone = 'gold' | 'blue' | 'plain';

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  tone?: GlassTone;
  /** hover lift + border brighten */
  interactive?: boolean;
}

export function GlassCard({ tone = 'plain', interactive = false, className = '', ...rest }: GlassCardProps) {
  const toneClass = tone === 'gold' ? 'glass--gold' : tone === 'blue' ? 'glass--blue' : '';
  return (
    <div
      className={`glass ${toneClass} ${interactive ? 'glass--int' : ''} ${className}`.trim()}
      {...rest}
    />
  );
}
