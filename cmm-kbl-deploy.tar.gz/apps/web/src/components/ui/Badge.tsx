import type { ReactNode } from 'react';

export type BadgeTone = 'success' | 'warning' | 'danger' | 'info' | 'gold';

const TONE_CLASSES: Record<BadgeTone, string> = {
  success: 'border-success-500/30 bg-success-500/15 text-success-400',
  warning: 'border-warning-500/30 bg-warning-500/15 text-warning-400',
  danger: 'border-danger-500/30 bg-danger-500/15 text-danger-400',
  info: 'border-electric-500/30 bg-electric-500/15 text-electric-400',
  gold: 'border-gold-400/30 bg-gold-400/15 text-gold-400',
};

/** Pill label (M02 §3): difficulty, LIVE, status. */
export function Badge({ tone = 'info', children }: { tone?: BadgeTone; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-bold ${TONE_CLASSES[tone]}`}
    >
      {children}
    </span>
  );
}

/** Difficulty → tone mapping (आसान success / मध्यम warning / कठिन danger — M02 §1). */
export const DIFFICULTY_TONE: Record<'easy' | 'medium' | 'hard', BadgeTone> = {
  easy: 'success',
  medium: 'warning',
  hard: 'danger',
};
