import { CheckCircle, AlertTriangle, XCircle, Info, X } from 'lucide-react';
import { useToastStore, type ToastTone } from '../../stores/toast';

const ICONS: Record<ToastTone, typeof CheckCircle> = {
  success: CheckCircle,
  warning: AlertTriangle,
  danger: XCircle,
  info: Info,
};

const TONE_CLASSES: Record<ToastTone, string> = {
  success: 'border-success-500/40 bg-success-500/15 text-success-400',
  warning: 'border-warning-500/40 bg-warning-500/15 text-warning-400',
  danger: 'border-danger-500/40 bg-danger-500/15 text-danger-400',
  info: 'border-electric-500/40 bg-electric-500/15 text-electric-400',
};

/** Global toast renderer — mount once in App root. */
export function Toaster() {
  const toasts = useToastStore((s) => s.toasts);
  const dismiss = useToastStore((s) => s.dismiss);

  if (toasts.length === 0) return null;

  return (
    <div className="pointer-events-none fixed right-4 top-4 z-toast flex w-80 flex-col gap-2">
      {toasts.map((t) => {
        const Icon = ICONS[t.tone];
        return (
          <div
            key={t.id}
            className={`pointer-events-auto flex items-start gap-3 rounded-xl border p-3.5 backdrop-blur-md animate-in slide-in-from-right ${TONE_CLASSES[t.tone]}`}
          >
            <Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            <p className="min-w-0 flex-1 text-sm font-semibold text-ink">{t.message}</p>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="shrink-0 rounded-lg p-0.5 text-ink/50 transition hover:bg-white/10 hover:text-ink"
            >
              <X className="h-3.5 w-3.5" aria-hidden />
            </button>
          </div>
        );
      })}
    </div>
  );
}
