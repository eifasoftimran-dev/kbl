import i18n from 'i18next';
import type { Resource } from 'i18next';
import { initReactI18next } from 'react-i18next';
import { I18N_RESOURCES } from '@cmm/shared';

/**
 * i18next bootstrap (M10.1) — bundles come from @cmm/shared so the server can
 * reuse them for exports. Hindi is primary; fallback chain: requested → hi →
 * `[missing] key` (visually obvious in dev).
 */
const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('lang') : null;

void i18n.use(initReactI18next).init({
  resources: I18N_RESOURCES as unknown as Resource,
  lng: stored === 'en' ? 'en' : 'hi',
  fallbackLng: 'hi',
  supportedLngs: ['hi', 'en'],
  defaultNS: 'common',
  ns: ['common', 'login', 'nav', 'admin', 'display', 'errors'],
  interpolation: { escapeValue: false },
  parseMissingKeyHandler: (key) => `[missing] ${key}`,
  returnNull: false,
});

export default i18n;
