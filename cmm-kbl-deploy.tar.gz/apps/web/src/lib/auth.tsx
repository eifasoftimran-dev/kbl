import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { UserPublic } from '@cmm/shared';
import { api, clearAccessToken, setAccessToken } from './api';

interface AuthContextValue {
  user: UserPublic | null;
  /** true while the initial /me rehydration is in flight (before routing) */
  booting: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

/** Auth session provider (M05): access token in storage + refresh cookie. */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserPublic | null>(null);
  const [booting, setBooting] = useState(true);

  // Rehydrate on first load — /me goes through the silent-refresh path.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const { user: me } = await api<{ user: UserPublic }>('/api/auth/me');
        if (!cancelled) setUser(me);
      } catch {
        clearAccessToken();
      } finally {
        if (!cancelled) setBooting(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const data = await api<{ user: UserPublic; accessToken: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setAccessToken(data.accessToken);
    setUser(data.user);
  }, []);

  const logout = useCallback(async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' });
    } catch {
      /* session already gone server-side */
    }
    clearAccessToken();
    setUser(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ user, booting, login, logout }),
    [user, booting, login, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
