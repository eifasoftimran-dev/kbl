import type { ApiFailure, ApiSuccess } from '@cmm/shared';

/**
 * Envelope-aware fetch client (M04 §2 + M05 §4).
 * - Bearer access token from storage; refresh cookie travels via credentials.
 * - On 401 (outside /login & /refresh) does a single-flight silent refresh + retry.
 */

const TOKEN_STORAGE_KEY = 'cmm.accessToken';

export function getAccessToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setAccessToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
  } catch {
    /* storage unavailable */
  }
}

export function clearAccessToken(): void {
  try {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  } catch {
    /* storage unavailable */
  }
}

/** Typed failure surfaced to callers (code → i18n error key in the UI). */
export class ApiClientError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details?: unknown;

  constructor(code: string, message: string, status: number, details?: unknown) {
    super(message);
    this.name = 'ApiClientError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

let refreshInFlight: Promise<string | null> | null = null;

/** Single-flight silent refresh using the httpOnly cookie. */
async function tryRefresh(): Promise<string | null> {
  if (!refreshInFlight) {
    refreshInFlight = fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
      .then(async (res) => {
        if (!res.ok) return null;
        const body = (await res.json().catch(() => null)) as ApiSuccess<{ accessToken: string }> | null;
        return body && body.ok ? body.data.accessToken : null;
      })
      .catch(() => null)
      .finally(() => {
        refreshInFlight = null;
      });
  }
  return refreshInFlight;
}

const NO_REFRESH_PATHS = ['/api/auth/login', '/api/auth/refresh'];

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const doFetch = (): Promise<Response> =>
    fetch(path, {
      ...init,
      credentials: 'include',
      headers: {
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...(getAccessToken() ? { Authorization: `Bearer ${getAccessToken()}` } : {}),
        ...(init.headers ?? {}),
      },
    });

  let res = await doFetch();

  if (res.status === 401 && !NO_REFRESH_PATHS.some((p) => path.startsWith(p))) {
    const fresh = await tryRefresh();
    if (fresh) {
      setAccessToken(fresh);
      res = await doFetch();
    }
  }

  const body = (await res.json().catch(() => null)) as ApiSuccess<T> | ApiFailure | null;
  if (body && body.ok) return body.data;

  const failure = body && !body.ok ? body.error : undefined;
  throw new ApiClientError(
    failure?.code ?? 'NETWORK',
    failure?.message ?? 'Could not reach the server',
    res.status,
    failure?.details,
  );
}
