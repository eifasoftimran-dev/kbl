/**
 * Screen B — LED display (M09). Full TV-stage rendering of the sanitized GameView.
 * Designed at fixed 1920×1080, scaled via useStageScaling — pixel-exact on any TV.
 */
import { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Maximize2 } from 'lucide-react';
import type { GameView, OptionKey } from '@cmm/shared';
import { useGameStore } from '../stores/game';
import { useSmoothRemainingMs, useKioskMode } from '../hooks/stage';
import { joinDisplaySession, onConnectionChange } from '../sockets/client';
import { LanguageToggle } from '../components/ui/LanguageToggle';
import { StageRoot, StageBackdrop } from '../components/display/StageRoot';
import { TimerRing, PrizeLadder } from '../components/display/TimerRing';
import { OptionCard, QuestionBox, LifelinesRow, type OptionVisualState } from '../components/display/OptionCard';
import { Podiums, FlowStrip } from '../components/display/Podiums';
import { RevealOverlay, GameOverFinale, BrandingScreen, PausedVeil } from '../components/display/RevealOverlay';
import { useStageEffects } from '../components/display/effects';

export default function DisplayPage() {
  const { code = '------' } = useParams<{ code: string }>();
  const [searchParams] = useSearchParams();
  const kiosk = searchParams.get('kiosk') === '1';

  const view = useGameStore((s) => s.view);
  const connected = useGameStore((s) => s.connected);
  const serverOffset = useGameStore((s) => s.serverOffset);
  const lastRevealEffect = useGameStore((s) => s.lastRevealEffect);
  const lastLifelineResult = useGameStore((s) => s.lastLifelineResult);
  const phase = view?.phase ?? 'idle';

  const [showBanner, setShowBanner] = useState(false);
  const [wasConnected, setWasConnected] = useState(false);

  useKioskMode(kiosk);

  // Join the display room by session code
  useEffect(() => {
    if (!code || code === '------') return;
    void joinDisplaySession(code.toUpperCase());
  }, [code]);

  // Connection banner (1.5s delay before showing — M06 §6)
  useEffect(() => {
    if (connected) {
      setWasConnected(true);
      setShowBanner(false);
      return;
    }
    if (!wasConnected) return; // not connected yet — normal
    const timer = setTimeout(() => setShowBanner(true), 1500);
    return () => clearTimeout(timer);
  }, [connected, wasConnected]);

  // Confetti + audio synced to phase transitions
  useStageEffects(phase, lastRevealEffect);

  // Smooth timer (rAF interpolation)
  const remainingMs = useSmoothRemainingMs(
    view?.timer?.endsAt,
    view?.timer?.remainingMs,
    serverOffset,
  );

  const slogans = view?.theme?.slogans;
  const isIdle = phase === 'idle';
  const isOver = phase === 'game_over';
  const showStage = view && !isIdle && !isOver;
  const pollDistribution =
    lastLifelineResult?.type === 'audience_poll' ? lastLifelineResult.distribution : null;

  return (
    <StageRoot>
      <StageBackdrop showReflection={view?.theme?.showHostIllustration ?? true} />

      {/* Connection banner — never blocks the show (M06 §6) */}
      {showBanner && (
        <div className="connection-banner">
          {code.toUpperCase()} — connection lost, reconnecting…
        </div>
      )}

      {/* Floating control cluster (non-kiosk) */}
      {!kiosk && (
        <div className="absolute right-6 top-6 z-toast flex items-center gap-3">
          <LanguageToggle />
          <FullscreenButton />
        </div>
      )}

      {/* Idle / branding screen */}
      {(!view || isIdle) && <BrandingScreen code={code} slogans={slogans} />}

      {/* Game over finale */}
      {isOver && view && <GameOverFinale view={view} />}

      {/* Live stage */}
      {showStage && view && <LiveStage view={view} remainingMs={remainingMs} pollDistribution={pollDistribution} />}

      {/* Paused veil */}
      {view?.paused && showStage && <PausedVeil />}

      {/* Reveal overlay (on top of the stage) */}
      {phase === 'answer_revealed' && view?.reveal && <RevealOverlay view={view} />}
    </StageRoot>
  );
}

// ---------------------------------------------------------------------------
// Live stage — the zone grid (M09 §3)
// ---------------------------------------------------------------------------

function LiveStage({
  view,
  remainingMs,
  pollDistribution,
}: {
  view: GameView;
  remainingMs: number | null;
  pollDistribution: Record<string, number> | null;
}) {
  const phase = view.phase;
  const isIntro = phase === 'question_intro';
  const isActive = phase === 'question_active';
  const isSelected = phase === 'answer_selected';
  const isLocked = phase === 'answer_locked';
  const isSuspense = phase === 'reveal_suspense';
  const isRevealed = phase === 'answer_revealed';

  const q = view.question;
  const timerActive = isActive || isSelected;

  return (
    <div
      className="absolute inset-0 grid p-[96px]"
      style={{
        gridTemplateRows: '90px 1fr 300px',
        gridTemplateColumns: '360px 1fr 240px',
        gridTemplateAreas: `
          "header header header"
          "host   center rail"
          "bottom bottom rail"
        `,
        gap: '24px',
      }}
    >
      {/* HEADER — slogans bar */}
      <header
        className="glass flex items-center justify-between px-6"
        style={{ gridArea: 'header' }}
      >
        {/* Logo mark */}
        <div className="flex h-12 w-12 items-center justify-center rounded-full border border-gold-400/50 shadow-glow-gold">
          <span className="font-display text-xl font-extrabold text-gold-400">?</span>
        </div>
        <span className="text-sm font-bold text-ink/60">{view.theme?.slogans?.topLeft}</span>
        <span className="font-display text-base font-bold text-gold-400/90">{view.theme?.slogans?.center}</span>
        <span className="text-sm font-bold text-ink/60">{view.theme?.slogans?.topRight}</span>
      </header>

      {/* HOST illustration (left, optional) */}
      {view.theme?.showHostIllustration && (
        <div className="flex items-center justify-center" style={{ gridArea: 'host' }}>
          <HostIllustration />
        </div>
      )}

      {/* CENTER — question + options + lifelines */}
      <main className="flex flex-col justify-center gap-6" style={{ gridArea: 'center' }}>
        {q && (
          <>
            <QuestionBox
              numberLabel={q.numberLabel}
              total={q.total}
              text={q.text}
              difficulty={q.difficulty}
              media={q.media}
              introPhase={isIntro}
            />

            {/* Options grid 2×2 — fade-stagger during intro */}
            {!isIntro && (
              <div className="grid grid-cols-2 gap-4">
                {q.options.map((opt, i) => (
                  <OptionCard
                    key={opt.key}
                    optKey={opt.key}
                    text={opt.text}
                    state={optionState(opt.key, view)}
                    enterDelay={i * 80}
                  />
                ))}
              </div>
            )}

            {/* Lifelines row + poll overlay */}
            {!isIntro && !isRevealed && (
              <LifelinesRow lifelines={view.lifelines} pollDistribution={pollDistribution} />
            )}
          </>
        )}
      </main>

      {/* RAIL — timer ring + prize ladder */}
      <aside className="flex flex-col items-center justify-center gap-8" style={{ gridArea: 'rail' }}>
        <TimerRing
          remainingMs={remainingMs}
          durationMs={view.timer?.durationMs ?? 30000}
          paused={view.paused}
          active={timerActive || isLocked}
        />
        <PrizeLadder levels={view.ladder.levels} currentLevel={view.ladder.currentLevel} />
      </aside>

      {/* BOTTOM — podiums + flow strip */}
      <footer className="flex items-end justify-between gap-8" style={{ gridArea: 'bottom' }}>
        <Podiums contestants={view.contestants} />
        <FlowStrip phase={phase} />
      </footer>
    </div>
  );
}

/** Map GameView fields → OptionCard visual state (M09 §4). */
function optionState(key: OptionKey, view: GameView): OptionVisualState {
  const phase = view.phase;
  const q = view.question;

  // 50:50 eliminated
  const opt = q?.options.find((o) => o.key === key);
  if (opt && !opt.visible) return 'eliminated';

  // Reveal states
  if (phase === 'answer_revealed' && view.reveal) {
    if (key === view.reveal.correctOption) return 'correct';
    if (key === view.lockedOption && !view.reveal.isCorrect) return 'wrong';
    return 'dimmed';
  }

  // Locked / suspense
  if (phase === 'reveal_suspense' || phase === 'answer_locked') {
    if (key === view.lockedOption) return phase === 'reveal_suspense' ? 'suspense' : 'locked';
    return 'dimmed';
  }

  // Selected
  if (phase === 'answer_selected') {
    if (key === view.selectedOption) return 'selected';
    return 'dimmed';
  }

  return 'default';
}

/** Static host illustration (M09 §3) — SVG with subtle sway. */
function HostIllustration() {
  return (
    <div className="host-sway relative flex h-[420px] w-[280px] items-end justify-center">
      <svg width="220" height="400" viewBox="0 0 220 400" fill="none" aria-hidden>
        {/* Mic stand */}
        <rect x="150" y="200" width="6" height="160" rx="3" fill="#1A2A5E" />
        <circle cx="153" cy="190" r="14" fill="#FFC93C" opacity="0.8" />
        <rect x="139" y="355" width="28" height="8" rx="4" fill="#1A2A5E" />

        {/* Host silhouette — stylized */}
        <ellipse cx="110" cy="120" rx="46" ry="52" fill="#101B4A" stroke="#FFC93C" strokeOpacity="0.3" strokeWidth="2" />
        {/* Mic in hand */}
        <circle cx="60" cy="180" r="10" fill="#FFC93C" opacity="0.9" />
        <rect x="56" y="188" width="8" height="60" rx="4" transform="rotate(-20 56 188)" fill="#1A2A5E" />
        {/* Body / suit */}
        <path d="M 60 170 Q 110 140 160 170 L 175 360 Q 110 380 45 360 Z" fill="#101B4A" stroke="#4C7DFF" strokeOpacity="0.35" strokeWidth="2" />
        {/* Tie */}
        <path d="M 110 175 L 98 230 L 110 320 L 122 230 Z" fill="#7B2FF7" opacity="0.8" />
        {/* Glowing outline accents */}
        <circle cx="110" cy="120" r="58" stroke="#FFC93C" strokeOpacity="0.15" strokeWidth="8" fill="none" />
      </svg>
    </div>
  );
}

/** Fullscreen toggle button (non-kiosk). */
function FullscreenButton() {
  const { t } = useTranslation('display');
  return (
    <button
      type="button"
      onClick={() => {
        if (document.fullscreenElement) void document.exitFullscreen();
        else void document.documentElement.requestFullscreen().catch(() => undefined);
      }}
      className="glass flex h-9 w-9 items-center justify-center rounded-full text-ink/60 transition-colors hover:text-gold-400"
      title={t('branding.fullscreen')}
    >
      <Maximize2 className="h-4 w-4" aria-hidden />
    </button>
  );
}
