/**
 * Operator Cockpit — admin control panel for running the game (M07/M09).
 * Shows current game state and provides control buttons.
 */
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { GameView, OptionKey, SessionSummaryDTO, Paginated, LifelineType } from '@cmm/shared';
import { CLIENT_EVENTS } from '@cmm/shared';
import { api } from '../../../lib/api';
import { GlassCard } from '../../../components/ui/GlassCard';
import { GlowButton } from '../../../components/ui/GlowButton';
import { Select } from '../../../components/ui/Select';
import { Badge } from '../../../components/ui/Badge';
import { useGameStore, useRemainingMs, usePhase } from '../../../stores/game';
import { joinAdminSession, leaveSession, isConnected, emitControl } from '../../../sockets/client';
import { useToast } from '../../../stores/toast';

export default function OperatorCockpitPage() {
  const { t } = useTranslation(['admin', 'common']);
  const toast = useToast();
  const [sessions, setSessions] = useState<SessionSummaryDTO[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [joining, setJoining] = useState(false);

  const view = useGameStore((s) => s.view);
  const connected = useGameStore((s) => s.connected);
  const setSessionId = useGameStore((s) => s.setSessionId);

  // Load available sessions
  useEffect(() => {
    api<Paginated<SessionSummaryDTO>>('/api/sessions?limit=50')
      .then((d) => {
        setSessions(d.items);
        if (d.items.length > 0 && !selectedId) {
          // Auto-select first live session or first session
          const live = d.items.find((s) => s.status === 'live' || s.status === 'draft');
          if (live) setSelectedId(live.id);
        }
      })
      .catch(() => toast.error(t('admin:errors.network')));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleJoin = useCallback(async () => {
    if (!selectedId) return;
    setJoining(true);
    try {
      const ack = await joinAdminSession(selectedId);
      if (ack.ok) {
        setSessionId(selectedId);
        toast.success('Connected to session');
      } else {
        toast.error(ack.error.message);
      }
    } catch {
      toast.error('Failed to connect');
    } finally {
      setJoining(false);
    }
  }, [selectedId, setSessionId, toast]);

  const handleLeave = useCallback(() => {
    leaveSession();
    setSessionId(null);
  }, [setSessionId]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('admin:operator.title')}</h1>
          <p className="text-sm text-ink/50">{t('admin:operator.subtitle')}</p>
        </div>
        <div className="flex items-center gap-3">
          <ConnectionBadge connected={connected} />
          <Select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="w-56">
            <option value="">{t('admin:operator.selectSession')}</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.code}) — {s.status}
              </option>
            ))}
          </Select>
          {view ? (
            <GlowButton variant="ghost" size="sm" onClick={handleLeave}>
              {t('admin:operator.leave')}
            </GlowButton>
          ) : (
            <GlowButton size="sm" loading={joining} onClick={handleJoin}>
              {t('admin:operator.join')}
            </GlowButton>
          )}
        </div>
      </div>

      {view ? (
        <GameControlPanel view={view} />
      ) : (
        <GlassCard className="flex min-h-[400px] items-center justify-center">
          <p className="text-ink/50">{t('admin:operator.noSession')}</p>
        </GlassCard>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Connection badge
// ---------------------------------------------------------------------------

function ConnectionBadge({ connected }: { connected: boolean }) {
  return (
    <div className={`flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold ${connected ? 'bg-success-500/15 text-success-400' : 'bg-danger-500/15 text-danger-400'}`}>
      <span className={`h-2 w-2 rounded-full ${connected ? 'bg-success-400 animate-pulse' : 'bg-danger-400'}`} />
      {connected ? 'LIVE' : 'OFFLINE'}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Game control panel
// ---------------------------------------------------------------------------

function GameControlPanel({ view }: { view: GameView }) {
  const { t } = useTranslation('admin');
  const phase = usePhase();
  const remainingMs = useRemainingMs();
  const store = useGameStore();

  const isIdle = phase === 'idle';
  const isIntro = phase === 'question_intro';
  const isActive = phase === 'question_active';
  const isSelected = phase === 'answer_selected';
  const isLocked = phase === 'answer_locked';
  const isSuspense = phase === 'reveal_suspense';
  const isRevealed = phase === 'answer_revealed';
  const isOver = phase === 'game_over';
  const isPaused = view.paused;

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      {/* Main control area */}
      <div className="space-y-5 lg:col-span-2">
        {/* Phase + Timer */}
        <GlassCard className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <PhaseIndicator phase={phase} paused={isPaused} />
              {view.question && (
                <p className="mt-1 text-sm text-ink/60">
                  {t('operator.question')} {view.question.index + 1} / {view.question.total}
                  {' — '}
                  <span className="capitalize">{view.question.difficulty}</span>
                </p>
              )}
            </div>
            {remainingMs != null && (
              <TimerDisplay remainingMs={remainingMs} />
            )}
          </div>
        </GlassCard>

        {/* Question text + options */}
        {view.question && (
          <GlassCard className="p-6 space-y-4">
            <h3 className="text-lg font-bold text-ink">{view.question.text}</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              {view.question.options.map((opt) => (
                <OptionButton
                  key={opt.key}
                  optKey={opt.key}
                  text={opt.text}
                  visible={opt.visible}
                  selected={view.selectedOption === opt.key}
                  locked={view.lockedOption === opt.key}
                  correct={isRevealed && view.reveal?.correctOption === opt.key}
                  wrong={isRevealed && view.lockedOption === opt.key && !view.reveal?.isCorrect}
                  disabled={!isActive && !isSelected}
                  onSelect={() => store.selectOption(opt.key)}
                />
              ))}
            </div>
          </GlassCard>
        )}

        {/* Control buttons */}
        <GlassCard className="p-6">
          <div className="flex flex-wrap gap-3">
            {isIdle && (
              <GlowButton size="sm" onClick={() => store.start()}>
                {t('operator.controls.start')}
              </GlowButton>
            )}
            {(isIntro || isActive || isSelected) && !isPaused && (
              <GlowButton size="sm" variant="ghost" onClick={() => store.pause()}>
                {t('operator.controls.pause')}
              </GlowButton>
            )}
            {isPaused && (
              <GlowButton size="sm" onClick={() => store.resume()}>
                {t('operator.controls.resume')}
              </GlowButton>
            )}
            {(isActive || isSelected) && (
              <GlowButton size="sm" onClick={() => store.lock()}>
                {t('operator.controls.lock')}
              </GlowButton>
            )}
            {(isLocked || isActive || isSelected) && (
              <GlowButton size="sm" onClick={() => store.reveal()}>
                {t('operator.controls.reveal')}
              </GlowButton>
            )}
            {isRevealed && (
              <GlowButton size="sm" onClick={() => store.next()}>
                {t('operator.controls.next')}
              </GlowButton>
            )}
            {!isIdle && !isOver && (
              <GlowButton size="sm" variant="danger" onClick={() => store.end()}>
                {t('operator.controls.end')}
              </GlowButton>
            )}
            {!isIdle && (
              <GlowButton size="sm" variant="ghost" onClick={() => store.reset()}>
                {t('operator.controls.reset')}
              </GlowButton>
            )}
          </div>
        </GlassCard>

        {/* Lifelines */}
        {view.activeContestant && (isActive || isSelected) && (
          <GlassCard className="p-6">
            <h4 className="mb-3 text-sm font-bold uppercase text-ink/50">{t('operator.lifelines')}</h4>
            <div className="flex gap-3">
              <LifelineButton
                label="50:50"
                count={view.lifelines.fifty_fifty}
                onUse={() => store.useLifeline('fifty_fifty')}
              />
              <LifelineButton
                label={t('operator.audiencePoll')}
                count={view.lifelines.audience_poll}
                onUse={() => store.useLifeline('audience_poll')}
              />
              <LifelineButton
                label={t('operator.expertCall')}
                count={view.lifelines.expert_call}
                onUse={() => store.useLifeline('expert_call')}
              />
            </div>
          </GlassCard>
        )}
      </div>

      {/* Sidebar — contestants + ladder */}
      <div className="space-y-5">
        {/* Active contestant */}
        {view.activeContestant && (
          <GlassCard className="p-4">
            <p className="text-xs font-bold uppercase text-ink/50">{t('operator.activeContestant')}</p>
            <p className="mt-1 text-lg font-bold text-gold-400">{view.activeContestant.name}</p>
          </GlassCard>
        )}

        {/* Contestants */}
        <GlassCard className="p-4 space-y-2">
          <p className="text-xs font-bold uppercase text-ink/50">{t('operator.contestants')}</p>
          {view.contestants.map((c) => (
            <div
              key={c.id}
              className={`flex items-center justify-between rounded-lg px-3 py-2 ${c.isActive ? 'bg-electric-500/10 ring-1 ring-electric-500/30' : 'bg-navy-800/40'}`}
            >
              <span className={`text-sm font-semibold ${c.isActive ? 'text-electric-400' : 'text-ink/70'}`}>
                {c.name}
              </span>
              <span className="tabular-nums text-sm font-bold text-gold-400">{c.score.toLocaleString()}</span>
            </div>
          ))}
        </GlassCard>

        {/* Ladder */}
        <GlassCard className="p-4">
          <p className="mb-2 text-xs font-bold uppercase text-ink/50">{t('operator.ladder')}</p>
          <div className="max-h-[300px] overflow-y-auto">
            {[...view.ladder.levels].reverse().map((l) => (
              <div
                key={l.level}
                className={`flex items-center justify-between rounded px-2 py-1 text-xs ${
                  l.level === view.ladder.currentLevel
                    ? 'bg-gold-400/15 font-bold text-gold-400'
                    : l.isSafeHaven
                      ? 'text-gold-400/60'
                      : 'text-ink/50'
                }`}
              >
                <span>{l.level}</span>
                <span className="tabular-nums">₹{l.amount.toLocaleString()}</span>
                {l.isSafeHaven && <span className="text-gold-400">★</span>}
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

const PHASE_LABELS: Record<string, string> = {
  idle: 'Idle',
  lobby: 'Lobby',
  question_intro: 'Question Intro',
  question_active: 'Question Active',
  answer_selected: 'Answer Selected',
  answer_locked: 'Answer Locked',
  reveal_suspense: 'Reveal Suspense',
  answer_revealed: 'Answer Revealed',
  game_over: 'Game Over',
};

function PhaseIndicator({ phase, paused }: { phase: string; paused: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className="font-display text-xl font-extrabold text-ink">
        {PHASE_LABELS[phase] ?? phase}
      </span>
      {paused && <Badge tone="warning">PAUSED</Badge>}
    </div>
  );
}

function TimerDisplay({ remainingMs }: { remainingMs: number }) {
  const seconds = Math.ceil(remainingMs / 1000);
  const isLow = seconds <= 10;
  return (
    <div className={`font-mono text-4xl font-extrabold tabular-nums ${isLow ? 'text-danger-400 animate-pulse' : 'text-ink'}`}>
      {seconds}s
    </div>
  );
}

function OptionButton({
  optKey,
  text,
  visible,
  selected,
  locked,
  correct,
  wrong,
  disabled,
  onSelect,
}: {
  optKey: OptionKey;
  text: string;
  visible: boolean;
  selected: boolean;
  locked: boolean;
  correct: boolean;
  wrong: boolean;
  disabled: boolean;
  onSelect: () => void;
}) {
  if (!visible) {
    return (
      <div className="rounded-xl border border-white/5 bg-navy-900/40 p-4 opacity-30">
        <span className="text-sm text-ink/30 line-through">{optKey}: {text}</span>
      </div>
    );
  }

  let ringClass = 'ring-white/5';
  if (correct) ringClass = 'ring-success-400 bg-success-500/10';
  else if (wrong) ringClass = 'ring-danger-400 bg-danger-500/10';
  else if (locked) ringClass = 'ring-gold-400 bg-gold-400/10';
  else if (selected) ringClass = 'ring-electric-400 bg-electric-500/10';

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onSelect}
      className={`rounded-xl border border-white/5 p-4 text-left ring-1 transition-all ${ringClass} ${disabled ? 'cursor-default' : 'cursor-pointer hover:bg-white/5'}`}
    >
      <span className="mr-2 font-bold text-electric-400">{optKey}</span>
      <span className="text-sm text-ink">{text}</span>
    </button>
  );
}

function LifelineButton({ label, count, onUse }: { label: string; count: number; onUse: () => void }) {
  const exhausted = count <= 0;
  return (
    <button
      type="button"
      disabled={exhausted}
      onClick={onUse}
      className={`rounded-xl border border-white/10 px-4 py-3 text-sm font-bold transition-all ${
        exhausted
          ? 'cursor-not-allowed bg-navy-900/40 text-ink/30'
          : 'bg-navy-800/60 text-ink hover:bg-electric-500/10 hover:text-electric-400 hover:ring-1 hover:ring-electric-500/30'
      }`}
    >
      {label}
      <span className="ml-2 text-xs opacity-60">×{count}</span>
    </button>
  );
}
