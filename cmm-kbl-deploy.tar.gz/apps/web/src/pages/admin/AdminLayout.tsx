import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  BarChart3,
  LayoutDashboard,
  LibraryBig,
  LogOut,
  MonitorPlay,
  Palette,
  PlayCircle,
  ShieldCheck,
  Trophy,
  Users,
  type LucideIcon,
} from 'lucide-react';
import type { Permission } from '@cmm/shared';
import { roleHasPermission } from '@cmm/shared';
import { useAuth } from '../../lib/auth';
import { Badge } from '../../components/ui/Badge';
import { LanguageToggle } from '../../components/ui/LanguageToggle';

interface NavItem {
  to: string;
  labelKey: string;
  icon: LucideIcon;
  permission: Permission;
  /** exact match for /admin (index route) */
  end?: boolean;
}

/** Sidebar nav (M08 §3) — visibility gated by the shared permission matrix. */
const NAV_ITEMS: NavItem[] = [
  { to: '/admin', labelKey: 'nav:dashboard', icon: LayoutDashboard, permission: 'dashboard.view', end: true },
  { to: '/admin/questions', labelKey: 'nav:questionBank', icon: LibraryBig, permission: 'questions.read' },
  { to: '/admin/contestants', labelKey: 'nav:contestants', icon: Users, permission: 'contestants.read' },
  { to: '/admin/sessions', labelKey: 'nav:gameSession', icon: PlayCircle, permission: 'sessions.read' },
  { to: '/admin/display', labelKey: 'nav:ledControl', icon: MonitorPlay, permission: 'led.control' },
  { to: '/admin/reports', labelKey: 'nav:reports', icon: BarChart3, permission: 'reports.read' },
  { to: '/admin/users', labelKey: 'nav:users', icon: ShieldCheck, permission: 'users.manage' },
  { to: '/admin/settings', labelKey: 'nav:branding', icon: Palette, permission: 'settings.write' },
];

const ROLE_TONE: Record<string, 'gold' | 'info' | 'warning' | 'success'> = {
  super_admin: 'gold',
  operator: 'info',
  host: 'warning',
  question_editor: 'success',
};

/** Screen A shell (M08 §3): permission-aware sidebar + topbar + routed content. */
export default function AdminLayout() {
  const { t } = useTranslation(['nav', 'common']);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const visibleItems = NAV_ITEMS.filter((item) => roleHasPermission(user.role, item.permission));

  async function onLogout(): Promise<void> {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <div className="stage-bg flex min-h-screen">
      {/* Sidebar */}
      <aside className="flex w-60 shrink-0 flex-col border-r border-white/5 bg-navy-900/80 backdrop-blur-md">
        <div className="flex items-center gap-3 border-b border-white/5 px-5 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/40 bg-gradient-to-b from-gold-300/20 to-transparent">
            <Trophy className="h-5 w-5 text-gold-400" aria-hidden />
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-extrabold text-ink">{t('common:appName')}</p>
            <p className="truncate text-[11px] text-ink/50">{t('common:brandLine')}</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label={t('nav:dashboard')}>
          {visibleItems.map(({ to, labelKey, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-colors ${
                  isActive
                    ? 'border border-gold-400/30 bg-gold-400/10 text-gold-400 shadow-glow-gold'
                    : 'border border-transparent text-ink/70 hover:bg-white/5 hover:text-ink'
                }`
              }
            >
              <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden />
              <span className="truncate">{t(labelKey)}</span>
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-white/5 p-3">
          <button
            type="button"
            onClick={() => void onLogout()}
            className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-ink/60 transition-colors hover:bg-danger-500/10 hover:text-danger-400"
          >
            <LogOut className="h-[18px] w-[18px] shrink-0" aria-hidden />
            {t('common:logout')}
          </button>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center justify-between border-b border-white/5 bg-navy-900/60 px-6 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <p className="font-display text-lg font-bold text-ink">{t('nav:dashboard')}</p>
          </div>
          <div className="flex items-center gap-4">
            <LanguageToggle />
            <div className="flex items-center gap-2.5 border-l border-white/10 pl-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-b from-electric-400 to-electric-500 text-xs font-extrabold text-white">
                {user.name.slice(0, 1).toUpperCase()}
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-bold leading-tight text-ink">{user.name}</p>
                <Badge tone={ROLE_TONE[user.role] ?? 'info'}>{t(`common:roles.${user.role}`)}</Badge>
              </div>
            </div>
          </div>
        </header>

        <main className="min-h-0 flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
