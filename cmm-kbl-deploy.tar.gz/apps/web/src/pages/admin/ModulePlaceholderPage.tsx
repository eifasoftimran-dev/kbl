import { useTranslation } from 'react-i18next';
import { Hourglass } from 'lucide-react';
import { GlassCard } from '../../components/ui/GlassCard';

/** Interim route for modules not yet implemented (P1+ per docs/plans). */
export default function ModulePlaceholderPage({ labelKey }: { labelKey: string }) {
  const { t } = useTranslation(['admin', 'nav']);

  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <GlassCard className="max-w-md p-10 text-center">
        <Hourglass className="mx-auto mb-4 h-10 w-10 text-gold-400/70" aria-hidden />
        <h1 className="font-display text-xl font-extrabold text-ink">
          {t('admin:placeholder.title', { module: t(labelKey) })}
        </h1>
        <p className="mt-2 text-sm text-ink/60">{t('admin:placeholder.body')}</p>
      </GlassCard>
    </div>
  );
}
