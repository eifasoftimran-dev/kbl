import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { DashboardStatsDTO, LadderLevel, ThemeSettingsDTO } from '@cmm/shared';
import { api } from '../../lib/api';
import { GlassCard } from '../../components/ui/GlassCard';
import { GlowButton } from '../../components/ui/GlowButton';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Skeleton } from '../../components/ui/Skeleton';
import { useToast } from '../../stores/toast';

type Tab = 'timer' | 'lifelines' | 'theme' | 'ladder';

export default function SettingsPage() {
  const { t } = useTranslation('admin');
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('timer');

  const tabs: { key: Tab; label: string }[] = [
    { key: 'timer', label: t('settings.timerTab') },
    { key: 'lifelines', label: t('settings.lifelinesTab') },
    { key: 'theme', label: t('settings.themeTab') },
    { key: 'ladder', label: t('settings.ladderTab') },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl font-extrabold text-ink">{t('settings.title')}</h1>
        <p className="text-sm text-ink/50">{t('settings.subtitle')}</p>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 rounded-xl border border-white/5 bg-navy-900/60 p-1">
        {tabs.map(({ key, label }) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`flex-1 rounded-lg px-4 py-2 text-sm font-bold transition-colors ${
              tab === key ? 'bg-gold-400/15 text-gold-400 shadow-glow-gold' : 'text-ink/60 hover:text-ink'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'timer' && <TimerSettings />}
      {tab === 'lifelines' && <LifelineSettings />}
      {tab === 'theme' && <ThemeSettings />}
      {tab === 'ladder' && <LadderSettings />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Timer
// ---------------------------------------------------------------------------

function TimerSettings() {
  const { t } = useTranslation('admin');
  const toast = useToast();
  const [timer, setTimer] = useState({ easy: 30, medium: 30, hard: 45, max: 120 });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ timer: typeof timer }>('/api/settings/timer')
      .then((d) => setTimer(d.timer))
      .catch(() => toast.error(t('errors.network')))
      .finally(() => setLoading(false));
  }, [t, toast]);

  async function save() {
    setSaving(true);
    try {
      await api('/api/settings/timer', { method: 'PUT', body: JSON.stringify(timer) });
      toast.success(t('settings.saved'));
    } catch {
      toast.error(t('errors.network'));
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <GlassCard className="space-y-4 p-6"><Skeleton className="h-8 w-full" /><Skeleton className="h-8 w-full" /></GlassCard>;

  return (
    <GlassCard className="space-y-5 p-6">
      <p className="text-sm text-ink/60">{t('settings.timerNote')}</p>
      <div className="grid gap-4 sm:grid-cols-2">
        {(['easy', 'medium', 'hard', 'max'] as const).map((key) => (
          <Input
            key={key}
            type="number"
            label={t(`settings.timer.${key}`)}
            value={timer[key]}
            min={10}
            max={120}
            onChange={(e) => setTimer({ ...timer, [key]: Number(e.target.value) })}
          />
        ))}
      </div>
      <div className="flex justify-end">
        <GlowButton loading={saving} onClick={save}>{t('settings.save')}</GlowButton>
      </div>
    </GlassCard>
  );
}

// ---------------------------------------------------------------------------
// Lifelines
// ---------------------------------------------------------------------------

function LifelineSettings() {
  const { t } = useTranslation('admin');
  const toast = useToast();
  const [data, setData] = useState<{
    fiftyFifty: { enabled: boolean; perContestant: number };
    audiencePoll: { enabled: boolean; perContestant: number };
    expertCall: { enabled: boolean; perContestant: number; durationSeconds: number };
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ lifelines: typeof data }>('/api/settings/lifelines')
      .then((d) => setData(d.lifelines))
      .catch(() => toast.error(t('errors.network')))
      .finally(() => setLoading(false));
  }, [t, toast]);

  async function save() {
    if (!data) return;
    setSaving(true);
    try {
      await api('/api/settings/lifelines', { method: 'PUT', body: JSON.stringify(data) });
      toast.success(t('settings.saved'));
    } catch {
      toast.error(t('errors.network'));
    } finally {
      setSaving(false);
    }
  }

  if (loading || !data) return <GlassCard className="space-y-4 p-6"><Skeleton className="h-8 w-full" /></GlassCard>;

  const cards = [
    { key: 'fiftyFifty' as const, label: '50:50', hasDuration: false },
    { key: 'audiencePoll' as const, label: t('settings.audiencePoll'), hasDuration: false },
    { key: 'expertCall' as const, label: t('settings.expertCall'), hasDuration: true },
  ];

  return (
    <GlassCard className="space-y-5 p-6">
      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map(({ key, label, hasDuration }) => (
          <div key={key} className="rounded-xl border border-white/5 bg-navy-800/40 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-ink">{label}</span>
              <label className="relative inline-flex cursor-pointer items-center">
                <input
                  type="checkbox"
                  checked={data[key].enabled}
                  onChange={(e) => setData({ ...data, [key]: { ...data[key], enabled: e.target.checked } })}
                  className="peer sr-only"
                />
                <div className="h-5 w-9 rounded-full bg-navy-700 after:absolute after:left-[2px] after:top-[2px] after:h-4 after:w-4 after:rounded-full after:bg-ink/50 after:transition-all peer-checked:bg-electric-500 peer-checked:after:translate-x-full peer-checked:after:bg-white" />
              </label>
            </div>
            <Input
              type="number"
              label={t('settings.perContestant')}
              value={data[key].perContestant}
              min={0}
              max={10}
              onChange={(e) => setData({ ...data, [key]: { ...data[key], perContestant: Number(e.target.value) } })}
            />
            {hasDuration && 'durationSeconds' in data[key] && (
              <Input
                type="number"
                label={t('settings.duration')}
                value={(data[key] as { durationSeconds: number }).durationSeconds}
                min={10}
                max={120}
                onChange={(e) => setData({ ...data, [key]: { ...(data[key] as { enabled: boolean; perContestant: number; durationSeconds: number }), durationSeconds: Number(e.target.value) } })}
              />
            )}
          </div>
        ))}
      </div>
      <div className="flex justify-end">
        <GlowButton loading={saving} onClick={save}>{t('settings.save')}</GlowButton>
      </div>
    </GlassCard>
  );
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

function ThemeSettings() {
  const { t } = useTranslation('admin');
  const toast = useToast();
  const [theme, setTheme] = useState<ThemeSettingsDTO | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ theme: ThemeSettingsDTO }>('/api/settings/theme')
      .then((d) => setTheme(d.theme))
      .catch(() => toast.error(t('errors.network')))
      .finally(() => setLoading(false));
  }, [t, toast]);

  async function save() {
    if (!theme) return;
    setSaving(true);
    try {
      await api('/api/settings/theme', {
        method: 'PUT',
        body: JSON.stringify({
          brandPrimary: theme.brandPrimary,
          brandAccent: theme.brandAccent,
          ledLayout: theme.ledLayout,
          buzzerMode: theme.buzzerMode,
          defaultLanguage: theme.defaultLanguage,
          showHostIllustration: theme.showHostIllustration,
          showReflection: theme.showReflection,
          slogans: theme.slogans,
        }),
      });
      toast.success(t('settings.saved'));
    } catch {
      toast.error(t('errors.network'));
    } finally {
      setSaving(false);
    }
  }

  if (loading || !theme) return <GlassCard className="space-y-4 p-6"><Skeleton className="h-8 w-full" /></GlassCard>;

  return (
    <GlassCard className="space-y-5 p-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label={t('settings.brandPrimary')} type="color" value={theme.brandPrimary} onChange={(e) => setTheme({ ...theme, brandPrimary: e.target.value })} />
        <Input label={t('settings.brandAccent')} type="color" value={theme.brandAccent} onChange={(e) => setTheme({ ...theme, brandAccent: e.target.value })} />
        <Select label={t('settings.ledLayout')} value={theme.ledLayout} onChange={(e) => setTheme({ ...theme, ledLayout: e.target.value as ThemeSettingsDTO['ledLayout'] })}>
          <option value="classic">Classic</option>
          <option value="compact">Compact</option>
          <option value="wide">Wide</option>
        </Select>
        <Select label={t('settings.defaultLang')} value={theme.defaultLanguage} onChange={(e) => setTheme({ ...theme, defaultLanguage: e.target.value as ThemeSettingsDTO['defaultLanguage'] })}>
          <option value="hi">हिन्दी</option>
          <option value="en">English</option>
        </Select>
      </div>
      <div className="flex items-center gap-6">
        <label className="flex items-center gap-2 text-sm text-ink/80">
          <input type="checkbox" checked={theme.buzzerMode} onChange={(e) => setTheme({ ...theme, buzzerMode: e.target.checked })} className="rounded" />
          {t('settings.buzzerMode')}
        </label>
        <label className="flex items-center gap-2 text-sm text-ink/80">
          <input type="checkbox" checked={theme.showHostIllustration} onChange={(e) => setTheme({ ...theme, showHostIllustration: e.target.checked })} className="rounded" />
          {t('settings.hostIllustr')}
        </label>
        <label className="flex items-center gap-2 text-sm text-ink/80">
          <input type="checkbox" checked={theme.showReflection} onChange={(e) => setTheme({ ...theme, showReflection: e.target.checked })} className="rounded" />
          {t('settings.reflection')}
        </label>
      </div>
      <div className="flex justify-end">
        <GlowButton loading={saving} onClick={save}>{t('settings.save')}</GlowButton>
      </div>
    </GlassCard>
  );
}

// ---------------------------------------------------------------------------
// Ladder
// ---------------------------------------------------------------------------

function LadderSettings() {
  const { t } = useTranslation('admin');
  const toast = useToast();
  const [levels, setLevels] = useState<LadderLevel[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ levels: LadderLevel[] }>('/api/settings/ladder')
      .then((d) => setLevels(d.levels))
      .catch(() => toast.error(t('errors.network')))
      .finally(() => setLoading(false));
  }, [t, toast]);

  async function save() {
    if (!levels) return;
    setSaving(true);
    try {
      await api('/api/settings/ladder', { method: 'PUT', body: JSON.stringify({ levels }) });
      toast.success(t('settings.saved'));
    } catch {
      toast.error(t('errors.network'));
    } finally {
      setSaving(false);
    }
  }

  function updateLevel(idx: number, field: keyof LadderLevel, value: number | boolean) {
    if (!levels) return;
    const next = [...levels];
    next[idx] = { ...next[idx], [field]: value };
    setLevels(next);
  }

  if (loading || !levels) return <GlassCard className="space-y-4 p-6"><Skeleton className="h-8 w-full" /></GlassCard>;

  return (
    <GlassCard className="space-y-4 p-6">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-white/5 text-xs font-bold uppercase text-ink/50">
            <th className="py-2 w-16">{t('settings.level')}</th>
            <th className="py-2">{t('settings.amount')}</th>
            <th className="py-2 w-24">{t('settings.safeHaven')}</th>
          </tr>
        </thead>
        <tbody>
          {levels.map((l, i) => (
            <tr key={l.level} className="border-b border-white/5 last:border-b-0">
              <td className="py-2 font-mono text-xs text-ink/60">{l.level}</td>
              <td className="py-2">
                <Input
                  type="number"
                  value={l.amount}
                  min={0}
                  onChange={(e) => updateLevel(i, 'amount', Number(e.target.value))}
                  className="!py-1.5"
                />
              </td>
              <td className="py-2">
                <input
                  type="checkbox"
                  checked={l.isSafeHaven}
                  onChange={(e) => updateLevel(i, 'isSafeHaven', e.target.checked)}
                  className="h-4 w-4 rounded"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex justify-end">
        <GlowButton loading={saving} onClick={save}>{t('settings.save')}</GlowButton>
      </div>
    </GlassCard>
  );
}
