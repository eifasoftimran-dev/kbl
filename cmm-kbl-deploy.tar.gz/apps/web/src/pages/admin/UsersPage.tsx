import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Search } from 'lucide-react';
import type { Paginated, UserPublic } from '@cmm/shared';
import { api } from '../../lib/api';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { GlowButton } from '../../components/ui/GlowButton';
import { Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { Select } from '../../components/ui/Select';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../stores/toast';

const LIMIT = 20;
const ROLE_TONE: Record<string, BadgeTone> = {
  super_admin: 'gold', operator: 'info', host: 'warning', question_editor: 'success',
};
const ROLES = ['super_admin', 'operator', 'host', 'question_editor'] as const;

interface UserForm { name: string; email: string; password: string; role: string; }
const EMPTY: UserForm = { name: '', email: '', password: '', role: 'question_editor' };

export default function UsersPage() {
  const { t } = useTranslation(['admin', 'common']);
  const toast = useToast();

  const [data, setData] = useState<Paginated<UserPublic> | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');

  // modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<UserPublic | null>(null);
  const [form, setForm] = useState<UserForm>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // password reset
  const [resetTarget, setResetTarget] = useState<UserPublic | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [resetting, setResetting] = useState(false);

  // deactivate
  const [deactivateTarget, setDeactivateTarget] = useState<UserPublic | null>(null);
  const [deactivating, setDeactivating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) params.set('search', search);
      const result = await api<Paginated<UserPublic>>(`/api/users?${params}`);
      setData(result);
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setLoading(false);
    }
  }, [page, search, t, toast]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const id = setTimeout(() => { setSearch(searchInput); setPage(1); }, 300);
    return () => clearTimeout(id);
  }, [searchInput]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(u: UserPublic) {
    setEditing(u);
    setForm({ name: u.name, email: u.email, password: '', role: u.role });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave() {
    setSaving(true);
    setFormError('');
    try {
      if (editing) {
        const body: Record<string, string> = { name: form.name, email: form.email, role: form.role };
        await api(`/api/users/${editing.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        toast.success(t('admin:users.updated'));
      } else {
        await api('/api/users', { method: 'POST', body: JSON.stringify(form) });
        toast.success(t('admin:users.created'));
      }
      setModalOpen(false);
      await load();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : t('admin:errors.network'));
    } finally {
      setSaving(false);
    }
  }

  async function handleResetPassword() {
    if (!resetTarget || !newPassword) return;
    setResetting(true);
    try {
      await api(`/api/users/${resetTarget.id}/password`, {
        method: 'POST',
        body: JSON.stringify({ password: newPassword }),
      });
      toast.success(t('admin:users.passwordReset'));
      setResetTarget(null);
      setNewPassword('');
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setResetting(false);
    }
  }

  async function handleDeactivate() {
    if (!deactivateTarget) return;
    setDeactivating(true);
    try {
      await api(`/api/users/${deactivateTarget.id}/deactivate`, { method: 'POST' });
      toast.success(t('admin:users.deactivated'));
      setDeactivateTarget(null);
      await load();
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setDeactivating(false);
    }
  }

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  const columns: Column<UserPublic>[] = [
    { key: 'name', header: t('admin:users.name'), render: (u) => <span className="font-semibold text-ink">{u.name}</span> },
    { key: 'email', header: t('admin:users.email'), render: (u) => <span className="text-ink/70">{u.email}</span> },
    {
      key: 'role',
      header: t('admin:users.role'),
      className: 'w-36',
      render: (u) => <Badge tone={ROLE_TONE[u.role] ?? 'info'}>{t(`common:roles.${u.role}`)}</Badge>,
    },
    {
      key: 'isActive',
      header: t('admin:users.status'),
      className: 'w-24',
      render: (u) => (
        <span className={`text-xs font-bold ${u.isActive ? 'text-success-400' : 'text-danger-400'}`}>
          {u.isActive ? t('admin:users.active') : t('admin:users.inactive')}
        </span>
      ),
    },
    {
      key: 'lastLoginAt',
      header: t('admin:users.lastLogin'),
      className: 'w-32',
      render: (u) => (
        <span className="text-xs text-ink/50">
          {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleDateString() : '—'}
        </span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'w-36',
      render: (u) => (
        <div className="flex gap-2">
          <button type="button" onClick={(e) => { e.stopPropagation(); setResetTarget(u); }} className="text-xs font-bold text-electric-400 hover:text-electric-300">
            {t('admin:users.resetPw')}
          </button>
          {u.isActive && (
            <button type="button" onClick={(e) => { e.stopPropagation(); setDeactivateTarget(u); }} className="text-xs font-bold text-danger-400 hover:text-danger-300">
              {t('admin:users.deactivate')}
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('admin:users')}</h1>
          <p className="text-sm text-ink/50">{data ? `${data.total} ${t('admin:users.found')}` : '…'}</p>
        </div>
        <GlowButton icon={<Plus className="h-4 w-4" aria-hidden />} onClick={openCreate}>
          {t('admin:users.add')}
        </GlowButton>
      </div>

      <div className="relative min-w-[200px] max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
        <Input placeholder={t('admin:users.search')} value={searchInput} onChange={(e) => setSearchInput(e.target.value)} className="pl-9" />
      </div>

      <DataTable<UserPublic>
        columns={columns}
        data={data?.items ?? []}
        rowKey={(u) => u.id}
        onRowClick={openEdit}
        loading={loading}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
        emptyMessage={t('admin:users.empty')}
      />

      {/* Create / Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? t('admin:users.edit') : t('admin:users.add')} size="sm">
        <div className="space-y-4">
          <Input label={t('admin:users.name')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input label={t('admin:users.email')} type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          {!editing && (
            <Input label={t('admin:users.password')} type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          )}
          <Select label={t('admin:users.role')} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            {ROLES.map((r) => <option key={r} value={r}>{t(`common:roles.${r}`)}</option>)}
          </Select>
          {formError && <p className="text-xs font-semibold text-danger-400">{formError}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <GlowButton variant="ghost" size="sm" onClick={() => setModalOpen(false)}>{t('common:cancel')}</GlowButton>
            <GlowButton size="sm" loading={saving} onClick={handleSave}>{editing ? t('common:save') : t('common:create')}</GlowButton>
          </div>
        </div>
      </Modal>

      {/* Password reset modal */}
      <Modal open={!!resetTarget} onClose={() => { setResetTarget(null); setNewPassword(''); }} title={t('admin:users.resetPwTitle')} size="sm">
        <div className="space-y-4">
          <p className="text-sm text-ink/70">{t('admin:users.resetPwFor', { name: resetTarget?.name ?? '' })}</p>
          <Input label={t('admin:users.newPassword')} type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          <div className="flex justify-end gap-3 pt-2">
            <GlowButton variant="ghost" size="sm" onClick={() => { setResetTarget(null); setNewPassword(''); }}>{t('common:cancel')}</GlowButton>
            <GlowButton size="sm" loading={resetting} onClick={handleResetPassword}>{t('admin:users.resetPw')}</GlowButton>
          </div>
        </div>
      </Modal>

      {/* Deactivate confirm */}
      <ConfirmDialog
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={handleDeactivate}
        title={t('admin:users.confirmDeactivateTitle')}
        message={t('admin:users.confirmDeactivateMsg', { name: deactivateTarget?.name ?? '' })}
        confirmLabel={t('admin:users.deactivate')}
        loading={deactivating}
      />
    </div>
  );
}
