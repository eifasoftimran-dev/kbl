import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  LibraryBig,
  MonitorPlay,
  PlayCircle,
  ServerCog,
  Trophy,
  Users,
} from 'lucide-react';
import type { DashboardStatsDTO, SessionSummaryDTO } from '@cmm/shared';
import { api } from '../../lib/api';
import { useAuth } from '../../lib/auth';
import { GlassCard } from '../../components/ui/GlassCard';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { GlowButton } from '../../components/ui/GlowButton';
import { Skeleton } from '../../components/ui/Skeleton';

const STATUS_TONE: Record<string, BadgeTone> = {
  draft: 'info',
  live: 'danger',
  paused: 'warning',
  completed: 'success',
  cancelled: 'warning',
};

/** Real dashboard (M08 §3.1): stats from `/api/dashboard/stats` + recent sessions. */
export default function DashboardPage() {
  const { t } = useTranslation('admin');
  const { user } = useAuth();
  const navigate = useNavigate();

  const [stats, setStats] = useState<DashboardStatsDTO | null>(null);
  const [sessions, setSessions] = useState<SessionSummaryDTO[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [statsData, sessionsData] = await Promise.all([
        api<DashboardStatsDTO>('/api/dashboard/stats'),
        api<{ items: SessionSummaryDTO[]; total: number }>('/api/sessions?limit=5'),
      ]);
      setStats(statsData);
      setSessions(sessionsData.items);
    } catch {
      /* silent — skeleton stays or data remains stale */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const interval = setInterval(load, 15_000); // poll every 15s
    return () => clearInterval(interval);
  }, [load]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-extrabold text-ink">{t('dashboard.title')}</h1>
        <p className="mt-0.5 text-sm text-ink/60">
          {t('dashboard.welcome')}{user ? `, ${user.name}` : ''}
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Active Game */}
        <GlassCard tone="blue" className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-electric-500/30 bg-electric-500/10">
              <PlayCircle className="h-5 w-5 text-electric-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase text-ink/50">{t('dashboard.activeGame')}</p>
              {loading ? (
                <Skeleton className="mt-1 h-6 w-24" />
              ) : stats?.activeGame ? (
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-danger-400" />
                  <span className="text-sm font-bold text-ink truncate">{stats.activeGame.name}</span>
                </div>
              ) : (
                <p className="text-sm font-bold text-ink/50">{t('dashboard.noActiveGame')}</p>
              )}
            </div>
          </div>
        </GlassCard>

        {/* Total Questions */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-gold-400/30 bg-gold-400/10">
              <LibraryBig className="h-5 w-5 text-gold-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase text-ink/50">{t('dashboard.questions')}</p>
              {loading ? (
                <Skeleton className="mt-1 h-6 w-16" />
              ) : (
                <p className="text-xl font-extrabold tabular-nums text-ink">{stats?.totalQuestions ?? 0}</p>
              )}
            </div>
          </div>
        </GlassCard>

        {/* Contestants */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-violet-500/30 bg-violet-500/10">
              <Users className="h-5 w-5 text-violet-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase text-ink/50">{t('dashboard.contestants')}</p>
              {loading ? (
                <Skeleton className="mt-1 h-6 w-16" />
              ) : (
                <p className="text-xl font-extrabold tabular-nums text-ink">
                  {stats?.contestants.active ?? 0}
                  <span className="text-sm font-normal text-ink/40"> / {stats?.contestants.total ?? 0}</span>
                </p>
              )}
            </div>
          </div>
        </GlassCard>

        {/* Today's Sessions */}
        <GlassCard className="p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-success-500/30 bg-success-500/10">
              <Trophy className="h-5 w-5 text-success-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold uppercase text-ink/50">{t('dashboard.todaySessions')}</p>
              {loading ? (
                <Skeleton className="mt-1 h-6 w-20" />
              ) : (
                <p className="text-sm font-bold text-ink">
                  {stats?.todaySessions.live ?? 0} {t('dashboard.live')} · {stats?.todaySessions.completed ?? 0} {t('dashboard.done')}
                </p>
              )}
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Quick actions */}
      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">{t('dashboard.quickActions')}</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <GlassCard interactive className="flex items-center gap-4 p-5" onClick={() => navigate('/admin/questions')}>
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-gold-400/30 bg-gold-400/10">
              <LibraryBig className="h-5 w-5 text-gold-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-ink">{t('dashboard.manageQuestions')}</p>
              <p className="text-xs text-ink/50">{stats?.totalQuestions ?? 0} {t('dashboard.questions')}</p>
            </div>
          </GlassCard>
          <GlassCard interactive className="flex items-center gap-4 p-5" onClick={() => navigate('/admin/sessions')}>
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-electric-500/30 bg-electric-500/10">
              <PlayCircle className="h-5 w-5 text-electric-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-ink">{t('dashboard.openSession')}</p>
              <p className="text-xs text-ink/50">{t('dashboard.manageSessions')}</p>
            </div>
          </GlassCard>
          <GlassCard interactive className="flex items-center gap-4 p-5" onClick={() => window.open('/display/KBL202', '_blank')}>
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-violet-500/30 bg-violet-500/10">
              <MonitorPlay className="h-5 w-5 text-violet-400" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-ink">{t('dashboard.openDisplay')}</p>
              <p className="text-xs text-ink/50">LED Display ↗</p>
            </div>
          </GlassCard>
        </div>
      </section>

      {/* Recent sessions */}
      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">{t('dashboard.recentSessions')}</h2>
        {loading ? (
          <GlassCard className="space-y-3 p-5">
            {Array.from({ length: 3 }, (_, i) => <Skeleton key={i} className="h-8 w-full" />)}
          </GlassCard>
        ) : sessions.length === 0 ? (
          <GlassCard className="flex items-center justify-center gap-3 p-8 text-sm text-ink/50">
            <ServerCog className="h-4 w-4" aria-hidden />
            {t('dashboard.recentSessionsEmpty')}
          </GlassCard>
        ) : (
          <GlassCard className="overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-white/5 text-xs font-bold uppercase tracking-wider text-ink/50">
                  <th className="px-5 py-3">{t('dashboard.sessionName')}</th>
                  <th className="px-5 py-3 w-20">{t('dashboard.code')}</th>
                  <th className="px-5 py-3 w-24">{t('dashboard.status')}</th>
                  <th className="px-5 py-3 w-28">{t('dashboard.questions')}</th>
                </tr>
              </thead>
              <tbody>
                {sessions.map((s) => (
                  <tr
                    key={s.id}
                    className="cursor-pointer border-b border-white/5 transition-colors last:border-b-0 hover:bg-white/5"
                    onClick={() => navigate('/admin/sessions')}
                  >
                    <td className="px-5 py-3 font-semibold text-ink">{s.name}</td>
                    <td className="px-5 py-3 font-mono text-xs text-ink/70">{s.code}</td>
                    <td className="px-5 py-3">
                      <Badge tone={STATUS_TONE[s.status] ?? 'info'}>{s.status}</Badge>
                    </td>
                    <td className="px-5 py-3 tabular-nums text-ink/70">
                      {s.currentQuestionIndex + 1} / {s.totalQuestions}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </GlassCard>
        )}
      </section>

      {/* Server health */}
      <GlassCard tone="blue" className="flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <ServerCog className="h-4 w-4 text-electric-400" aria-hidden />
          <span className="text-xs font-bold text-ink/70">API</span>
        </div>
        <GlowButton variant="ghost" size="sm" onClick={() => void load()}>
          {t('dashboard.refresh')}
        </GlowButton>
      </GlassCard>
    </div>
  );
}
