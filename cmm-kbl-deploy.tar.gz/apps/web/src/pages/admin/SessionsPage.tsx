import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus } from 'lucide-react';
import type { Paginated, SessionSummaryDTO } from '@cmm/shared';
import { api } from '../../lib/api';
import { Badge, type BadgeTone } from '../../components/ui/Badge';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { GlowButton } from '../../components/ui/GlowButton';
import { Select } from '../../components/ui/Select';
import { useToast } from '../../stores/toast';

const LIMIT = 20;
const STATUS_TONE: Record<string, BadgeTone> = {
  draft: 'info', live: 'danger', paused: 'warning', completed: 'success', cancelled: 'warning',
};

export default function SessionsPage() {
  const { t } = useTranslation(['admin', 'common']);
  const toast = useToast();

  const [data, setData] = useState<Paginated<SessionSummaryDTO> | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (statusFilter) params.set('status', statusFilter);
      const result = await api<Paginated<SessionSummaryDTO>>(`/api/sessions?${params}`);
      setData(result);
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter, t, toast]);

  useEffect(() => { void load(); }, [load]);

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  const columns: Column<SessionSummaryDTO>[] = [
    {
      key: 'name',
      header: t('admin:sessions.name'),
      render: (s) => (
        <div>
          <span className="font-semibold text-ink">{s.name}</span>
          <span className="ml-2 font-mono text-xs text-ink/40">{s.code}</span>
        </div>
      ),
    },
    {
      key: 'status',
      header: t('admin:sessions.status'),
      className: 'w-28',
      render: (s) => <Badge tone={STATUS_TONE[s.status] ?? 'info'}>{s.status}</Badge>,
    },
    {
      key: 'progress',
      header: t('admin:sessions.progress'),
      className: 'w-28',
      render: (s) => (
        <span className="tabular-nums text-ink/70">
          {s.currentQuestionIndex + 1} / {s.totalQuestions}
        </span>
      ),
    },
    {
      key: 'contestants',
      header: t('admin:sessions.contestants'),
      className: 'w-24',
      render: (s) => <span className="tabular-nums text-ink/70">{s.contestantIds.length}</span>,
    },
    {
      key: 'startedAt',
      header: t('admin:sessions.started'),
      className: 'w-36',
      render: (s) => (
        <span className="text-xs text-ink/50">
          {s.startedAt ? new Date(s.startedAt).toLocaleDateString() : '—'}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('admin:gameSession')}</h1>
          <p className="text-sm text-ink/50">{data ? `${data.total} ${t('admin:sessions.found')}` : '…'}</p>
        </div>
        <GlowButton icon={<Plus className="h-4 w-4" aria-hidden />}>
          {t('admin:sessions.create')}
        </GlowButton>
      </div>

      {/* Filters */}
      <div className="flex items-end gap-3">
        <Select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }} className="w-36" placeholder={t('admin:sessions.allStatus')}>
          <option value="">{t('admin:sessions.allStatus')}</option>
          <option value="draft">{t('admin:sessions.draft')}</option>
          <option value="live">{t('admin:sessions.live')}</option>
          <option value="paused">{t('admin:sessions.paused')}</option>
          <option value="completed">{t('admin:sessions.completed')}</option>
        </Select>
      </div>

      <DataTable<SessionSummaryDTO>
        columns={columns}
        data={data?.items ?? []}
        rowKey={(s) => s.id}
        loading={loading}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
        emptyMessage={t('admin:sessions.empty')}
      />
    </div>
  );
}
