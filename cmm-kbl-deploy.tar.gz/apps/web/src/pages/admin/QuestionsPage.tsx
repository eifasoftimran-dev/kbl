import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Search } from 'lucide-react';
import type { CategoryDTO, Paginated, QuestionListItemDTO } from '@cmm/shared';
import { api } from '../../lib/api';
import { Badge, DIFFICULTY_TONE } from '../../components/ui/Badge';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { GlowButton } from '../../components/ui/GlowButton';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { useToast } from '../../stores/toast';

const LIMIT = 20;

export default function QuestionsPage() {
  const { t } = useTranslation(['admin', 'common']);
  const toast = useToast();

  const [data, setData] = useState<Paginated<QuestionListItemDTO> | null>(null);
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [status, setStatus] = useState('');
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) params.set('search', search);
      if (categoryId) params.set('categoryId', categoryId);
      if (difficulty) params.set('difficulty', difficulty);
      if (status) params.set('status', status);
      const result = await api<Paginated<QuestionListItemDTO>>(`/api/questions?${params}`);
      setData(result);
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setLoading(false);
    }
  }, [page, search, categoryId, difficulty, status, t, toast]);

  useEffect(() => {
    api<{ categories: CategoryDTO[] }>('/api/questions/categories')
      .then((d) => setCategories(d.categories))
      .catch(() => {});
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // debounced search
  const [searchInput, setSearchInput] = useState('');
  useEffect(() => {
    const id = setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 300);
    return () => clearTimeout(id);
  }, [searchInput]);

  async function toggleStatus(q: QuestionListItemDTO) {
    const next = q.status === 'active' ? 'inactive' : 'active';
    setTogglingId(q.id);
    try {
      await api(`/api/questions/${q.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: next }),
      });
      toast.success(next === 'active' ? 'Question activated' : 'Question deactivated');
      await load();
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setTogglingId(null);
    }
  }

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  const columns: Column<QuestionListItemDTO>[] = [
    { key: 'code', header: 'ID', className: 'w-20', render: (q) => <span className="font-mono text-xs">{q.code}</span> },
    {
      key: 'text',
      header: t('admin:questions.question'),
      render: (q) => <span className="line-clamp-1">{q.text}</span>,
    },
    {
      key: 'category',
      header: t('admin:questions.category'),
      className: 'w-36',
      render: (q) => (
        <span
          className="inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-bold"
          style={{ borderColor: `${q.category.color}40`, color: q.category.color }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: q.category.color }} />
          {q.category.name}
        </span>
      ),
    },
    {
      key: 'difficulty',
      header: t('admin:questions.difficulty'),
      className: 'w-24',
      render: (q) => <Badge tone={DIFFICULTY_TONE[q.difficulty]}>{q.difficulty}</Badge>,
    },
    {
      key: 'timerSeconds',
      header: t('admin:questions.timer'),
      className: 'w-16',
      render: (q) => <span className="tabular-nums text-ink/70">{q.timerSeconds}s</span>,
    },
    {
      key: 'status',
      header: t('admin:questions.status'),
      className: 'w-24',
      render: (q) => (
        <button
          type="button"
          disabled={togglingId === q.id}
          onClick={(e) => { e.stopPropagation(); void toggleStatus(q); }}
          className="flex items-center gap-1.5 text-xs font-bold disabled:opacity-50"
        >
          <span className={`h-2 w-2 rounded-full ${q.status === 'active' ? 'bg-success-400' : 'bg-ink/30'}`} />
          <span className={q.status === 'active' ? 'text-success-400' : 'text-ink/50'}>{q.status}</span>
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('admin:questionBank')}</h1>
          <p className="text-sm text-ink/50">{data ? `${data.total} ${t('admin:questions.found')}` : '…'}</p>
        </div>
        <GlowButton icon={<Plus className="h-4 w-4" aria-hidden />}>
          {t('admin:questions.add')}
        </GlowButton>
      </div>

      {/* Filter bar */}
      <div className="flex flex-wrap items-end gap-3">
        <div className="relative min-w-[200px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
          <Input
            placeholder={t('admin:questions.search')}
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={categoryId} onChange={(e) => { setCategoryId(e.target.value); setPage(1); }} className="w-44" placeholder={t('admin:questions.allCategories')}>
          <option value="">{t('admin:questions.allCategories')}</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name.en || c.name.hi}</option>
          ))}
        </Select>
        <Select value={difficulty} onChange={(e) => { setDifficulty(e.target.value); setPage(1); }} className="w-36" placeholder={t('admin:questions.allLevels')}>
          <option value="">{t('admin:questions.allLevels')}</option>
          <option value="easy">{t('common:difficulty.easy')}</option>
          <option value="medium">{t('common:difficulty.medium')}</option>
          <option value="hard">{t('common:difficulty.hard')}</option>
        </Select>
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className="w-32" placeholder={t('admin:questions.allStatus')}>
          <option value="">{t('admin:questions.allStatus')}</option>
          <option value="active">{t('admin:questions.active')}</option>
          <option value="inactive">{t('admin:questions.inactive')}</option>
        </Select>
      </div>

      <DataTable<QuestionListItemDTO>
        columns={columns}
        data={data?.items ?? []}
        rowKey={(q) => q.id}
        loading={loading}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
        emptyMessage={t('admin:questions.empty')}
      />
    </div>
  );
}
