import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Search } from 'lucide-react';
import type { ContestantDTO, Paginated } from '@cmm/shared';
import { api } from '../../lib/api';
import { DataTable, type Column } from '../../components/ui/DataTable';
import { GlowButton } from '../../components/ui/GlowButton';
import { Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { Select } from '../../components/ui/Select';
import { useToast } from '../../stores/toast';

const LIMIT = 20;

interface FormState { name: string; mobile: string; city: string; }
const EMPTY_FORM: FormState = { name: '', mobile: '', city: '' };

export default function ContestantsPage() {
  const { t } = useTranslation(['admin', 'common']);
  const toast = useToast();

  const [data, setData] = useState<Paginated<ContestantDTO> | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('');

  // modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ContestantDTO | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // confirm deactivate
  const [deactivateTarget, setDeactivateTarget] = useState<ContestantDTO | null>(null);
  const [deactivating, setDeactivating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) params.set('search', search);
      if (activeFilter) params.set('isActive', activeFilter);
      const result = await api<Paginated<ContestantDTO>>(`/api/contestants?${params}`);
      setData(result);
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setLoading(false);
    }
  }, [page, search, activeFilter, t, toast]);

  useEffect(() => { void load(); }, [load]);

  // debounced search
  useEffect(() => {
    const id = setTimeout(() => { setSearch(searchInput); setPage(1); }, 300);
    return () => clearTimeout(id);
  }, [searchInput]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError('');
    setModalOpen(true);
  }

  function openEdit(c: ContestantDTO) {
    setEditing(c);
    setForm({ name: c.name, mobile: c.mobile, city: c.city });
    setFormError('');
    setModalOpen(true);
  }

  async function handleSave() {
    setSaving(true);
    setFormError('');
    try {
      if (editing) {
        await api(`/api/contestants/${editing.id}`, { method: 'PATCH', body: JSON.stringify(form) });
        toast.success(t('admin:contestants.updated'));
      } else {
        await api('/api/contestants', { method: 'POST', body: JSON.stringify(form) });
        toast.success(t('admin:contestants.created'));
      }
      setModalOpen(false);
      await load();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : t('admin:errors.network'));
    } finally {
      setSaving(false);
    }
  }

  async function handleDeactivate() {
    if (!deactivateTarget) return;
    setDeactivating(true);
    try {
      await api(`/api/contestants/${deactivateTarget.id}`, { method: 'DELETE' });
      toast.success(t('admin:contestants.deactivated'));
      setDeactivateTarget(null);
      await load();
    } catch {
      toast.error(t('admin:errors.network'));
    } finally {
      setDeactivating(false);
    }
  }

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  const columns: Column<ContestantDTO>[] = [
    { key: 'name', header: t('admin:contestants.name'), render: (c) => <span className="font-semibold text-ink">{c.name}</span> },
    { key: 'mobile', header: t('admin:contestants.mobile'), className: 'w-32', render: (c) => <span className="font-mono text-xs text-ink/70">{c.mobile}</span> },
    { key: 'city', header: t('admin:contestants.city'), className: 'w-32' },
    { key: 'score', header: t('admin:contestants.score'), className: 'w-20', render: (c) => <span className="tabular-nums font-bold text-gold-400">{c.score}</span> },
    {
      key: 'isActive',
      header: t('admin:contestants.status'),
      className: 'w-24',
      render: (c) => (
        <div className="flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${c.isActive ? 'bg-success-400' : 'bg-ink/30'}`} />
          <span className={`text-xs font-bold ${c.isActive ? 'text-success-400' : 'text-ink/50'}`}>
            {c.isActive ? t('admin:contestants.active') : t('admin:contestants.inactive')}
          </span>
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'w-20',
      render: (c) => (
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); setDeactivateTarget(c); }}
          className="text-xs font-bold text-danger-400 hover:text-danger-300"
        >
          {t('admin:contestants.remove')}
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('admin:contestants')}</h1>
          <p className="text-sm text-ink/50">{data ? `${data.total} ${t('admin:contestants.found')}` : '…'}</p>
        </div>
        <GlowButton icon={<Plus className="h-4 w-4" aria-hidden />} onClick={openCreate}>
          {t('admin:contestants.add')}
        </GlowButton>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-end gap-3">
        <div className="relative min-w-[200px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
          <Input placeholder={t('admin:contestants.search')} value={searchInput} onChange={(e) => setSearchInput(e.target.value)} className="pl-9" />
        </div>
        <Select value={activeFilter} onChange={(e) => { setActiveFilter(e.target.value); setPage(1); }} className="w-32" placeholder={t('admin:contestants.all')}>
          <option value="">{t('admin:contestants.all')}</option>
          <option value="true">{t('admin:contestants.active')}</option>
          <option value="false">{t('admin:contestants.inactive')}</option>
        </Select>
      </div>

      <DataTable<ContestantDTO>
        columns={columns}
        data={data?.items ?? []}
        rowKey={(c) => c.id}
        onRowClick={openEdit}
        loading={loading}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
        emptyMessage={t('admin:contestants.empty')}
      />

      {/* Create / Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? t('admin:contestants.edit') : t('admin:contestants.add')} size="sm">
        <div className="space-y-4">
          <Input label={t('admin:contestants.name')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input label={t('admin:contestants.mobile')} value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="9876543210" />
          <Input label={t('admin:contestants.city')} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          {formError && <p className="text-xs font-semibold text-danger-400">{formError}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <GlowButton variant="ghost" size="sm" onClick={() => setModalOpen(false)}>{t('common:cancel')}</GlowButton>
            <GlowButton size="sm" loading={saving} onClick={handleSave}>{editing ? t('common:save') : t('common:create')}</GlowButton>
          </div>
        </div>
      </Modal>

      {/* Deactivate confirm */}
      <ConfirmDialog
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={handleDeactivate}
        title={t('admin:contestants.confirmRemoveTitle')}
        message={t('admin:contestants.confirmRemoveMsg', { name: deactivateTarget?.name ?? '' })}
        confirmLabel={t('admin:contestants.remove')}
        loading={deactivating}
      />
    </div>
  );
}
