import { useTranslation } from 'react-i18next';
import { formatINR } from '@cmm/shared';
import { GlassCard } from '../components/ui/GlassCard';
import { GlowButton } from '../components/ui/GlowButton';
import { Badge } from '../components/ui/Badge';
import { Input } from '../components/ui/Input';
import { LanguageToggle } from '../components/ui/LanguageToggle';

const COLOR_TOKENS: { name: string; className: string }[] = [
  { name: 'navy.950', className: 'bg-navy-950' },
  { name: 'navy.900', className: 'bg-navy-900' },
  { name: 'navy.800', className: 'bg-navy-800' },
  { name: 'navy.700', className: 'bg-navy-700' },
  { name: 'electric.500', className: 'bg-electric-500' },
  { name: 'electric.400', className: 'bg-electric-400' },
  { name: 'gold.400', className: 'bg-gold-400' },
  { name: 'gold.300', className: 'bg-gold-300' },
  { name: 'violet.500', className: 'bg-violet-500' },
  { name: 'success.500', className: 'bg-success-500' },
  { name: 'warning.500', className: 'bg-warning-500' },
  { name: 'danger.500', className: 'bg-danger-500' },
];

/** Living reference (M02 §5) — tokens + P0 component subset in both scripts. */
export default function StyleguidePage() {
  const { t } = useTranslation('common');

  return (
    <div className="stage-bg min-h-screen p-8">
      <div className="mx-auto max-w-4xl space-y-10">
        <header className="flex items-center justify-between">
          <h1 className="font-display text-3xl font-extrabold text-ink">Styleguide</h1>
          <LanguageToggle />
        </header>

        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">Colors</h2>
          <div className="grid grid-cols-4 gap-3 sm:grid-cols-6">
            {COLOR_TOKENS.map(({ name, className }) => (
              <div key={name} className="glass p-2 text-center">
                <div className={`mb-2 h-10 w-full rounded-lg ${className}`} />
                <p className="text-[10px] font-bold text-ink/70">{name}</p>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">Typography</h2>
          <GlassCard className="space-y-3 p-6">
            <p className="font-display text-4xl font-extrabold text-ink">सोचो • चुनो • जीतो</p>
            <p className="font-display text-3xl font-extrabold text-ink">Think • Choose • Win</p>
            <p className="font-display text-2xl font-bold text-gold-400 tabular">{formatINR(10000000)}</p>
            <p className="font-devanagari text-base text-ink">
              {t('appName')} — {t('brandLine')}
            </p>
            <p className="font-devanagari text-sm text-ink/60">
              आसान / मध्यम / कठिन — easy / medium / hard · {t('difficulty.easy')} · {t('difficulty.medium')} ·{' '}
              {t('difficulty.hard')}
            </p>
          </GlassCard>
        </section>

        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">Buttons</h2>
          <GlassCard className="flex flex-wrap items-center gap-3 p-6">
            <GlowButton variant="gold">Gold</GlowButton>
            <GlowButton variant="blue">Blue</GlowButton>
            <GlowButton variant="violet">Violet</GlowButton>
            <GlowButton variant="danger">Danger</GlowButton>
            <GlowButton variant="ghost">Ghost</GlowButton>
            <GlowButton variant="gold" loading>
              Loading
            </GlowButton>
            <GlowButton variant="gold" disabled>
              Disabled
            </GlowButton>
            <GlowButton variant="gold" size="xl" className="mt-3">
              XL — सेशन शुरू करें
            </GlowButton>
          </GlassCard>
        </section>

        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">Badges</h2>
          <GlassCard className="flex flex-wrap items-center gap-3 p-6">
            <Badge tone="success">{t('difficulty.easy')}</Badge>
            <Badge tone="warning">{t('difficulty.medium')}</Badge>
            <Badge tone="danger">{t('difficulty.hard')}</Badge>
            <Badge tone="info">{t('status.active')}</Badge>
            <Badge tone="gold">{t('roles.super_admin')}</Badge>
          </GlassCard>
        </section>

        <section className="pb-10">
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink/50">Inputs &amp; Cards</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <GlassCard tone="gold" className="space-y-4 p-6">
              <Input name="sg1" label={t('search')} placeholder="प्रश्न खोजें…" />
              <Input name="sg2" label={t('error')} error={t('validation.required')} />
            </GlassCard>
            <GlassCard tone="blue" interactive className="flex flex-col items-start gap-2 p-6">
              <p className="font-display text-lg font-bold text-ink">glass--blue + glass--int</p>
              <p className="text-sm text-ink/60">Hover me — lift + gold border.</p>
            </GlassCard>
          </div>
        </section>
      </div>
    </div>
  );
}
