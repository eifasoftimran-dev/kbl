import { useState, type FormEvent } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Trophy } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { ApiClientError } from '../lib/api';
import { GlassCard } from '../components/ui/GlassCard';
import { GlowButton } from '../components/ui/GlowButton';
import { Input } from '../components/ui/Input';
import { LanguageToggle } from '../components/ui/LanguageToggle';

/** Screen A gate (M08 §2): email/password → JWT session. */
export default function LoginPage() {
  const { t } = useTranslation(['login', 'errors']);
  const { user, login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  if (user) return <Navigate to="/admin" replace />;

  async function onSubmit(e: FormEvent<HTMLFormElement>): Promise<void> {
    e.preventDefault();
    if (submitting) return;
    setErrorKey(null);
    setSubmitting(true);
    try {
      await login(email.trim(), password);
      navigate('/admin', { replace: true });
    } catch (err) {
      if (err instanceof ApiClientError) {
        setErrorKey(
          err.code === 'UNAUTHORIZED' || err.code === 'VALIDATION_ERROR' ? 'login:invalidCredentials' : 'errors:unknown',
        );
      } else {
        setErrorKey('errors:network');
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="stage-bg relative flex min-h-screen items-center justify-center p-6">
      <div className="absolute right-6 top-6">
        <LanguageToggle />
      </div>

      <GlassCard tone="gold" className="w-full max-w-md p-8">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-gold-400/40 bg-gradient-to-b from-gold-300/20 to-transparent shadow-glow-gold">
            <Trophy className="h-8 w-8 text-gold-400" aria-hidden />
          </div>
          <h1 className="font-display text-2xl font-extrabold text-ink">{t('login:title')}</h1>
          <p className="mt-1 text-sm text-ink/60">{t('login:subtitle')}</p>
        </div>

        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <Input
            name="email"
            type="email"
            autoComplete="email"
            label={t('login:email')}
            placeholder={t('login:emailPlaceholder')}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input
            name="password"
            type="password"
            autoComplete="current-password"
            label={t('login:password')}
            placeholder={t('login:passwordPlaceholder')}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          {errorKey && (
            <p role="alert" className="rounded-xl border border-danger-500/40 bg-danger-500/10 px-3 py-2 text-sm font-semibold text-danger-400">
              {t(errorKey)}
            </p>
          )}

          <GlowButton type="submit" variant="gold" size="lg" loading={submitting} className="w-full">
            {submitting ? t('login:submitting') : t('login:submit')}
          </GlowButton>
        </form>

        <p className="mt-6 text-center text-xs text-ink/40">{t('login:devHint')}</p>
      </GlassCard>
    </div>
  );
}
