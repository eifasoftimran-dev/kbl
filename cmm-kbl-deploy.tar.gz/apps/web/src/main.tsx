import React from 'react';
import ReactDOM from 'react-dom/client';
// Devanagari-first fonts (M10 §5) — bundled locally via @fontsource.
import '@fontsource/noto-sans-devanagari/400.css';
import '@fontsource/noto-sans-devanagari/700.css';
import '@fontsource/mukta/600.css';
import '@fontsource/mukta/800.css';
import './i18n';
import './index.css';
import App from './App';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
